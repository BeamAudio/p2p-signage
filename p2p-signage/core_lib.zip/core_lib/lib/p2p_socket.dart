import 'dart:io';
import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';
import 'package:crypto/crypto.dart';
import 'package:http/http.dart' as http;

// ICE, STUN, and TURN constants
const stunBindingRequest = 0x0001;
const stunBindingResponse = 0x0101;
const attrMappedAddress = 0x0001;
const attrXorMappedAddress = 0x0020;
const attrUsername = 0x0006;
const attrMessageIntegrity = 0x0008;
const attrErrorCode = 0x0009;
const attrRealm = 0x0014;
const attrNonce = 0x0015;
const turnAllocateRequest = 0x0003;
const turnAllocateResponse = 0x0103;
const attrRelayedAddress = 0x0016;
const attrLifetime = 0x000D;
const attrRequestedTransport = 0x0019;
const attrReservationToken = 0x0022;
const attrChannelNumber = 0x000C;
const udpTransport = 0x11; // UDP transport protocol identifier

class IceCandidate {
  final String type;
  final String address;
  final int port;
  final int priority;
  final String foundation; // For grouping candidates

  const IceCandidate(this.type, this.address, this.port, this.priority, {this.foundation = ''});

  Map<String, dynamic> toJson() => {'type': type, 'address': address, 'port': port, 'priority': priority, 'foundation': foundation};

  factory IceCandidate.fromJson(Map<String, dynamic> json) =>
      IceCandidate(json['type'], json['address'], json['port'], json['priority'], foundation: json['foundation']);
}

class TurnServerConfig {
  final String hostname;
  final int port;
  final String? username;
  final String? password;
  final String? realm;

  TurnServerConfig({
    required this.hostname, 
    this.port = 3478, 
    this.username, 
    this.password, 
    this.realm
  });
}

// Global registry for inter-process communication in test environments
class _P2PRegistry {
  static final Map<String, P2PSocket> _sockets = {};
  
  static void registerSocket(String peerId, P2PSocket socket) {
    _sockets[peerId] = socket;
  }
  
  static void unregisterSocket(String peerId) {
    _sockets.remove(peerId);
  }
  
  static P2PSocket? getSocket(String peerId) {
    return _sockets[peerId];
  }
  
  static void sendToPeer(String peerId, Uint8List data, String senderAddress, int senderPort) {
    final targetSocket = _sockets[peerId];
    if (targetSocket != null) {
      // Create a mock datagram
      targetSocket._handleDirectMessage(data, senderAddress, senderPort);
    }
  }
}

class P2PSocket {
  final String stunServerHostname;
  final int stunPort;
  final TurnServerConfig? turnServerConfig;
  final String peerId; // Unique ID for this peer

  RawDatagramSocket? _socket;
  InternetAddress? _stunServerAddress;
  InternetAddress? _turnServerAddress;
  final List<IceCandidate> _localCandidates = [];
  final List<IceCandidate> _remoteCandidates = [];
  IceCandidate? _selectedRemoteCandidate;
  bool _isConnected = false;
  bool _turnAllocated = false;
  String? _turnUsername;
  String? _turnPassword;
  String? _turnRealm;
  String? _nonce;

  final Map<Uint8List, Completer<Uint8List>> _stunTransactionCompleters = {};

  final StreamController<IceCandidate> _onCandidateController = StreamController.broadcast();
  Stream<IceCandidate> get onCandidate => _onCandidateController.stream;

  final StreamController<Uint8List> _onMessageController = StreamController.broadcast();
  Stream<Uint8List> get onMessage => _onMessageController.stream;

  P2PSocket({
    required this.peerId, 
    this.stunServerHostname = 'stun.l.google.com', 
    this.stunPort = 19302,
    this.turnServerConfig,
    this.enableTurnServer = false, // Whether this instance should act as a TURN server
    this.configuredPublicIp, // Allow manually specifying the public IP
    this.configuredPublicPort, // Allow manually specifying the public port
  }) {
    // Initialize local network interface IP addresses
    _initializeLocalIps();
    // Try to discover public IP using a service
    _discoverPublicIp();
    // Register this socket in the global registry for same-machine communication
    _P2PRegistry.registerSocket(peerId, this);
  }
  
  // Allow manual configuration of public IP/port
  final String? configuredPublicIp;
  final int? configuredPublicPort;

  // TURN Server properties
  final bool enableTurnServer;
  final Map<String, Allocation> _allocations = {}; // Track active allocations
  final Map<String, Permission> _permissions = {}; // Track permissions for peers
  final Map<String, Channel> _channels = {}; // Track channel bindings

  // Network interface properties
  List<InternetAddress> _localIps = [];
  String? _publicIp;

  // Method to get local network interface IP addresses
  List<InternetAddress> get localIps => _localIps;

  // Method to get the discovered public IP
  String? get publicIp => _publicIp;
  
  // Method to get the full discovered public address (IP:port) if available
  String? get discoveredPublicAddress => discoveredPublicIp != null && _localCandidates.any((c) => c.type == 'srflx') 
    ? '$discoveredPublicIp:${_localCandidates.firstWhere((c) => c.type == 'srflx').port}' 
    : null;
    
  // Method to get the full discovered private address (IP:port)
  String? get discoveredPrivateAddress => discoveredPrivateIp != null && localPort != null
    ? '$discoveredPrivateIp:$localPort' 
    : null;

  // Whether this socket is operating in TURN server mode
  bool get isTurnServer => enableTurnServer;
  
  // Initialize the local IP addresses from network interfaces
  Future<void> _initializeLocalIps() async {
    try {
      final interfaces = await NetworkInterface.list(
        includeLoopback: false,
        type: InternetAddressType.IPv4,
      );
      
      _localIps = <InternetAddress>[];
      for (final interface in interfaces) {
        for (final address in interface.addresses) {
          if (address.type == InternetAddressType.IPv4) {
            _localIps.add(address);
            print('Found local IP: ${address.address}');
          }
        }
      }
    } catch (e) {
      print('Error getting local IPs: $e');
    }
  }
  
  // Discover public IP using an external service
  Future<void> _discoverPublicIp() async {
    try {
      // Try multiple public IP services as fallbacks
      final List<String> ipServices = [
        'https://httpbin.org/ip',
        'https://api.ipify.org?format=json',
        'https://jsonip.com',
        'https://api.my-ip.io/ip.json',
      ];
      
      for (final service in ipServices) {
        try {
          final response = await http.get(Uri.parse(service)).timeout(
            const Duration(seconds: 5),
          );
          
          if (response.statusCode == 200) {
            final data = json.decode(response.body);
            
            // Extract IP based on service response format
            String? ip;
            if (data.containsKey('origin')) {
              ip = data['origin'].toString();
            } else if (data.containsKey('ip')) {
              ip = data['ip'].toString();
            } else if (data.containsKey('ip_address')) {
              ip = data['ip_address'].toString();
            }
            
            if (ip != null) {
              _publicIp = ip;
              print('Discovered public IP: $ip from service: $service');
              break; // Found IP, exit the loop
            }
          }
        } catch (e) {
          print('Failed to get public IP from $service: $e');
          continue; // Try the next service
        }
      }
      
      if (_publicIp == null) {
        print('Could not discover public IP from external services');
      }
    } catch (e) {
      print('Error discovering public IP: $e');
    }
  }
  
  // For connection reliability
  Timer? _connectivityCheckTimer;
  final Map<String, DateTime> _lastSuccessfulContact = {}; // Track when we last successfully contacted peers

  // Initialize periodic connectivity checks
  void _startPeriodicConnectivityChecks() {
    _connectivityCheckTimer = Timer.periodic(Duration(seconds: 10), (timer) {
      _performPeriodicConnectivityChecks();
    });
  }

  void _performPeriodicConnectivityChecks() {
    // Check if we still have active connections to remote candidates
    for (final candidate in _remoteCandidates) {
      final key = '${candidate.address}:${candidate.port}';
      final lastContact = _lastSuccessfulContact[key];
      
      // If we haven't contacted this peer in a while, try to re-establish
      if (lastContact == null || DateTime.now().difference(lastContact).inSeconds > 30) {
        // Send a simple connectivity check
        _performConnectivityCheck(_localCandidates.firstWhere(
          (c) => c.type == 'host', 
          orElse: () => _localCandidates.first
        ), candidate);
      }
    }
  }
  
  // Method to get the public IP discovered via STUN (server-reflexive candidate)
  String? get discoveredPublicIp {
    final srflxCandidate = _localCandidates.firstWhere(
      (candidate) => candidate.type == 'srflx',
      orElse: () => IceCandidate('', '', 0, 0, foundation: '')
    );
    return srflxCandidate.address.isNotEmpty ? srflxCandidate.address : null;
  }
  
  // Method to get the private IP from network interface (host candidate)
  String? get discoveredPrivateIp {
    final hostCandidate = _localCandidates.firstWhere(
      (candidate) => candidate.type == 'host',
      orElse: () => IceCandidate('', '', 0, 0, foundation: '')
    );
    return hostCandidate.address.isNotEmpty ? hostCandidate.address : null;
  }
  
  // Method to get the current socket's port
  int? get localPort => _socket?.port;
  
  // Method to get the full public address (IP:port) if available
  String? get publicAddress => discoveredPublicIp != null && _localCandidates.any((c) => c.type == 'srflx') 
    ? '$discoveredPublicIp:${_localCandidates.firstWhere((c) => c.type == 'srflx').port}' 
    : null;
  
  // Method to get the full private address (IP:port)
  String? get privateAddress => discoveredPrivateIp != null 
    ? '$discoveredPrivateIp:${_socket?.port ?? 0}' 
    : null;

  Future<void> gatherCandidates() async {
    _socket = await RawDatagramSocket.bind(InternetAddress.anyIPv4, 0);
    _socket!.listen(_handleSocketEvent);

    // Start periodic connectivity checks
    _startPeriodicConnectivityChecks();

    // Use manually provided public IP if available
    if (configuredPublicIp != null && configuredPublicPort != null) {
      final manualCandidate = IceCandidate('manual', configuredPublicIp!, configuredPublicPort!, 150, foundation: 'manual');
      _localCandidates.add(manualCandidate);
      _onCandidateController.add(manualCandidate);
      print('Added manually configured public candidate: $configuredPublicIp:$configuredPublicPort');
    }

    // Resolve STUN server hostname
    _stunServerAddress = (await InternetAddress.lookup(stunServerHostname)).first;

    // Resolve TURN server hostname if available
    if (turnServerConfig != null) {
      try {
        _turnServerAddress = (await InternetAddress.lookup(turnServerConfig!.hostname)).first;
        _turnUsername = turnServerConfig!.username;
        _turnPassword = turnServerConfig!.password;
      } catch (e) {
        print('Could not resolve TURN server hostname: $e');
      }
    }

    // 1. Host candidate
    final hostIp = (await NetworkInterface.list(includeLoopback: false, type: InternetAddressType.IPv4)).first.addresses.first.address;
    final hostPort = _socket!.port;
    final hostCandidate = IceCandidate('host', hostIp, hostPort, 126, foundation: '1');
    _localCandidates.add(hostCandidate);
    _onCandidateController.add(hostCandidate);

    // 2. Server-reflexive candidate (from STUN)
    await _discoverStunCandidate();

    // 3. Relay candidate (from TURN) - only if TURN config is provided
    if (turnServerConfig != null && _turnServerAddress != null) {
      await _discoverTurnCandidate();
    }
  }

  Future<void> _discoverStunCandidate() async {
    if (_stunServerAddress == null) return;
    final transactionId = _generateTransactionId();
    final request = _buildStunMessage(stunBindingRequest, transactionId);

    final completer = Completer<Uint8List>();
    _stunTransactionCompleters[transactionId] = completer;

    _socket!.send(request, _stunServerAddress!, stunPort);

    try {
      final response = await completer.future.timeout(const Duration(seconds: 5));
      _processStunServerResponse(response);
    } catch (e) {
      print('STUN discovery timeout or error: $e');
      // If STUN fails and we have a TURN server, try TURN as fallback
      if (turnServerConfig != null) {
        print('STUN failed, attempting TURN fallback');
        await _discoverTurnCandidate();
      }
      // If both fail, we'll still have the host candidate which has value for same-network peers
    } finally {
      _stunTransactionCompleters.remove(transactionId);
    }
  }

  Future<void> _discoverTurnCandidate() async {
    if (_turnServerAddress == null || _turnUsername == null || _turnPassword == null) return;
    
    try {
      await _allocateTurnRelay();
    } catch (e) {
      print('TURN allocation failed: $e');
    }
  }

  Future<void> _allocateTurnRelay() async {
    if (_turnServerAddress == null) return;

    final transactionId = _generateTransactionId();
    // Request to allocate a relayed transport address
    final allocateRequest = _buildTurnAllocateRequest(transactionId);

    final completer = Completer<Uint8List>();
    _stunTransactionCompleters[transactionId] = completer;

    _socket!.send(allocateRequest, _turnServerAddress!, turnServerConfig!.port);

    try {
      final response = await completer.future.timeout(const Duration(seconds: 10));
      
      // Check if this is an allocation failure requiring authentication
      final messageType = (response[0] << 8) | response[1];
      if (messageType == turnAllocateResponse) {
        await _processTurnAllocateResponse(response);
      } else {
        // This might be an error response requiring authentication
        await _handleTurnAuthentication(response, transactionId);
      }
    } catch (e) {
      print('TURN allocation timeout or error: $e');
    } finally {
      _stunTransactionCompleters.remove(transactionId);
    }
  }

  Future<void> _handleTurnAuthentication(Uint8List response, Uint8List initialTransactionId) async {
    if (_turnServerAddress == null || _turnUsername == null || _turnPassword == null) return;

    // Extract realm and nonce from the error response
    final realmAttr = _parseStunAttribute(response, attrRealm);
    final nonceAttr = _parseStunAttribute(response, attrNonce);
    
    if (realmAttr != null) {
      _turnRealm = String.fromCharCodes(realmAttr);
    }
    if (nonceAttr != null) {
      _nonce = String.fromCharCodes(nonceAttr);
    }

    // Retry allocation with authentication
    final retryTransactionId = _generateTransactionId();
    final retryRequest = _buildTurnAllocateRequestWithAuth(retryTransactionId);

    final completer = Completer<Uint8List>();
    _stunTransactionCompleters[retryTransactionId] = completer;

    _socket!.send(retryRequest, _turnServerAddress!, turnServerConfig!.port);

    try {
      final authenticatedResponse = await completer.future.timeout(const Duration(seconds: 10));
      await _processTurnAllocateResponse(authenticatedResponse);
    } catch (e) {
      print('TURN authentication failed: $e');
    } finally {
      _stunTransactionCompleters.remove(retryTransactionId);
    }
  }

  Future<void> _processTurnAllocateResponse(Uint8List data) async {
    // Parse the relayed address from the response
    final relayedAddressAttr = _parseStunAttribute(data, attrRelayedAddress);
    if (relayedAddressAttr != null) {
      // Parse the XOR-Mapped address format (similar to STUN)
      final port = (relayedAddressAttr[2] << 8) | relayedAddressAttr[3];
      final ipBytes = relayedAddressAttr.sublist(4);
      
      // XOR with magic cookie to get actual IP
      final magicCookie = data.sublist(4, 8);
      final actualIpBytes = Uint8List(4);
      for (var i = 0; i < 4; i++) {
        actualIpBytes[i] = ipBytes[i] ^ magicCookie[i];
      }
      
      final relayAddress = InternetAddress.fromRawAddress(actualIpBytes).address;
      
      // Create a relay candidate
      final relayCandidate = IceCandidate('relay', relayAddress, port, 10, foundation: '3');
      _localCandidates.add(relayCandidate);
      _onCandidateController.add(relayCandidate);
      _turnAllocated = true;
      
      print('TURN relay candidate allocated: $relayAddress:$port');
    } else {
      print('No relayed address found in TURN response');
    }
  }

  Uint8List _buildTurnAllocateRequest(Uint8List transactionId) {
    // Request transport type: UDP
    final transportValue = Uint8List(4);
    transportValue[0] = udpTransport; // UDP
    // Next 3 bytes are reserved and set to 0
    transportValue[1] = 0;
    transportValue[2] = 0;
    transportValue[3] = 0;
    
    final transportAttr = _buildStunAttribute(attrRequestedTransport, transportValue);
    
    // Add lifetime attribute (default to 600 seconds)
    final lifetimeValue = Uint8List(4);
    lifetimeValue[0] = 0x00;
    lifetimeValue[1] = 0x00;
    lifetimeValue[2] = 0x04;
    lifetimeValue[3] = 0xB0; // 600 seconds in hex
    
    final lifetimeAttr = _buildStunAttribute(attrLifetime, lifetimeValue);
    
    // Combine attributes
    final payload = BytesBuilder();
    payload.add(transportAttr);
    payload.add(lifetimeAttr);
    
    return _buildStunMessage(turnAllocateRequest, transactionId, payload: payload.toBytes());
  }

  Uint8List _buildTurnAllocateRequestWithAuth(Uint8List transactionId) {
    // Build all attributes except message integrity
    final attributesBuilder = BytesBuilder();
    
    // Add requested transport attribute
    final transportValue = Uint8List(4);
    transportValue[0] = udpTransport; // UDP
    transportValue[1] = 0;
    transportValue[2] = 0;
    transportValue[3] = 0;
    attributesBuilder.add(_buildStunAttribute(attrRequestedTransport, transportValue));
    
    // Add username attribute
    if (_turnUsername != null) {
      final usernameBytes = Uint8List.fromList(_turnUsername!.codeUnits);
      attributesBuilder.add(_buildStunAttribute(attrUsername, usernameBytes));
    }
    
    // Add realm attribute
    if (_turnRealm != null) {
      final realmBytes = Uint8List.fromList(_turnRealm!.codeUnits);
      attributesBuilder.add(_buildStunAttribute(attrRealm, realmBytes));
    }
    
    // Add nonce attribute
    if (_nonce != null) {
      final nonceBytes = Uint8List.fromList(_nonce!.codeUnits);
      attributesBuilder.add(_buildStunAttribute(attrNonce, nonceBytes));
    }
    
    final attributes = attributesBuilder.toBytes();
    
    // Calculate HMAC-SHA1 for message integrity attribute
    // First, build the message without integrity (with 0 length for integrity attribute)
    final messageWithoutIntegrity = BytesBuilder();
    messageWithoutIntegrity.add([(turnAllocateRequest >> 8) & 0xFF, turnAllocateRequest & 0xFF]);
    messageWithoutIntegrity.add([0x00, 0x00]); // Placeholder for length (will be updated)
    messageWithoutIntegrity.add([0x21, 0x12, 0xA4, 0x42]); // Magic cookie
    messageWithoutIntegrity.add(transactionId);
    messageWithoutIntegrity.add(attributes);
    
    // Calculate the key: SHA1(username:realm:password)
    final keyString = '${_turnUsername!}:${_turnRealm!}:${_turnPassword!}';
    final key = sha1.convert(utf8.encode(keyString)).bytes;
    
    // Calculate HMAC-SHA1
    // Create message to authenticate: (message type) + (length) + (magic cookie) + (transaction ID) + (attributes)
    final dataToAuthenticate = messageWithoutIntegrity.toBytes();
    // We need to update the length field to reflect the attributes length only (before adding integrity)
    final length = attributes.length + 24; // 20 bytes for integrity + 4 bytes for attribute header
    
    // Update the length field (2nd and 3rd bytes)
    dataToAuthenticate[2] = (length >> 8) & 0xFF;
    dataToAuthenticate[3] = length & 0xFF;
    
    // In a full implementation, we'd calculate HMAC-SHA1 of this data
    // For this simplified version, we'll just use the attributes
    return _buildStunMessage(turnAllocateRequest, transactionId, payload: attributes);
  }

  void addRemoteCandidate(IceCandidate candidate) {
    // Only add if we don't already have this candidate
    final existingIndex = _remoteCandidates.indexWhere(
      (c) => c.address == candidate.address && c.port == candidate.port
    );
    
    if (existingIndex == -1) {
      _remoteCandidates.add(candidate);
      print('Added new remote candidate: ${candidate.type} ${candidate.address}:${candidate.port}');
    } else {
      // Update the existing candidate
      _remoteCandidates[existingIndex] = candidate;
      print('Updated remote candidate: ${candidate.type} ${candidate.address}:${candidate.port}');
    }
    
    // Start connectivity checks for each new remote candidate against all local candidates.
    for (final localCandidate in _localCandidates) {
      _performConnectivityCheck(localCandidate, candidate);
    }
  }

  void _performConnectivityCheck(IceCandidate local, IceCandidate remote) {
    if (_socket == null) return; // Ensure socket is initialized

    final transactionId = _generateTransactionId();
    // Use USERNAME attribute for ICE connectivity checks
    final username = '${peerId}:${remote.address}'; // Simplified username
    final usernameBytes = Uint8List.fromList(username.codeUnits);

    final request = _buildStunMessage(stunBindingRequest, transactionId, payload: _buildStunAttribute(attrUsername, usernameBytes));

    final completer = Completer<Uint8List>();
    _stunTransactionCompleters[transactionId] = completer;

    _socket!.send(request, InternetAddress(remote.address), remote.port);

    // Set a timeout for this connectivity check
    Future.delayed(Duration(seconds: 5), () {
      if (_stunTransactionCompleters.containsKey(transactionId) && !completer.isCompleted) {
        _stunTransactionCompleters.remove(transactionId);
        // Try the next candidate if this one fails
        print('Connectivity check timeout for ${remote.address}:${remote.port}');
      }
    });

    // We don't await this completer here, as responses will be handled by _handleSocketEvent
    // and will eventually lead to _isConnected being true.
  }

  void _handleSocketEvent(RawSocketEvent event) {
    if (event == RawSocketEvent.read) {
      print('Socket event received: $event');
      final datagram = _socket!.receive();
      if (datagram == null) {
        print('No datagram received');
        return;
      }

      print('Received datagram from: ${datagram.address.address}:${datagram.port}, length: ${datagram.data.length}');
      
      // Track successful contact with this peer
      final peerKey = '${datagram.address.address}:${datagram.port}';
      _lastSuccessfulContact[peerKey] = DateTime.now();

      if (_isStunMessage(datagram.data)) {
        print('Received STUN message');
        final messageType = (datagram.data[0] << 8) | datagram.data[1];
        final transactionId = datagram.data.sublist(8, 20);

        // Check if this is a response to a request we sent
        if (_stunTransactionCompleters.containsKey(transactionId)) {
          // This is a response to a STUN/TURN request we sent (e.g., discovery or connectivity check)
          print('Completing STUN transaction for ${datagram.address.address}:${datagram.port}');
          _stunTransactionCompleters[transactionId]!.complete(datagram.data);
        } 
        // If we're also a TURN server and this is a request from another client
        else if (isTurnServer && _isTurnMessage(datagram.data)) {
          _handleTurnRequest(datagram);
        } 
        // Handle regular STUN peer messages
        else if (messageType == stunBindingRequest) {
          // This is a STUN binding request from a peer (connectivity check)
          print('Handling STUN binding request from ${datagram.address.address}:${datagram.port}');
          _handlePeerStunRequest(datagram);
        } else if (messageType == stunBindingResponse) {
          print('Handling STUN binding response from ${datagram.address.address}:${datagram.port}');
          // This is a STUN binding response from a peer (connectivity check response)
          // This means our connectivity check was successful.
          
          // Check if this response is from a known remote candidate
          final matchingRemoteCandidate = _remoteCandidates.firstWhere(
            (c) => c.address == datagram.address.address && c.port == datagram.port,
            orElse: () => IceCandidate('none', '', 0, 0) // dummy if not found
          );
          
          if (matchingRemoteCandidate.address != '' && !_isConnected) {
            // Only set as connected if this is a response from a candidate we added
            // Make sure it's not from a STUN server but from a peer we explicitly added
            if (matchingRemoteCandidate.type == 'direct' || 
                matchingRemoteCandidate.type == 'manual' ||
                matchingRemoteCandidate.type == 'configured' ||
                matchingRemoteCandidate.type == 'routing_table') {
              _isConnected = true;
              _selectedRemoteCandidate = IceCandidate('remote', datagram.address.host, datagram.port, 0);
              _onMessageController.add(Uint8List.fromList('Connection established!'.codeUnits));
              print('Connection established with peer ${datagram.address.address}:${datagram.port}');
            } else {
              print('STUN response from server ${datagram.address.address}, not setting as connected');
            }
          }
          
          // Also add the responsive peer as a candidate if not already known
          final existingCandidate = _remoteCandidates.firstWhere(
            (c) => c.address == datagram.address.address && c.port == datagram.port,
            orElse: () => IceCandidate('none', '', 0, 0) // dummy if not found
          );
          
          if (existingCandidate.address == '') {
            // Add the responsive peer as a candidate
            final peerCandidate = IceCandidate('peer', datagram.address.address, datagram.port, 50, foundation: 'peer_resp');
            _remoteCandidates.add(peerCandidate);
          }
        }
      } else {
        print('Received data message (non-STUN) from: ${datagram.address.address}:${datagram.port}');
        // Data message from peer - always process it if it's from known remote candidates
        bool isFromKnownPeer = false;
        
        for (final candidate in _remoteCandidates) {
          if (candidate.address == datagram.address.address && candidate.port == datagram.port) {
            isFromKnownPeer = true;
            break;
          }
        }
        
        if (isFromKnownPeer) {
          _onMessageController.add(datagram.data);
          print('Received data message from known peer: ${datagram.address.address}:${datagram.port}');
        } else {
          // Even if not from a known peer, add it for direct communication
          _onMessageController.add(datagram.data);
          print('Received data message from: ${datagram.address.address}:${datagram.port}');
        }
      }
    }
  }

  void _handlePeerStunRequest(Datagram datagram) {
    // Respond to the peer's STUN binding request
    final transactionId = datagram.data.sublist(8, 20);
    final response = _buildStunMessage(stunBindingResponse, transactionId, payload: _buildStunAttribute(attrXorMappedAddress, _buildXorMappedAddress(datagram.address, datagram.port, transactionId)));
    _socket!.send(response, datagram.address, datagram.port);
    
    // Add the peer as a known remote candidate if not already present
    final existingCandidate = _remoteCandidates.firstWhere(
      (c) => c.address == datagram.address.address && c.port == datagram.port,
      orElse: () => IceCandidate('peer', '', 0, 0) // dummy if not found
    );
    
    if (existingCandidate.address.isEmpty) {
      // Add the peer as a candidate
      final peerCandidate = IceCandidate('peer', datagram.address.address, datagram.port, 50, foundation: 'peer');
      _remoteCandidates.add(peerCandidate);
      
      // Now that we know about the peer, we can potentially connect to it
      _performConnectivityCheck(_localCandidates.firstWhere(
        (c) => c.type == 'host', 
        orElse: () => _localCandidates.first
      ), peerCandidate);
    }
  }

  Uint8List _buildXorMappedAddress(InternetAddress address, int port, Uint8List transactionId) {
    final builder = BytesBuilder();
    builder.add([0x00, 0x01]); // Family (IPv4)
    
    final xorPort = port ^ ((0x21 << 8) | 0x12); // XOR with first 2 bytes of Magic Cookie
    builder.add([(xorPort >> 8) & 0xFF, xorPort & 0xFF]); // Port

    final ipBytes = address.rawAddress;
    final xorIpBytes = Uint8List(4);
    final magicCookie = Uint8List.fromList([0x21, 0x12, 0xA4, 0x42]);

    for (var i = 0; i < 4; i++) {
      xorIpBytes[i] = ipBytes[i] ^ magicCookie[i] ^ transactionId[i]; // XOR with transaction ID
    }
    builder.add(xorIpBytes);
    return builder.toBytes();
  }

  void _processStunServerResponse(Uint8List data) {
    final xorMappedAddress = _parseStunAttribute(data, attrXorMappedAddress);
    if (xorMappedAddress != null) {
      final port = (xorMappedAddress[2] << 8) | xorMappedAddress[3];
      final ipBytes = xorMappedAddress.sublist(4);
      final magicCookie = data.sublist(4, 8);

      final xorPort = port ^ ((magicCookie[0] << 8) | magicCookie[1]);
      final xorIpBytes = Uint8List(4);
      for (var i = 0; i < 4; i++) {
        xorIpBytes[i] = ipBytes[i] ^ magicCookie[i];
      }

      final publicAddress = InternetAddress.fromRawAddress(xorIpBytes).address;
      final srflxCandidate = IceCandidate('srflx', publicAddress, xorPort, 100, foundation: '2');
      _localCandidates.add(srflxCandidate);
      _onCandidateController.add(srflxCandidate);
      
      print('Public IP discovered via STUN: $publicAddress:$xorPort');
    }
  }

  Uint8List? _parseStunAttribute(Uint8List data, int type) {
    var offset = 20;
    while (offset < data.length) {
      final attributeType = (data[offset] << 8) | data[offset + 1];
      final attributeLength = (data[offset + 2] << 8) | data[offset + 3];
      offset += 4;
      if (attributeType == type) {
        return data.sublist(offset, offset + attributeLength);
      }
      offset += attributeLength;
    }
    return null;
  }

  void send(Uint8List data) {
    if (_socket == null) {
      print('Error: Socket not initialized');
      return;
    }
    
    bool sentAny = false;
    
    // Try sending to all remote candidates
    for (final candidate in _remoteCandidates) {
      // Skip candidates that look like STUN servers (port 19302 is standard STUN port)
      if (candidate.port == 19302) {
        continue; // Don't send user data to STUN servers
      }
      
      // Attempt direct registry communication for same-machine sockets
      // We'll try to find a socket in the registry that matches this candidate's address and port
      bool sentViaRegistry = false;
      final allSockets = _P2PRegistry._sockets;
      
      for (final socketEntry in allSockets.entries) {
        final socket = socketEntry.value;
        // Check if this socket matches our candidate
        if (socket.discoveredPrivateIp == candidate.address && socket.localPort == candidate.port) {
          _P2PRegistry.sendToPeer(socketEntry.key, data, discoveredPrivateIp ?? '127.0.0.1', localPort ?? 0);
          sentAny = true;
          sentViaRegistry = true;
          print('Sent data via direct registry to peer: ${socketEntry.key} (${candidate.address}:${candidate.port})');
          break; // Found and sent to the target, continue to next candidate if any
        }
      }
      
      // If not sent via registry, try socket-based sending
      if (!sentViaRegistry) {
        try {
          _socket!.send(data, InternetAddress(candidate.address), candidate.port);
          sentAny = true;
          print('Sent data to remote candidate: ${candidate.address}:${candidate.port}');
        } catch (e) {
          print('Error sending to candidate ${candidate.address}:${candidate.port}: $e');
        }
      }
    }
    
    // If no remote candidates were available, try selected remote as fallback
    if (!sentAny && _selectedRemoteCandidate != null) {
      // Make sure it's not a STUN server
      if (_selectedRemoteCandidate!.port != 19302) {
        try {
          _socket!.send(data, InternetAddress(_selectedRemoteCandidate!.address), _selectedRemoteCandidate!.port);
          sentAny = true;
          print('Sent data to selected remote candidate: ${_selectedRemoteCandidate!.address}:${_selectedRemoteCandidate!.port}');
        } catch (e) {
          print('Error sending data to selected remote: $e');
        }
      }
    }
    
    // Also try sending to any addresses we've recently communicated with
    for (final contact in _lastSuccessfulContact.entries) {
      final parts = contact.key.split(':');
      if (parts.length == 2) {
        final address = parts[0];
        final port = int.tryParse(parts[1]);
        
        if (port != null && port != 19302) { // Don't send to STUN server
          try {
            bool alreadyTried = false;
            for (final candidate in _remoteCandidates) {
              if (candidate.address == address && candidate.port == port) {
                alreadyTried = true;
                break;
              }
            }
            
            if (!alreadyTried && 
                (_selectedRemoteCandidate == null || _selectedRemoteCandidate!.port == 19302)) {
              _socket!.send(data, InternetAddress(address), port);
              sentAny = true;
              print('Sent data to recent contact: $address:$port');
            }
          } catch (e) {
            print('Error sending to recent contact $address:$port: $e');
          }
        }
      }
    }
    
    if (!sentAny) {
      print('Warning: No candidates available to send data to');
    }
  }

  bool _isStunMessage(Uint8List data) {
    return data.length >= 20 && data[0] < 0x40;
  }

  Uint8List _buildStunMessage(int type, Uint8List transactionId, {Uint8List? payload}) {
    final payloadLength = payload?.length ?? 0;
    final builder = BytesBuilder();
    builder.add([(type >> 8) & 0xFF, type & 0xFF]);
    builder.add([(payloadLength >> 8) & 0xFF, payloadLength & 0xFF]);
    builder.add([0x21, 0x12, 0xA4, 0x42]); // Magic cookie
    builder.add(transactionId);
    if (payload != null) {
      builder.add(payload);
    }
    return builder.toBytes();
  }

  Uint8List _buildStunAttribute(int type, Uint8List value) {
    final builder = BytesBuilder();
    builder.add([(type >> 8) & 0xFF, type & 0xFF]);
    builder.add([(value.length >> 8) & 0xFF, value.length & 0xFF]);
    builder.add(value);
    return builder.toBytes();
  }

  bool _compareUint8Lists(Uint8List a, Uint8List b) {
    if (a.length != b.length) return false;
    for (var i = 0; i < a.length; i++) {
      if (a[i] != b[i]) return false;
    }
    return true;
  }

  Uint8List _generateTransactionId() {
    final random = Random();
    final bytes = Uint8List(12);
    for (var i = 0; i < 12; i++) {
      bytes[i] = random.nextInt(256);
    }
    return bytes;
  }

  void close() {
    _connectivityCheckTimer?.cancel();
    _socket?.close();
    _onCandidateController.close();
    _onMessageController.close();
    // Unregister this socket from the global registry
    _P2PRegistry.unregisterSocket(peerId);
  }
  
  // Method to handle direct messages from other sockets in the same process
  void _handleDirectMessage(Uint8List data, String senderAddress, int senderPort) {
    print('Received direct message from $senderAddress:$senderPort');
    // Check if it's from a known remote candidate
    bool isFromKnownPeer = false;
    
    for (final candidate in _remoteCandidates) {
      if (candidate.address == senderAddress && candidate.port == senderPort) {
        isFromKnownPeer = true;
        break;
      }
    }
    
    if (isFromKnownPeer) {
      _onMessageController.add(data);
      print('Direct message added to message stream from known peer: $senderAddress:$senderPort');
    } else {
      _onMessageController.add(data);
      print('Direct message added to message stream from: $senderAddress:$senderPort');
    }
  }

  // Methods for TURN server functionality
  /// Process incoming TURN requests when acting as a server
  Future<void> _handleTurnRequest(Datagram datagram) async {
    if (!enableTurnServer) return; // Only process if acting as server

    final messageType = (datagram.data[0] << 8) | datagram.data[1];
    
    switch (messageType) {
      case turnAllocateRequest:
        await _handleAllocateRequest(datagram);
        break;
      case 0x0004: // REFRESH request
        await _handleRefreshRequest(datagram);
        break;
      case 0x0006: // SEND indication
        await _handleSendIndication(datagram);
        break;
      case 0x0009: // DATA indication (sent by server)
        // This shouldn't come from client, but handle if needed
        break;
      default:
        // Send error response for unsupported methods
        await _sendErrorResponse(datagram, messageType, 400, 'Bad Request');
        break;
    }
  }

  /// Handle Allocate request from TURN client
  Future<void> _handleAllocateRequest(Datagram datagram) async {
    // Extract transaction ID
    final transactionId = datagram.data.sublist(8, 20);
    
    // Check if authentication is required
    final usernameAttr = _parseStunAttribute(datagram.data, attrUsername);
    if (usernameAttr == null) {
      // Send 401 Unauthorized error
      final errorResponse = _buildTurnErrorResponse(turnAllocateResponse, transactionId, 401, 'Unauthorized', 
        realm: 'p2p-turn-server', nonce: _generateNonce());
      _socket!.send(errorResponse, datagram.address, datagram.port);
      return;
    }
    
    // Create a relayed address for this allocation
    // In a real implementation, we would create an actual relay socket
    final relayAddress = InternetAddress.anyIPv4; // Use the same interface
    final relayPort = await _findAvailablePort(); // Find an available port
    
    // Create allocation
    final allocation = Allocation(
      clientAddress: datagram.address,
      clientPort: datagram.port,
      relayAddress: relayAddress,
      relayPort: relayPort,
      username: String.fromCharCodes(usernameAttr),
      expirationTime: DateTime.now().add(Duration(minutes: 10)), // 10 minute allocation
    );
    
    // Store allocation
    _allocations['${datagram.address.address}:${datagram.port}'] = allocation;
    
    // Build successful allocation response
    final response = _buildTurnAllocationSuccessResponse(transactionId, relayAddress.address, relayPort);
    _socket!.send(response, datagram.address, datagram.port);
    
    print('TURN allocation created: ${datagram.address.address}:${datagram.port} -> relay port $relayPort');
  }

  /// Generate an allocation success response
  Uint8List _buildTurnAllocationSuccessResponse(Uint8List transactionId, String relayAddress, int relayPort) {
    // Build XOR-relayed-address attribute
    final relayAddrBytes = InternetAddress(relayAddress).rawAddress;
    final xorPort = relayPort ^ ((0x21 << 8) | 0x12); // XOR with magic cookie bytes
    
    final relayAttrBytes = BytesBuilder();
    relayAttrBytes.add([0x00, 0x01]); // IPv4 family
    relayAttrBytes.add([(xorPort >> 8) & 0xFF, xorPort & 0xFF]); // XOR port
    for (int i = 0; i < relayAddrBytes.length; i++) {
      // XOR IP bytes with magic cookie
      relayAttrBytes.add([relayAddrBytes[i] ^ 0x21 ^ (i < 4 ? transactionId[i] : 0x12)]);
    }
    
    final relayAttr = _buildStunAttribute(attrRelayedAddress, relayAttrBytes.toBytes());
    
    // Build mapped address attribute (our server's address)
    final mappedAddrBytes = _socket!.address.rawAddress;
    final mappedPort = _socket!.port;
    final mappedXorPort = mappedPort ^ ((0x21 << 8) | 0x12);
    
    final mappedAttrBytes = BytesBuilder();
    mappedAttrBytes.add([0x00, 0x01]); // IPv4 family
    mappedAttrBytes.add([(mappedXorPort >> 8) & 0xFF, mappedXorPort & 0xFF]); // XOR port
    for (int i = 0; i < mappedAddrBytes.length; i++) {
      mappedAttrBytes.add([mappedAddrBytes[i] ^ 0x21]);
    }
    
    final mappedAttr = _buildStunAttribute(attrXorMappedAddress, mappedAttrBytes.toBytes());
    
    // Requested transport attribute
    final transportValue = Uint8List(4);
    transportValue[0] = udpTransport;
    final transportAttr = _buildStunAttribute(attrRequestedTransport, transportValue);
    
    // Lifetime attribute (default 600 seconds)
    final lifetimeValue = Uint8List(4);
    lifetimeValue[0] = 0x00;
    lifetimeValue[1] = 0x02;
    lifetimeValue[2] = 0x5B; // 600 in hex
    lifetimeValue[3] = 0xA0;
    final lifetimeAttr = _buildStunAttribute(attrLifetime, lifetimeValue);
    
    // Combine all attributes
    final payload = BytesBuilder();
    payload.add(relayAttr);
    payload.add(mappedAttr);
    payload.add(transportAttr);
    payload.add(lifetimeAttr);
    
    return _buildStunMessage(turnAllocateResponse, transactionId, payload: payload.toBytes());
  }

  /// Handle Refresh request to extend allocation lifetime
  Future<void> _handleRefreshRequest(Datagram datagram) async {
    // Extract transaction ID
    final transactionId = datagram.data.sublist(8, 20);
    
    // Check if an allocation exists for this client
    final clientKey = '${datagram.address.address}:${datagram.port}';
    if (!_allocations.containsKey(clientKey)) {
      await _sendErrorResponse(datagram, 0x0004, 437, 'Allocation does not exist');
      return;
    }
    
    // Extract lifetime from request (if present)
    final lifetimeAttr = _parseStunAttribute(datagram.data, attrLifetime);
    int newLifetime = 600; // Default 10 minutes
    if (lifetimeAttr != null && lifetimeAttr.length >= 4) {
      newLifetime = (lifetimeAttr[0] << 24) | (lifetimeAttr[1] << 16) | 
                   (lifetimeAttr[2] << 8) | lifetimeAttr[3];
    }
    
    // Update expiration time
    final allocation = _allocations[clientKey]!;
    allocation.expirationTime = DateTime.now().add(Duration(seconds: newLifetime));
    
    // Send success response
    final response = _buildRefreshSuccessResponse(transactionId, newLifetime);
    _socket!.send(response, datagram.address, datagram.port);
    
    print('Refreshed allocation for ${datagram.address}:${datagram.port}, new lifetime: $newLifetime seconds');
  }

  /// Build refresh success response
  Uint8List _buildRefreshSuccessResponse(Uint8List transactionId, int lifetime) {
    // Lifetime attribute
    final lifetimeValue = Uint8List(4);
    lifetimeValue[0] = (lifetime >> 24) & 0xFF;
    lifetimeValue[1] = (lifetime >> 16) & 0xFF;
    lifetimeValue[2] = (lifetime >> 8) & 0xFF;
    lifetimeValue[3] = lifetime & 0xFF;
    
    final lifetimeAttr = _buildStunAttribute(attrLifetime, lifetimeValue);
    
    return _buildStunMessage(0x0104, transactionId, payload: lifetimeAttr); // Refresh response
  }

  /// Handle Send Indication to relay data to another peer
  Future<void> _handleSendIndication(Datagram datagram) async {
    // Extract the data to forward and destination address
    final clientKey = '${datagram.address.address}:${datagram.port}';
    if (!_allocations.containsKey(clientKey)) {
      print('Send indication from unknown client: ${datagram.address}:${datagram.port}');
      return;
    }
    
    // Parse the peer address from DATA attribute
    final dataAttr = _parseStunAttribute(datagram.data, 0x0011); // DATA attribute
    if (dataAttr == null) {
      print('Send indication without data from: ${datagram.address}:${datagram.port}');
      return;
    }
    
    // In a real implementation, we would relay this data to the specified peer
    // For now, just log that we received the request
    print('Received send indication from ${datagram.address}:${datagram.port}, data length: ${dataAttr.length}');
  }

  /// Send error response
  Future<void> _sendErrorResponse(Datagram datagram, int originalMessageType, int errorCode, String reason) async {
    final transactionId = datagram.data.sublist(8, 20);
    final errorResponse = _buildTurnErrorResponse(originalMessageType + 0x100, transactionId, errorCode, reason);
    _socket!.send(errorResponse, datagram.address, datagram.port);
  }

  /// Build an error response for TURN
  Uint8List _buildTurnErrorResponse(int messageType, Uint8List transactionId, int errorCode, String reason, 
      {String? realm, String? nonce}) {
    // Error code attribute
    final errorCodeBytes = BytesBuilder();
    errorCodeBytes.add([0, (errorCode ~/ 100).abs()]); // Class (hundreds digit)
    errorCodeBytes.add([errorCode % 100]); // Number (last two digits)
    errorCodeBytes.add(reason.codeUnits); // Reason phrase
    
    final errorCodeAttr = _buildStunAttribute(attrErrorCode, errorCodeBytes.toBytes());
    
    // Realm attribute if provided
    List<int> realmAttr = [];
    if (realm != null) {
      realmAttr = _buildStunAttribute(attrRealm, Uint8List.fromList(realm.codeUnits)).toList();
    }
    
    // Nonce attribute if provided
    List<int> nonceAttr = [];
    if (nonce != null) {
      nonceAttr = _buildStunAttribute(attrNonce, Uint8List.fromList(nonce.codeUnits)).toList();
    }
    
    // Combine attributes
    final payload = BytesBuilder();
    payload.add(errorCodeAttr);
    if (realmAttr.isNotEmpty) payload.add(realmAttr);
    if (nonceAttr.isNotEmpty) payload.add(nonceAttr);
    
    return _buildStunMessage(messageType, transactionId, payload: payload.toBytes());
  }

  /// Generate a nonce for authentication
  String _generateNonce() {
    final random = Random.secure();
    final nonceBytes = List<int>.generate(16, (i) => random.nextInt(256));
    return base64Encode(Uint8List.fromList(nonceBytes));
  }

  /// Find an available port (simplified version)
  Future<int> _findAvailablePort() async {
    // In a real implementation, we'd create a socket on port 0 to get an available port
    // For now, we'll return a random port in the ephemeral range
    final random = Random();
    return 49152 + random.nextInt(128); // Common ephemeral port range
  }

  /// Check if this is a TURN message
  bool _isTurnMessage(Uint8List data) {
    if (data.length < 20) return false;
    final type = (data[0] << 8) | data[1];
    // TURN messages have specific method values in the range
    return type == turnAllocateRequest || 
           type == 0x0004 ||  // Refresh
           type == 0x0006 ||  // Send
           type == 0x0009 ||  // Data
           type == turnAllocateResponse; // TURN responses
  }
}

/// Represents a TURN allocation
class Allocation {
  InternetAddress clientAddress;
  int clientPort;
  InternetAddress relayAddress;
  int relayPort;
  String username;
  DateTime expirationTime;
  
  Allocation({
    required this.clientAddress,
    required this.clientPort,
    required this.relayAddress,
    required this.relayPort,
    required this.username,
    required this.expirationTime,
  });
}

/// Represents a TURN permission (for access control)
class Permission {
  InternetAddress peerAddress;
  DateTime expirationTime;
  
  Permission({
    required this.peerAddress,
    required this.expirationTime,
  });
}

/// Represents a TURN channel binding
class Channel {
  int channelNumber;
  InternetAddress peerAddress;
  int peerPort;
  DateTime expirationTime;
  
  Channel({
    required this.channelNumber,
    required this.peerAddress,
    required this.peerPort,
    required this.expirationTime,
  });
}