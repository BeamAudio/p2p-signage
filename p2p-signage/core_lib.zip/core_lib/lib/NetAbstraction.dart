import 'dart:convert';
import 'dart:io';
import 'dart:async';
import 'dart:typed_data';
import 'package:crypto/crypto.dart';
import 'p2p_socket.dart';

enum MessageType {
  playlist,
  mediaFileRequest,
  mediaFileChunk,
  playlistInfo,
}

class NetworkMessage {
  final MessageType type;
  final dynamic payload;

  NetworkMessage(this.type, this.payload);

  Map<String, dynamic> toJson() => {'type': type.index, 'payload': payload};

  factory NetworkMessage.fromJson(Map<String, dynamic> json) =>
      NetworkMessage(MessageType.values[json['type']], json['payload']);
}

class Playlist {
  final String id;
  final String name;
  final List<String> mediaFileIds;

  Playlist({required this.id, required this.name, required this.mediaFileIds});

  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'mediaFileIds': mediaFileIds};

  factory Playlist.fromJson(Map<String, dynamic> json) =>
      Playlist(id: json['id'], name: json['name'], mediaFileIds: List<String>.from(json['mediaFileIds']));
}

class MediaFileInfo {
  final String id;
  final String checksum;

  MediaFileInfo({required this.id, required this.checksum});

  Map<String, dynamic> toJson() => {'id': id, 'checksum': checksum};

  factory MediaFileInfo.fromJson(Map<String, dynamic> json) =>
      MediaFileInfo(id: json['id'], checksum: json['checksum']);
}

class NetAbstraction {
  final P2PSocket _socket;
  final Map<String, String> _localFileChecksums = {}; // fileId -> checksum

  final _onPlaylistController = StreamController<Playlist>.broadcast();
  Stream<Playlist> get onPlaylist => _onPlaylistController.stream;

  NetAbstraction(this._socket) {
    _socket.onMessage.listen(_handleMessage);
  }

  void _handleMessage(Uint8List data) {
    try {
      final message = NetworkMessage.fromJson(jsonDecode(String.fromCharCodes(data)));
      switch (message.type) {
        case MessageType.playlistInfo:
          final playlistId = message.payload['id'];
          final mediaFiles = (message.payload['files'] as List).map((f) => MediaFileInfo.fromJson(f)).toList();
          _requestMissingFiles(playlistId, mediaFiles);
          break;
        case MessageType.playlist:
          _onPlaylistController.add(Playlist.fromJson(message.payload));
          break;
        // Handle other message types like mediaFileChunk
        default:
          break;
      }
    } catch (e) {
      print('Error handling message: $e');
    }
  }

  void _requestMissingFiles(String playlistId, List<MediaFileInfo> files) {
    final missingFiles = <String>[];
    for (final fileInfo in files) {
      if (_localFileChecksums[fileInfo.id] != fileInfo.checksum) {
        missingFiles.add(fileInfo.id);
      }
    }
    // In a real app, you would request the full playlist and the missing files.
  }

  Future<void> sendPlaylist(Playlist playlist, Map<String, File> mediaFiles) async {
    final fileInfos = <MediaFileInfo>[];
    for (final fileId in playlist.mediaFileIds) {
      final file = mediaFiles[fileId];
      if (file != null) {
        final checksum = await _calculateChecksum(file);
        fileInfos.add(MediaFileInfo(id: fileId, checksum: checksum));
      }
    }

    final message = NetworkMessage(MessageType.playlistInfo, {
      'id': playlist.id,
      'files': fileInfos.map((f) => f.toJson()).toList(),
    });
    _socket.send(Uint8List.fromList(jsonEncode(message.toJson()).codeUnits));
  }

  Future<String> _calculateChecksum(File file) async {
    final bytes = await file.readAsBytes();
    return sha256.convert(bytes).toString();
  }

  void close() {
    _onPlaylistController.close();
  }
}