import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:core_lib/p2p_socket.dart';

void main() {
  group('P2PSocket Stress Test - Multiple Instances', () {
    test('Create and manage multiple P2PSocket instances simultaneously', () async {
      const numInstances = 5; // Reduced number to avoid resource exhaustion
      final sockets = <P2PSocket>[];
      
      // Create multiple instances
      for (int i = 0; i < numInstances; i++) {
        final socket = P2PSocket(
          peerId: 'stress_test_$i',
        );
        sockets.add(socket);
        
        // Start gathering candidates to initialize sockets
        await socket.gatherCandidates().timeout(Duration(seconds: 5), 
          onTimeout: () => Future.value());
        
        // Add a delay to ensure each socket gets a unique port
        await Future.delayed(Duration(milliseconds: 100));
        
        print('Created socket $i');
      }
      
      // Verify all instances were created successfully
      expect(sockets.length, numInstances);
      
      // Close all sockets
      for (final socket in sockets) {
        socket.close();
      }
      
      print('Successfully created and closed $numInstances socket instances');
    }, timeout: Timeout(Duration(seconds: 30)));
    
    test('Test resource usage with multiple instances', () async {
      const numInstances = 8; // Reduced to avoid resource exhaustion
      final sockets = <P2PSocket>[];
      
      final stopwatch = Stopwatch()..start();
      
      // Create all instances
      for (int i = 0; i < numInstances; i++) {
        final socket = P2PSocket(
          peerId: 'resource_test_$i',
        );
        sockets.add(socket);
        
        // Start gathering candidates to initialize sockets
        await socket.gatherCandidates().timeout(Duration(seconds: 5), 
          onTimeout: () => Future.value());
        
        print('Initialized socket $i');
      }
      
      stopwatch.stop();
      print('Time to create $numInstances instances: ${stopwatch.elapsed}');
      
      // Verify all instances were created
      expect(sockets.length, numInstances);
      
      // Check for any error messages or failed initializations
      int successfulInitializations = 0;
      for (final socket in sockets) {
        // We can't access the internal socket directly, but we can try to use it
        try {
          final message = Uint8List.fromList('test'.codeUnits);
          socket.send(message);
          successfulInitializations++;
        } catch (e) {
          print('Error using socket: $e');
        }
      }
      
      print('Successfully initialized $successfulInitializations out of $numInstances instances');
      
      // Close all sockets
      stopwatch.start();
      for (final socket in sockets) {
        socket.close();
      }
      stopwatch.stop();
      
      print('Time to close $numInstances instances: ${stopwatch.elapsed}');
    }, timeout: Timeout(Duration(seconds: 40)));
    
    test('Test candidate generation under stress', () async {
      const numInstances = 10; // Reduced to avoid resource exhaustion
      final sockets = <P2PSocket>[];
      final allCandidates = <List<IceCandidate>>[];
      
      // Initialize lists to track candidates for each socket
      for (int i = 0; i < numInstances; i++) {
        allCandidates.add([]);
      }
      
      // Create and set up all sockets
      for (int i = 0; i < numInstances; i++) {
        final socket = P2PSocket(
          peerId: 'candidate_stress_$i',
        );
        sockets.add(socket);
        
        // Listen for candidates on each socket
        socket.onCandidate.listen((candidate) {
          allCandidates[i].add(candidate);
          print('Socket $i received candidate: ${candidate.type} - ${candidate.address}:${candidate.port}');
        });
      }
      
      // Start candidate gathering for all sockets simultaneously
      final futures = <Future>[];
      for (final socket in sockets) {
        futures.add(socket.gatherCandidates().timeout(Duration(seconds: 10), 
          onTimeout: () => Future.value()));
      }
      
      // Wait for all to complete (with timeout)
      try {
        await Future.wait(futures, eagerError: true);
      } catch (e) {
        print('Some candidate gathering timed out (expected in stress test): $e');
      }
      
      // Wait a bit more to collect all possible candidates
      await Future.delayed(Duration(seconds: 3));
      
      // Verify each socket gathered at least a host candidate
      int socketsWithCandidates = 0;
      for (int i = 0; i < numInstances; i++) {
        if (allCandidates[i].isNotEmpty) {
          socketsWithCandidates++;
          print('Socket $i gathered ${allCandidates[i].length} candidates');
        } else {
          print('Socket $i gathered no candidates');
        }
      }
      
      print('Sockets with candidates: $socketsWithCandidates out of $numInstances');
      expect(socketsWithCandidates, greaterThan(0)); // At least some should succeed
      
      // Close all sockets
      for (final socket in sockets) {
        socket.close();
      }
    }, timeout: Timeout(Duration(seconds: 40)));
  });
}