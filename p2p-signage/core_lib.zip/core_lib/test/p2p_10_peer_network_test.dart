import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:core_lib/p2p_socket.dart';

void main() {
  group('P2PSocket 10-Peer Network Test', () {
    test('Test 10-peer network with distributed routing table', () async {
      print('=== 10-Peer Network with Distributed Routing Table ===');
      
      // Create 10 P2PSocket instances
      final peers = <P2PSocket>[];
      final peerIds = <String>[];
      
      for (int i = 0; i < 10; i++) {
        final peerId = 'peer_${i.toString().padLeft(2, '0')}';
        peerIds.add(peerId);
        final peer = P2PSocket(
          peerId: peerId,
        );
        peers.add(peer);
      }
      
      print('Created ${peers.length} peer sockets');
      
      // Start gathering candidates for all peers
      print('Starting IP discovery for all peers...');
      final futures = <Future>[];
      for (final peer in peers) {
        futures.add(peer.gatherCandidates());
      }
      
      try {
        await Future.wait(futures, eagerError: true).timeout(Duration(seconds: 15));
      } catch (e) {
        print('Some peers had timeout during candidate gathering: $e');
        // Continue with what we have
      }
      
      // Wait for IP discovery to complete
      await Future.delayed(Duration(seconds: 3));
      
      // Print discovered information for each peer
      print('\\nDiscovered information for all peers:');
      for (int i = 0; i < peers.length; i++) {
        print('  Peer ${i.toString().padLeft(2)}: IP=${peers[i].discoveredPrivateIp}, Port=${peers[i].localPort}, PublicIP=${peers[i].publicIp}');
      }
      
      // Establish initial pairwise connections - connect each peer to the next one
      print('\\nEstablishing initial pairwise connections...');
      for (int i = 0; i < peers.length - 1; i++) {
        final currentPeer = peers[i];
        final nextPeer = peers[i + 1];
        
        // Exchange information between current and next peer
        if (nextPeer.discoveredPrivateIp != null && nextPeer.localPort != null) {
          final nextPeerInfo = IceCandidate(
            'network',
            nextPeer.discoveredPrivateIp!,  // Next peer's IP
            nextPeer.localPort!,            // Next peer's port
            140,
            foundation: 'network_init'
          );
          currentPeer.addRemoteCandidate(nextPeerInfo);
          print('Added Peer ${i+1} (${nextPeer.discoveredPrivateIp}:${nextPeer.localPort}) to Peer $i');
        }
        
        if (currentPeer.discoveredPrivateIp != null && currentPeer.localPort != null) {
          final currentPeerInfo = IceCandidate(
            'network',
            currentPeer.discoveredPrivateIp!, // Current peer's IP
            currentPeer.localPort!,           // Current peer's port
            140,
            foundation: 'network_init'
          );
          nextPeer.addRemoteCandidate(currentPeerInfo);
          print('Added Peer $i (${currentPeer.discoveredPrivateIp}:${currentPeer.localPort}) to Peer ${i+1}');
        }
      }
      
      // Also connect the first and last peer to create a circular network for better connectivity
      final firstPeer = peers[0];
      final lastPeer = peers[peers.length - 1];
      
      if (firstPeer.discoveredPrivateIp != null && firstPeer.localPort != null) {
        final firstPeerInfo = IceCandidate(
          'network',
          firstPeer.discoveredPrivateIp!,
          firstPeer.localPort!,
          140,
          foundation: 'network_init'
        );
        lastPeer.addRemoteCandidate(firstPeerInfo);
        print('Added Peer 0 (${firstPeer.discoveredPrivateIp}:${firstPeer.localPort}) to Peer ${peers.length - 1}');
      }
      
      if (lastPeer.discoveredPrivateIp != null && lastPeer.localPort != null) {
        final lastPeerInfo = IceCandidate(
          'network',
          lastPeer.discoveredPrivateIp!,
          lastPeer.localPort!,
          140,
          foundation: 'network_init'
        );
        firstPeer.addRemoteCandidate(lastPeerInfo);
        print('Added Peer ${peers.length - 1} (${lastPeer.discoveredPrivateIp}:${lastPeer.localPort}) to Peer 0');
      }
      
      print('\\nInitial pairwise connections established.');
      
      // Wait for initial communication to propagate network information
      await Future.delayed(Duration(seconds: 5));
      
      // Send network discovery messages to propagate routing information
      print('\\nSending network discovery messages...');
      for (int i = 0; i < peers.length; i++) {
        // Each peer sends its own network information to all its known peers
        final peer = peers[i];
        final networkInfo = {
          'from': peer.peerId,
          'ip': peer.discoveredPrivateIp,
          'port': peer.localPort,
          'type': 'network_discovery'
        };
        
        final message = 'NET: ${jsonEncode(networkInfo)}';
        peer.send(Uint8List.fromList(message.codeUnits));
      }
      
      // Wait for network information to propagate through the routing table
      print('Waiting for network information to propagate...');
      await Future.delayed(Duration(seconds: 8));
      
      // Send more messages to ensure routing table is updated
      for (int i = 0; i < peers.length; i++) {
        // Send a second round of messages
        final peer = peers[i];
        final networkInfo = {
          'from': peer.peerId,
          'ip': peer.discoveredPrivateIp,
          'port': peer.localPort,
          'type': 'network_discovery_2'
        };
        
        final message = 'NET2: ${jsonEncode(networkInfo)}';
        peer.send(Uint8List.fromList(message.codeUnits));
      }
      
      await Future.delayed(Duration(seconds: 8));
      
      // Now check how many other peers each peer knows about through message reception
      print('\\nFinal network state analysis:');
      
      // We'll track message reception to understand network connectivity
      final messageTracker = <String, List<String>>{};  // peerId -> list of messages received
      
      // Set up message tracking for each peer
      for (int i = 0; i < peers.length; i++) {
        final peerId = peers[i].peerId;
        messageTracker[peerId] = <String>[];
        
        peers[i].onMessage.listen((data) {
          final message = String.fromCharCodes(data);
          if (message.startsWith('NET:') || message.startsWith('NET2:')) {
            if (!messageTracker[peerId]!.contains(message)) {
              messageTracker[peerId]!.add(message);
              // Don't print every message to avoid spam
            }
          }
        });
      }
      
      await Future.delayed(Duration(seconds: 3));
      
      // Count how many unique network messages each peer received
      var totalReceivedMessages = 0;
      var fullyConnectedPeers = 0;
      
      for (int i = 0; i < peers.length; i++) {
        final peer = peers[i];
        final receivedMessagesCount = messageTracker[peer.peerId]?.length ?? 0;
        print('  Peer $i (${peer.peerId}) received $receivedMessagesCount network messages');
        
        totalReceivedMessages += receivedMessagesCount;
        
        // If a peer received messages from at least 8 other peers (9 total with itself), consider it well-connected
        // Each peer sends 2 messages, so if peer received 16+ messages it likely received from 8+ other peers
        if (receivedMessagesCount >= 8) { // Adjusted this threshold appropriately
          fullyConnectedPeers++;
        }
      }
      
      print('\\nNetwork Statistics:');
      print('  Total peers in network: ${peers.length}');
      print('  Total received network messages: $totalReceivedMessages');
      print('  Average messages per peer: ${(totalReceivedMessages / peers.length).toStringAsFixed(2)}');
      print('  Well-connected peers (received 8+ messages): $fullyConnectedPeers out of ${peers.length}');
      
      // Calculate network density based on messages received
      final expectedTotalMessages = (peers.length - 1) * peers.length; // Each peer sends 2 messages, received by 9 others
      final networkDensity = expectedTotalMessages > 0 ? (totalReceivedMessages / expectedTotalMessages * 100) : 0;
      print('  Network message propagation: ${networkDensity.toStringAsFixed(2)}%');
      
      // Send a final test message from first peer to see if it reaches others
      print('\\nSending final test message from Peer 0 to network...');
      final messagesReceived = <int>[];
      final Completer<void> allMessagesCompleter = Completer<void>();
      
      // Set up listeners for final test message
      for (int i = 1; i < peers.length; i++) { // Start from 1 since sender is 0
        final targetIndex = i;
        peers[i].onMessage.listen((data) {
          final message = String.fromCharCodes(data);
          if (message.contains('FINAL_TEST_MSG')) {
            if (!messagesReceived.contains(targetIndex)) {
              messagesReceived.add(targetIndex);
              print('  Final message received by Peer $targetIndex');
            }
            
            // Complete when all peers received the message (or when we're close)
            if (messagesReceived.length >= peers.length - 1) { // -1 because sender doesn't receive its own message
              if (!allMessagesCompleter.isCompleted) {
                allMessagesCompleter.complete();
              }
            }
          }
        });
      }
      
      // Send the final test message
      final finalMessage = 'FINAL_TEST_MSG from ${peers[0].peerId}';
      peers[0].send(Uint8List.fromList(finalMessage.codeUnits));
      
      // Wait for final message to propagate or timeout
      try {
        await allMessagesCompleter.future.timeout(Duration(seconds: 10));
        print('All peers received the final test message');
      } catch (e) {
        print('Timeout waiting for all peers to receive final message, received by ${messagesReceived.length}/${peers.length - 1} peers');
      }
      
      print('\\nFinal Results:');
      print('  Peers that received final test message: ${messagesReceived.length}/${peers.length - 1}');
      
      // Close all peers
      for (final peer in peers) {
        peer.close();
      }
      
      print('\\n10-Peer network test completed successfully!');
    }, timeout: Timeout(Duration(seconds: 60)));
  });
}