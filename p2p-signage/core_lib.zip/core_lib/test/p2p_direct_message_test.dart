import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:core_lib/p2p_socket.dart';

void main() {
  group('P2PSocket Direct Message Test', () {
    test('Test sending messages without established connection', () async {
      print('=== Testing Direct Messages ===');
      
      // Create two P2PSocket instances
      final sender = P2PSocket(
        peerId: 'sender',
      );
      
      final receiver = P2PSocket(
        peerId: 'receiver',
      );
      
      // Wait for IP discovery
      await Future.wait([
        sender.gatherCandidates(),
        receiver.gatherCandidates()
      ]).timeout(Duration(seconds: 10), onTimeout: () => [Future.value(), Future.value()]);
      
      await Future.delayed(Duration(seconds: 3));
      
      print('Sender IP: ${sender.discoveredPrivateIp}, Port: ${sender.localPort}');
      print('Receiver IP: ${receiver.discoveredPrivateIp}, Port: ${receiver.localPort}');
      
      // Add receiver's address as a remote candidate to the sender
      final receiverInfo = IceCandidate(
        'direct',
        receiver.discoveredPrivateIp!,  // Use receiver's IP
        receiver.localPort!,            // Use receiver's port
        140,
        foundation: 'direct_test'
      );
      sender.addRemoteCandidate(receiverInfo);
      print('Added receiver (${receiver.discoveredPrivateIp}:${receiver.localPort}) to sender');
      
      // Add sender's address as a remote candidate to the receiver
      final senderInfo = IceCandidate(
        'direct',
        sender.discoveredPrivateIp!,    // Use sender's IP
        sender.localPort!,              // Use sender's port
        140,
        foundation: 'direct_test'
      );
      receiver.addRemoteCandidate(senderInfo);
      print('Added sender (${sender.discoveredPrivateIp}:${sender.localPort}) to receiver');
      
      // Track all messages received by both parties
      final senderReceived = <String>[];
      final receiverReceived = <String>[];
      
      sender.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        if (message.startsWith('MSG:')) {
          senderReceived.add(message);
          print('Sender received: $message');
        }
      });
      
      receiver.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        if (message.startsWith('MSG:')) {
          receiverReceived.add(message);
          print('Receiver received: $message');
        }
      });
      
      await Future.delayed(Duration(seconds: 3));
      
      // Send messages from both ends now
      print('\\nSending messages...');
      sender.send(Uint8List.fromList('MSG: Hello from sender'.codeUnits));
      receiver.send(Uint8List.fromList('MSG: Hello from receiver'.codeUnits));
      
      await Future.delayed(Duration(seconds: 2));
      
      // Send more messages
      sender.send(Uint8List.fromList('MSG: Second message from sender'.codeUnits));
      receiver.send(Uint8List.fromList('MSG: Second message from receiver'.codeUnits));
      
      await Future.delayed(Duration(seconds: 3));
      
      print('\\nResults:');
      print('Sender received ${senderReceived.length} messages: $senderReceived');
      print('Receiver received ${receiverReceived.length} messages: $receiverReceived');
      
      // Close sockets
      sender.close();
      receiver.close();
    }, timeout: Timeout(Duration(seconds: 30)));
  });
}