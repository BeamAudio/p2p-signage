import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:core_lib/p2p_socket.dart';

void main() {
  group('P2PSocket Real IP Test', () {
    test('Test using actual public IP addresses', () async {
      // Use dynamically discovered IP addresses
      final socketA = P2PSocket(
        peerId: 'device_a',
      );
      
      final socketB = P2PSocket(
        peerId: 'device_b',
      );
      
      // Wait for IP discovery
      await Future.delayed(Duration(seconds: 3));
      
      // Use the discovered public IPs or fallback to local IPs
      final socketAIP = socketA.publicIp ?? (socketA.localIps.isNotEmpty ? socketA.localIps[0].address : '127.0.0.1');
      final socketBIP = socketB.publicIp ?? (socketB.localIps.isNotEmpty ? socketB.localIps[0].address : '127.0.0.1');
      final commonPortA = 8080;  // Use common port for communication
      final commonPortB = 8081;  // Use common port for communication
      
      var messageReceivedA = false;
      var messageReceivedB = false;
      var connectionEstablishedA = false;
      var connectionEstablishedB = false;
      
      // Listen for messages and connection establishment
      socketA.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        if (message == 'Connection established!') {
          connectionEstablishedA = true;
          print('Device A: Connection established');
        } else {
          print('Device A received: $message');
          messageReceivedA = true;
        }
      });
      
      socketB.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        if (message == 'Connection established!') {
          connectionEstablishedB = true;
          print('Device B: Connection established');
        } else {
          print('Device B received: $message');
          messageReceivedB = true;
        }
      });
      
      // Set up candidate exchange using the discovered public IPs
      socketA.onCandidate.listen((candidate) {
        print('Device A candidate: ${candidate.type} ${candidate.address}:${candidate.port}');
        // Add the candidate to the other socket
        socketB.addRemoteCandidate(candidate);
      });
      
      socketB.onCandidate.listen((candidate) {
        print('Device B candidate: ${candidate.type} ${candidate.address}:${candidate.port}');
        // Add the candidate to the other socket
        socketA.addRemoteCandidate(candidate);
      });
      
      // Start gathering candidates
      await Future.wait([
        socketA.gatherCandidates(),
        socketB.gatherCandidates()
      ]).timeout(Duration(seconds: 10), onTimeout: () => [Future.value(), Future.value()]);
      
      // Exchange the discovered IPs as manual candidates
      final aPublicCandidate = IceCandidate(
        'discovered', 
        socketAIP, 
        commonPortA,
        150,  // High priority for discovered IPs
        foundation: 'discovered_device'
      );
      socketB.addRemoteCandidate(aPublicCandidate);
      print('Added Node A ($socketAIP:$commonPortA) to Node B');
      
      final bPublicCandidate = IceCandidate(
        'discovered', 
        socketBIP, 
        commonPortB,
        150,  // High priority for discovered IPs
        foundation: 'discovered_device'
      );
      socketA.addRemoteCandidate(bPublicCandidate);
      print('Added Node B ($socketBIP:$commonPortB) to Node A');
      
      await Future.delayed(Duration(seconds: 3));
      
      // Send test messages
      socketA.send(Uint8List.fromList('Hello from device A'.codeUnits));
      socketB.send(Uint8List.fromList('Hello from device B'.codeUnits));
      
      await Future.delayed(Duration(seconds: 3));
      
      print('Results:');
      print('  A connection established: $connectionEstablishedA');
      print('  B connection established: $connectionEstablishedB');
      print('  A received message: $messageReceivedA');
      print('  B received message: $messageReceivedB');
      
      socketA.close();
      socketB.close();
    }, timeout: Timeout(Duration(seconds: 40)));
    
    test('Test with mixed IP types for network setup', () async {
      // Simulate the technician setup scenario with discovered IPs
      final masterSocket = P2PSocket(
        peerId: 'master',
      );
      
      final clientSocket = P2PSocket(
        peerId: 'client',
      );
      
      // Wait for IP discovery
      await Future.delayed(Duration(seconds: 3));
      
      // Use the discovered public IPs or fallback to local IPs
      final masterIP = masterSocket.publicIp ?? (masterSocket.localIps.isNotEmpty ? masterSocket.localIps[0].address : '127.0.0.1');
      final clientIP = clientSocket.publicIp ?? (clientSocket.localIps.isNotEmpty ? clientSocket.localIps[0].address : '127.0.0.1');
      final commonPortMaster = 8080;  // Use common port for communication
      final commonPortClient = 8081;  // Use common port for communication
      
      // Track messages
      final receivedMessages = <String>[];
      
      masterSocket.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        if (message != 'Connection established!') {
          receivedMessages.add('Master received: $message');
          print('Master received: $message');
        }
      });
      
      clientSocket.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        if (message != 'Connection established!') {
          receivedMessages.add('Client received: $message');
          print('Client received: $message');
        }
      });
      
      // Simulate the distributed routing table mechanism
      // Each device knows the discovered public IPs of others
      final masterCandidate = IceCandidate('discovered', masterIP, commonPortMaster, 150, foundation: 'discovered');
      final clientCandidate = IceCandidate('discovered', clientIP, commonPortClient, 150, foundation: 'discovered');
      
      masterSocket.addRemoteCandidate(clientCandidate);
      clientSocket.addRemoteCandidate(masterCandidate);
      
      await Future.delayed(Duration(seconds: 2));
      
      // Send messages between devices
      masterSocket.send(Uint8List.fromList('Message from master'.codeUnits));
      clientSocket.send(Uint8List.fromList('Message from client'.codeUnits));
      
      await Future.delayed(Duration(seconds: 3));
      
      print('Total messages exchanged: ${receivedMessages.length}');
      for (final msg in receivedMessages) {
        print('  $msg');
      }
      
      masterSocket.close();
      clientSocket.close();
    }, timeout: Timeout(Duration(seconds: 40)));
  });
}