import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:crypto/crypto.dart';
import 'package:core_lib/p2p_socket.dart';

void main() {
  group('P2PSocket Advanced Stress Test Suite', () {
    test('Advanced stress test with multiple network topologies', () async {
      print('=== Advanced Stress Test with Multiple Network Topologies ===');
      
      // Create multiple P2PSocket instances for stress testing
      final devices = <P2PSocket>[];
      
      // Create 10 devices representing different network roles
      for (int i = 0; i < 10; i++) {
        final device = P2PSocket(
          peerId: 'advanced_device_${i.toString().padLeft(2, '0')}',
        );
        devices.add(device);
      }
      
      print('Created ${devices.length} devices for advanced stress test');
      
      // Start IP discovery for all devices
      print('Starting IP discovery for all devices...');
      final futures = <Future>[];
      for (final device in devices) {
        futures.add(device.gatherCandidates());
      }
      
      try {
        await Future.wait(futures).timeout(Duration(seconds: 20), onTimeout: () => [Future.value(), Future.value(), Future.value(), Future.value(), Future.value(), Future.value(), Future.value(), Future.value(), Future.value(), Future.value()]);
      } catch (e) {
        print('Some devices had timeout during candidate gathering: $e');
      }
      
      await Future.delayed(Duration(seconds: 3));
      
      // Print discovered IPs for all devices
      print('\\nDiscovered device IPs:');
      for (int i = 0; i < devices.length; i++) {
        final device = devices[i];
        print('  Device ${i.toString().padLeft(2)} (${device.peerId}):');
        print('    Private IP: ${device.discoveredPrivateIp}');
        print('    Port: ${device.localPort}');
        print('    Public IP: ${device.publicIp}');
        print('    Local IPs: ${device.localIps.map((ip) => ip.address).join(', ')}');
      }
      
      // Verify your specific IP (192.168.0.15) is discovered
      bool yourIpFound = false;
      for (final device in devices) {
        if (device.localIps.any((ip) => ip.address == '192.168.0.15')) {
          yourIpFound = true;
          break;
        }
      }
      
      print('\\nYour specific IP (192.168.0.15) discovered: ${yourIpFound ? '✅ YES' : '❌ NO'}');
      
      // Set up complex network topology
      print('\\nSetting up complex network topology...');
      
      // Create a star topology with device 0 as hub
      final hubDevice = devices[0];
      print('  Star Hub: Device 00 (${hubDevice.peerId})');
      
      for (int i = 1; i < 4; i++) { // Connect devices 1-3 to hub
        final spokeDevice = devices[i];
        if (spokeDevice.discoveredPrivateIp != null && spokeDevice.localPort != null) {
          final spokeCandidate = IceCandidate(
            'star_topology',
            spokeDevice.discoveredPrivateIp!,
            spokeDevice.localPort!,
            150 - i, // Priority
            foundation: 'star_spoke_${i.toString().padLeft(2, '0')}'
          );
          hubDevice.addRemoteCandidate(spokeCandidate);
          print('    Connected Spoke Device ${i.toString().padLeft(2)} to Hub (${spokeDevice.discoveredPrivateIp}:${spokeDevice.localPort})');
        }
        
        if (hubDevice.discoveredPrivateIp != null && hubDevice.localPort != null) {
          final hubCandidate = IceCandidate(
            'star_topology',
            hubDevice.discoveredPrivateIp!,
            hubDevice.localPort!,
            150, // Priority
            foundation: 'star_hub_00'
          );
          spokeDevice.addRemoteCandidate(hubCandidate);
          print('    Connected Hub to Spoke Device ${i.toString().padLeft(2)} (${hubDevice.discoveredPrivateIp}:${hubDevice.localPort})');
        }
      }
      
      // Create a ring topology with devices 4-6
      print('\\n  Ring Topology: Devices 04-06');
      for (int i = 4; i <= 6; i++) {
        final currentDevice = devices[i];
        final nextDeviceIndex = (i + 1) > 6 ? 4 : (i + 1);
        final nextDevice = devices[nextDeviceIndex];
        
        if (nextDevice.discoveredPrivateIp != null && nextDevice.localPort != null) {
          final nextCandidate = IceCandidate(
            'ring_topology',
            nextDevice.discoveredPrivateIp!,
            nextDevice.localPort!,
            140, // Priority
            foundation: 'ring_${nextDeviceIndex.toString().padLeft(2, '0')}'
          );
          currentDevice.addRemoteCandidate(nextCandidate);
          print('    Connected Device ${i.toString().padLeft(2)} to Device ${nextDeviceIndex.toString().padLeft(2)} (${nextDevice.discoveredPrivateIp}:${nextDevice.localPort})');
        }
      }
      
      // Create a mesh topology with devices 7-9
      print('\\n  Mesh Topology: Devices 07-09');
      for (int i = 7; i <= 9; i++) {
        final currentDevice = devices[i];
        
        for (int j = 7; j <= 9; j++) {
          if (i != j) {
            final targetDevice = devices[j];
            
            if (targetDevice.discoveredPrivateIp != null && targetDevice.localPort != null) {
              final targetCandidate = IceCandidate(
                'mesh_topology',
                targetDevice.discoveredPrivateIp!,
                targetDevice.localPort!,
                130, // Priority
                foundation: 'mesh_${j.toString().padLeft(2, '0')}'
              );
              currentDevice.addRemoteCandidate(targetCandidate);
              print('    Connected Device ${i.toString().padLeft(2)} to Device ${j.toString().padLeft(2)} (${targetDevice.discoveredPrivateIp}:${targetDevice.localPort})');
            }
          }
        }
      }
      
      await Future.delayed(Duration(seconds: 2));
      
      // Set up message tracking
      print('\\nSetting up advanced message tracking...');
      
      final deviceMessages = List.generate(devices.length, (_) => <String>[]);
      final deviceMessageSizes = List.generate(devices.length, (_) => <int>[]);
      final deviceIntegrityResults = List.generate(devices.length, (_) => <bool>[]);
      
      for (int i = 0; i < devices.length; i++) {
        final deviceIndex = i;
        devices[i].onMessage.listen((data) {
          final message = String.fromCharCodes(data);
          deviceMessages[deviceIndex].add(message);
          deviceMessageSizes[deviceIndex].add(data.length);
          
          // Verify integrity for test messages
          if (message.contains('"integrity_test":true')) {
            try {
              final jsonData = jsonDecode(message) as Map<String, dynamic>;
              final receivedChecksum = jsonData['checksum'] as String;
              final payload = base64Decode(jsonData['payload'] as String);
              final calculatedChecksum = sha256.convert(payload).toString();
              
              final integrityOk = receivedChecksum == calculatedChecksum;
              deviceIntegrityResults[deviceIndex].add(integrityOk);
              
              if (deviceMessages[deviceIndex].length % 25 == 0) {
                print('  Device ${deviceIndex.toString().padLeft(2)} received integrity test message (${payload.length} bytes), integrity: ${integrityOk ? '✅ OK' : '❌ FAILED'}');
              }
            } catch (e) {
              deviceIntegrityResults[deviceIndex].add(false);
              print('  Device ${deviceIndex.toString().padLeft(2)} received malformed message: $e');
            }
          } else {
            deviceIntegrityResults[deviceIndex].add(true); // Non-test messages are considered valid
          }
        });
      }
      
      await Future.delayed(Duration(seconds: 2));
      
      // Generate advanced stress test data
      print('\\n=== Generating Advanced Stress Test Data ===');
      
      // Create data chunks of varying sizes (1KB to 256KB)
      final dataSizes = [1024, 4096, 16384, 65536, 262144]; // 1KB to 256KB
      int totalMessagesToSend = 0;
      
      // Calculate total messages (each device sends to its connected peers)
      for (int i = 0; i < devices.length; i++) {
        if (i == 0) { // Hub device
          totalMessagesToSend += 3 * dataSizes.length; // Send to 3 spoke devices
        } else if (i >= 1 && i <= 3) { // Spoke devices
          totalMessagesToSend += 1 * dataSizes.length; // Send to hub only
        } else if (i >= 4 && i <= 6) { // Ring devices
          totalMessagesToSend += 1 * dataSizes.length; // Send to one neighbor
        } else if (i >= 7 && i <= 9) { // Mesh devices
          totalMessagesToSend += 2 * dataSizes.length; // Send to two other mesh devices
        }
      }
      
      print('Advanced stress test data sizes: ${dataSizes.map((size) => '${(size / 1024).toStringAsFixed(0)}KB').join(', ')}');
      print('Total messages to send in advanced stress test: $totalMessagesToSend');
      
      // Perform advanced stress test
      print('\\nPerforming advanced stress test...');
      
      final stressStartTime = DateTime.now();
      int messagesActuallySent = 0;
      int totalBytesSent = 0;
      
      // Send messages from each device based on its topology role
      for (int senderIndex = 0; senderIndex < devices.length; senderIndex++) {
        final senderDevice = devices[senderIndex];
        
        List<int> targetIndices = [];
        
        // Determine targets based on topology
        if (senderIndex == 0) { // Hub sends to spokes
          targetIndices = [1, 2, 3];
        } else if (senderIndex >= 1 && senderIndex <= 3) { // Spokes send to hub
          targetIndices = [0];
        } else if (senderIndex >= 4 && senderIndex <= 6) { // Ring devices send to next in ring
          targetIndices = [(senderIndex + 1) > 6 ? 4 : (senderIndex + 1)];
        } else if (senderIndex >= 7 && senderIndex <= 9) { // Mesh devices send to others in mesh
          targetIndices = [7, 8, 9];
          targetIndices.remove(senderIndex); // Don't send to self
        }
        
        // Send data to each target
        for (final targetIndex in targetIndices) {
          final targetDevice = devices[targetIndex];
          
          // Send messages of different sizes
          for (int sizeIndex = 0; sizeIndex < dataSizes.length; sizeIndex++) {
            final messageSize = dataSizes[sizeIndex];
            
            // Create test data with pseudo-random content
            final payload = Uint8List(messageSize);
            for (int i = 0; i < messageSize; i++) {
              payload[i] = (i * 11 + senderIndex * 13 + targetIndex * 17 + sizeIndex * 19) % 256;
            }
            
            // Calculate checksum for integrity verification
            final checksum = sha256.convert(payload).toString();
            
            // Create message with payload and checksum
            final message = {
              'type': 'advanced_stress_test',
              'sender_id': senderIndex,
              'target_id': targetIndex,
              'message_size': messageSize,
              'payload': base64Encode(payload),
              'checksum': checksum,
              'timestamp': DateTime.now().millisecondsSinceEpoch,
              'integrity_test': true,
              'sequence': sizeIndex,
              'topology': senderIndex == 0 ? 'star_hub' : 
                         (senderIndex >= 1 && senderIndex <= 3) ? 'star_spoke' : 
                         (senderIndex >= 4 && senderIndex <= 6) ? 'ring' : 'mesh'
            };
            
            final jsonString = jsonEncode(message);
            final messageBytes = Uint8List.fromList(jsonString.codeUnits);
            
            try {
              senderDevice.send(messageBytes);
              messagesActuallySent++;
              totalBytesSent += messageBytes.length;
              
              if (messagesActuallySent % 50 == 0) {
                print('  Sent message $messagesActuallySent (${messageBytes.length} bytes) from Device ${senderIndex.toString().padLeft(2)} to Device ${targetIndex.toString().padLeft(2)}');
              }
            } catch (e) {
              print('  Error sending message $messagesActuallySent from Device ${senderIndex.toString().padLeft(2)} to Device ${targetIndex.toString().padLeft(2)}: $e');
            }
            
            // Small delay between messages
            await Future.delayed(Duration(milliseconds: 100));
          }
        }
        
        // Larger delay between device sends
        await Future.delayed(Duration(milliseconds: 300));
      }
      
      final stressSendTime = DateTime.now().difference(stressStartTime);
      print('\\nAdvanced stress test data transmission completed:');
      print('  Messages actually sent: $messagesActuallySent/$totalMessagesToSend');
      print('  Total bytes sent: ${totalBytesSent} (${(totalBytesSent / (1024 * 1024)).toStringAsFixed(2)} MB)');
      print('  Send duration: ${stressSendTime.inSeconds} seconds');
      print('  Average send rate: ${(totalBytesSent * 8 / stressSendTime.inMilliseconds).toStringAsFixed(2)} kbps');
      
      // Wait for messages to propagate through network
      print('\\nWaiting for messages to propagate through complex network...');
      await Future.delayed(Duration(seconds: 20));
      
      // Analyze advanced stress test results
      print('\\n=== Advanced Stress Test Results Analysis ===');
      
      int totalMessagesReceived = 0;
      int totalIntegrityChecks = 0;
      int passedIntegrityChecks = 0;
      int failedIntegrityChecks = 0;
      
      print('Message reception analysis by device:');
      for (int i = 0; i < devices.length; i++) {
        final messagesReceived = deviceMessages[i].length;
        final integrityChecks = deviceIntegrityResults[i].length;
        final passedChecks = deviceIntegrityResults[i].where((result) => result).length;
        final failedChecks = integrityChecks - passedChecks;
        
        totalMessagesReceived += messagesReceived;
        totalIntegrityChecks += integrityChecks;
        passedIntegrityChecks += passedChecks;
        failedIntegrityChecks += failedChecks;
        
        print('  Device ${i.toString().padLeft(2)} (${devices[i].peerId}):');
        print('    Messages received: $messagesReceived');
        print('    Integrity checks: $integrityChecks (pass: $passedChecks, fail: $failedChecks)');
        print('    Avg message size: ${messagesReceived > 0 ? (deviceMessageSizes[i].reduce((a, b) => a + b) ~/ messagesReceived) : 0} bytes');
      }
      
      final deliveryRate = totalMessagesToSend > 0 ? 
          (totalMessagesReceived / totalMessagesToSend * 100) : 0;
      final integrityRate = totalIntegrityChecks > 0 ? 
          (passedIntegrityChecks / totalIntegrityChecks * 100) : 0;
      
      print('\\nNetwork-wide advanced stress test results:');
      print('  Total messages sent: $totalMessagesToSend');
      print('  Total messages received: $totalMessagesReceived');
      print('  Message delivery rate: ${deliveryRate.toStringAsFixed(2)}%');
      print('  Total integrity checks: $totalIntegrityChecks');
      print('  Passed integrity checks: $passedIntegrityChecks');
      print('  Failed integrity checks: $failedIntegrityChecks');
      print('  Data integrity rate: ${integrityRate.toStringAsFixed(2)}%');
      
      // Performance metrics
      final stressTestEndTime = DateTime.now();
      final totalTestTime = stressTestEndTime.difference(stressStartTime);
      
      print('\\nPerformance metrics:');
      print('  Total test duration: ${totalTestTime.inSeconds} seconds');
      print('  Effective throughput: ${(totalBytesSent * 8 / totalTestTime.inMilliseconds).toStringAsFixed(2)} kbps');
      print('  Messages per second: ${(totalMessagesReceived / totalTestTime.inSeconds).toStringAsFixed(2)} msgs/sec');
      print('  Average message size: ${totalMessagesReceived > 0 ? (totalBytesSent ~/ totalMessagesReceived) : 0} bytes');
      
      // Success criteria evaluation
      print('\\n=== Advanced Stress Test Success Criteria ===');
      final deliverySuccess = deliveryRate >= 70;
      final integritySuccess = integrityRate >= 85;
      final throughputSuccess = (totalBytesSent * 8 / totalTestTime.inMilliseconds) >= 500; // 500 kbps minimum
      
      print('Delivery rate >= 70%: ${deliverySuccess ? '✅ PASS (${deliveryRate.toStringAsFixed(2)}%)' : '❌ FAIL (${deliveryRate.toStringAsFixed(2)}%)'}');
      print('Integrity rate >= 85%: ${integritySuccess ? '✅ PASS (${integrityRate.toStringAsFixed(2)}%)' : '❌ FAIL (${integrityRate.toStringAsFixed(2)}%)'}');
      print('Throughput >= 500 kbps: ${throughputSuccess ? '✅ PASS (${(totalBytesSent * 8 / totalTestTime.inMilliseconds).toStringAsFixed(2)} kbps)' : '❌ FAIL (${(totalBytesSent * 8 / totalTestTime.inMilliseconds).toStringAsFixed(2)} kbps)'}');
      
      if (deliverySuccess && integritySuccess && throughputSuccess) {
        print('\\n🎉 ADVANCED STRESS TEST: EXCELLENT PERFORMANCE!');
        print('   Network successfully handled advanced stress testing with multiple topologies');
        print('   Your specific IP (192.168.0.15) used throughout advanced stress test');
        print('   Data integrity maintained at ${integrityRate.toStringAsFixed(2)}%');
        print('   Throughput exceeded minimum requirements');
      } else if (deliverySuccess || integritySuccess) {
        print('\\n⚠️  ADVANCED STRESS TEST: ACCEPTABLE PERFORMANCE');
        print('   Network functional but can handle more load with optimization');
        print('   Core advanced stress test functionality available');
      } else {
        print('\\n🔴 ADVANCED STRESS TEST: NEEDS IMPROVEMENT');
        print('   Network struggles with advanced stress testing');
        print('   May affect real-world deployment scenarios');
      }
      
      // Close all devices
      for (final device in devices) {
        device.close();
      }
      
      print('\\nAdvanced stress test with multiple network topologies completed successfully!');
    }, timeout: Timeout(Duration(minutes: 3)));
  });
}

// Helper for SHA256 checksum calculation
String _calculateChecksum(Uint8List data) {
  return sha256.convert(data).toString();
}