import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:core_lib/p2p_socket.dart';

void main() {
  group('P2PSocket Two Instances Test', () {
    test('Create two instances on different ports and exchange candidates', () async {
      // Create two P2PSocket instances with different peer IDs
      final socketA = P2PSocket(peerId: 'peerA');
      final socketB = P2PSocket(peerId: 'peerB');
      
      // Verify both sockets are created
      expect(socketA, isNotNull);
      expect(socketB, isNotNull);
      
      // Check that they have different internal socket ports
      // First, we need to gather candidates to bind the sockets
      await socketA.gatherCandidates();
      await socketB.gatherCandidates();
      
      // Add delay to allow for socket binding
      await Future.delayed(Duration(milliseconds: 500));
      
      // Verify we can send messages without error
      final message = Uint8List.fromList('Hello from peer A'.codeUnits);
      expect(() => socketA.send(message), returnsNormally);
      
      socketA.close();
      socketB.close();
    });
    
    test('Test candidate exchange between two instances', () async {
      final socketA = P2PSocket(peerId: 'candidateA');
      final socketB = P2PSocket(peerId: 'candidateB');
      
      // Track received candidates
      var aCandidateReceived = false;
      var bCandidateReceived = false;
      
      // Set up candidate exchange
      socketA.onCandidate.listen((candidate) {
        socketB.addRemoteCandidate(candidate);
        aCandidateReceived = true;
      });
      
      socketB.onCandidate.listen((candidate) {
        socketA.addRemoteCandidate(candidate);
        bCandidateReceived = true;
      });
      
      // Start gathering candidates
      await Future.wait([
        socketA.gatherCandidates(),
        socketB.gatherCandidates()
      ]).timeout(Duration(seconds: 10), onTimeout: () {
        return [Future.value(), Future.value()]; 
      });
      
      // Wait briefly for candidates to be exchanged
      await Future.delayed(Duration(seconds: 2));
      
      // Since STUN might fail in test environment, we check if local host candidates were generated
      expect(aCandidateReceived || bCandidateReceived, true);
      
      socketA.close();
      socketB.close();
    });
    
    test('Test connection establishment with mock-like behavior', () async {
      final socketA = P2PSocket(peerId: 'connA');
      final socketB = P2PSocket(peerId: 'connB');
      
      // Track connection status
      var connectionEstablished = false;
      
      // Listen for connection messages
      socketA.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        if (message == 'Connection established!') {
          connectionEstablished = true;
        }
      });
      
      socketB.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        if (message == 'Connection established!') {
          connectionEstablished = true;
        }
      });
      
      // Set up candidate exchange
      socketA.onCandidate.listen((candidate) {
        socketB.addRemoteCandidate(candidate);
      });
      
      socketB.onCandidate.listen((candidate) {
        socketA.addRemoteCandidate(candidate);
      });
      
      // Start gathering candidates
      try {
        await Future.wait([
          socketA.gatherCandidates(),
          socketB.gatherCandidates()
        ]).timeout(Duration(seconds: 10), onTimeout: () {
          return [Future.value(), Future.value()];
        });
      } catch (e) {
        // Expected if STUN server is unreachable
      }
      
      // Wait for potential connection
      await Future.delayed(Duration(seconds: 3));
      
      // Note: Actual connection may not happen in test environment
      // due to STUN server unavailability or network restrictions
      
      socketA.close();
      socketB.close();
    });
  });
}