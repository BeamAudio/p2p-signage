import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:core_lib/p2p_socket.dart';

void main() {
  group('P2PSocket Stress Test with Large Data', () {
    test('Stress test sending large playlist items through abstraction layer', () async {
      print('=== P2PSocket Large Data Stress Test ===');
      
      // Create two P2PSocket instances to simulate master/slave devices
      final masterDevice = P2PSocket(
        peerId: 'master_device',
      );
      
      final slaveDevice = P2PSocket(
        peerId: 'slave_device',
      );
      
      print('Created master and slave devices');
      
      // Start gathering candidates for IP discovery
      print('Starting IP discovery...');
      await Future.wait([
        masterDevice.gatherCandidates(),
        slaveDevice.gatherCandidates()
      ]).timeout(Duration(seconds: 15), onTimeout: () => [Future.value(), Future.value()]);
      
      // Wait for IP discovery to complete
      await Future.delayed(Duration(seconds: 3));
      
      print('Discovered device information:');
      print('  Master Device:');
      print('    Private IP: ${masterDevice.discoveredPrivateIp}');
      print('    Port: ${masterDevice.localPort}');
      print('    Public IP: ${masterDevice.publicIp}');
      print('  Slave Device:');
      print('    Private IP: ${slaveDevice.discoveredPrivateIp}');
      print('    Port: ${slaveDevice.localPort}');
      print('    Public IP: ${slaveDevice.publicIp}');
      
      // Connect devices using public IPs to test relay functionality
      print('\\nSetting up connection using public IPs...');
      
      if (masterDevice.publicIp != null && masterDevice.localPort != null) {
        final masterPublicInfo = IceCandidate(
          'public_ip',
          masterDevice.publicIp!,  // Use public IP for relay testing
          masterDevice.localPort!, // Still need local port since we're on same machine
          150, // High priority for public IP
          foundation: 'public_ip_test'
        );
        slaveDevice.addRemoteCandidate(masterPublicInfo);
        print('  Added Master public IP (${masterDevice.publicIp}:${masterDevice.localPort}) to Slave');
      }
      
      if (slaveDevice.publicIp != null && slaveDevice.localPort != null) {
        final slavePublicInfo = IceCandidate(
          'public_ip',
          slaveDevice.publicIp!,  // Use public IP for relay testing
          slaveDevice.localPort!, // Still need local port since we're on same machine
          150, // High priority for public IP
          foundation: 'public_ip_test'
        );
        masterDevice.addRemoteCandidate(slavePublicInfo);
        print('  Added Slave public IP (${slaveDevice.publicIp}:${slaveDevice.localPort}) to Master');
      }
      
      await Future.delayed(Duration(seconds: 2));
      
      // Set up message tracking
      final masterReceivedMessages = <String>[];
      final slaveReceivedMessages = <String>[];
      final masterReceivedDataSizes = <int>[];
      final slaveReceivedDataSizes = <int>[];
      
      masterDevice.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        masterReceivedMessages.add(message);
        masterReceivedDataSizes.add(data.length);
        print('Master received message of ${data.length} bytes');
      });
      
      slaveDevice.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        slaveReceivedMessages.add(message);
        slaveReceivedDataSizes.add(data.length);
        print('Slave received message of ${data.length} bytes');
      });
      
      // Generate large playlist items for stress testing
      print('\\nGenerating large playlist items for stress test...');
      
      // Create a large playlist with various media types
      final largePlaylistItems = <Map<String, dynamic>>[];
      
      // Add large video items (simulate ~5MB each)
      for (int i = 0; i < 3; i++) {
        final videoData = Uint8List(5 * 1024 * 1024); // 5MB of data
        // Fill with pseudo-random data to make it realistic
        for (int j = 0; j < videoData.length; j++) {
          videoData[j] = (j * 7 + i * 13) % 256;
        }
        
        largePlaylistItems.add({
          'id': 'video_$i',
          'type': 'video',
          'name': 'Large Video File $i.mp4',
          'duration': 120 + i * 30,
          'size': videoData.length,
          'data': videoData,
          'checksum': 'checksum_${i}_large_video'
        });
      }
      
      // Add large image items (simulate ~2MB each)
      for (int i = 0; i < 5; i++) {
        final imageData = Uint8List(2 * 1024 * 1024); // 2MB of data
        // Fill with pseudo-random data
        for (int j = 0; j < imageData.length; j++) {
          imageData[j] = (j * 11 + i * 17) % 256;
        }
        
        largePlaylistItems.add({
          'id': 'image_$i',
          'type': 'image',
          'name': 'Large Image File $i.jpg',
          'duration': 30,
          'size': imageData.length,
          'data': imageData,
          'checksum': 'checksum_${i}_large_image'
        });
      }
      
      // Add text items (simulate ~100KB each)
      for (int i = 0; i < 10; i++) {
        final textData = Uint8List(100 * 1024); // 100KB of data
        // Fill with pseudo-random data
        for (int j = 0; j < textData.length; j++) {
          textData[j] = (j * 3 + i * 5) % 256;
        }
        
        largePlaylistItems.add({
          'id': 'text_$i',
          'type': 'text',
          'name': 'Large Text Content $i.txt',
          'duration': 60,
          'size': textData.length,
          'data': textData,
          'checksum': 'checksum_${i}_large_text'
        });
      }
      
      print('Generated ${largePlaylistItems.length} large playlist items:');
      print('  - ${largePlaylistItems.where((item) => item['type'] == 'video').length} large videos (~5MB each)');
      print('  - ${largePlaylistItems.where((item) => item['type'] == 'image').length} large images (~2MB each)');
      print('  - ${largePlaylistItems.where((item) => item['type'] == 'text').length} large text items (~100KB each)');
      
      // Calculate total data size
      int totalDataSize = 0;
      for (final item in largePlaylistItems) {
        totalDataSize += item['size'] as int;
      }
      print('Total data to transfer: ${(totalDataSize / (1024 * 1024)).toStringAsFixed(2)} MB');
      
      // Send playlist items from master to slave
      print('\\nSending large playlist items from Master to Slave...');
      
      final startTime = DateTime.now();
      int itemsSent = 0;
      int totalBytesSent = 0;
      
      // Send each playlist item
      for (int i = 0; i < largePlaylistItems.length; i++) {
        final item = largePlaylistItems[i];
        final itemType = item['type'] as String;
        final itemId = item['id'] as String;
        final itemSize = item['size'] as int;
        final itemData = item['data'] as Uint8List;
        
        // Create a structured message for the playlist item
        final playlistMessage = {
          'type': 'playlist_item',
          'itemId': itemId,
          'itemType': itemType,
          'itemName': item['name'] as String,
          'itemSize': itemSize,
          'timestamp': DateTime.now().millisecondsSinceEpoch,
          'data': base64Encode(itemData), // Encode binary data as base64 for transmission
        };
        
        final jsonString = jsonEncode(playlistMessage);
        final messageBytes = Uint8List.fromList(jsonString.codeUnits);
        
        print('Sending $itemType item "$itemId" (${(itemSize / 1024).toStringAsFixed(1)} KB)...');
        
        // Send the playlist item
        masterDevice.send(messageBytes);
        itemsSent++;
        totalBytesSent += messageBytes.length;
        
        // Add small delay between items to avoid overwhelming the connection
        if (i % 3 == 2) { // Every 3 items
          await Future.delayed(Duration(milliseconds: 500));
        }
        
        // For very large items, add extra delay
        if (itemType == 'video') {
          await Future.delayed(Duration(milliseconds: 1000));
        }
      }
      
      final sendTime = DateTime.now().difference(startTime);
      print('\\nPlaylist transmission completed:');
      print('  Items sent: $itemsSent');
      print('  Total bytes sent: ${totalBytesSent} (${(totalBytesSent / (1024 * 1024)).toStringAsFixed(2)} MB)');
      print('  Transmission time: ${sendTime.inMilliseconds} ms');
      print('  Average throughput: ${(totalBytesSent * 8 / sendTime.inMilliseconds).toStringAsFixed(2)} kbps');
      
      // Wait for all messages to be received
      print('\\nWaiting for all messages to be received...');
      await Future.delayed(Duration(seconds: 15));
      
      // Analyze received data
      print('\\n=== Stress Test Results ===');
      print('Master device received:');
      print('  Messages: ${masterReceivedMessages.length}');
      print('  Data sizes: ${masterReceivedDataSizes.join(', ')} bytes');
      
      print('Slave device received:');
      print('  Messages: ${slaveReceivedMessages.length}');
      print('  Data sizes: ${slaveReceivedDataSizes.join(', ')} bytes');
      
      // Verify data integrity
      int successfullyReceivedItems = 0;
      int corruptedItems = 0;
      
      for (int i = 0; i < slaveReceivedMessages.length; i++) {
        try {
          final message = slaveReceivedMessages[i];
          final jsonData = jsonDecode(message);
          
          if (jsonData['type'] == 'playlist_item') {
            successfullyReceivedItems++;
            print('  ✓ Successfully received playlist item: ${jsonData['itemId']} (${jsonData['itemType']})');
            
            // Verify data size matches expected
            final receivedSize = slaveReceivedDataSizes[i];
            final expectedSize = jsonData['itemSize'];
            if (receivedSize >= expectedSize * 0.9) { // Allow some overhead for encoding
              print('    Size verification: OK (${receivedSize} >= ${expectedSize})');
            } else {
              print('    Size verification: WARNING (${receivedSize} < ${expectedSize})');
              corruptedItems++;
            }
          }
        } catch (e) {
          print('  ✗ Error parsing received message $i: $e');
          corruptedItems++;
        }
      }
      
      final receiveTime = DateTime.now().difference(startTime);
      
      print('\\n=== Final Stress Test Analysis ===');
      print('Transmission Summary:');
      print('  Total items sent: $itemsSent');
      print('  Successfully received items: $successfullyReceivedItems');
      print('  Corrupted/lost items: $corruptedItems');
      print('  Success rate: ${((successfullyReceivedItems / itemsSent) * 100).toStringAsFixed(2)}%');
      print('  Total transmission time: ${receiveTime.inSeconds} seconds');
      print('  Average item size: ${(totalBytesSent / itemsSent).toStringAsFixed(0)} bytes');
      
      if (successfullyReceivedItems >= itemsSent * 0.8) {
        print('  🎉 OVERALL RESULT: STRESS TEST PASSED!');
        print('     System successfully handled large data transfers through public IP relay');
      } else {
        print('  ⚠️  OVERALL RESULT: STRESS TEST NEEDS IMPROVEMENT');
        print('     Too many items were lost or corrupted during transmission');
      }
      
      // Test sustained throughput with continuous data stream
      print('\\n=== Continuous Throughput Test ===');
      print('Sending continuous stream of medium-sized data packets...');
      
      final continuousStartTime = DateTime.now();
      int continuousPacketsSent = 0;
      int continuousBytesSent = 0;
      
      // Send 20 medium-sized packets (approx 512KB each)
      for (int i = 0; i < 20; i++) {
        // Create a medium-sized data packet
        final packetSize = 512 * 1024; // 512KB
        final dataPacket = Uint8List(packetSize);
        
        // Fill with pseudo-random but predictable data
        for (int j = 0; j < packetSize; j++) {
          dataPacket[j] = (j * 19 + i * 23) % 256;
        }
        
        // Create structured message
        final continuousMessage = {
          'type': 'continuous_data',
          'packetId': i,
          'packetSize': packetSize,
          'sequence': i,
          'timestamp': DateTime.now().millisecondsSinceEpoch,
          'data': base64Encode(dataPacket),
        };
        
        final jsonString = jsonEncode(continuousMessage);
        final messageBytes = Uint8List.fromList(jsonString.codeUnits);
        
        masterDevice.send(messageBytes);
        continuousPacketsSent++;
        continuousBytesSent += messageBytes.length;
        
        // Small delay between packets
        await Future.delayed(Duration(milliseconds: 200));
      }
      
      final continuousSendTime = DateTime.now().difference(continuousStartTime);
      print('Continuous transmission completed:');
      print('  Packets sent: $continuousPacketsSent');
      print('  Total bytes sent: ${continuousBytesSent} (${(continuousBytesSent / (1024 * 1024)).toStringAsFixed(2)} MB)');
      print('  Transmission time: ${continuousSendTime.inMilliseconds} ms');
      print('  Average throughput: ${(continuousBytesSent * 8 / continuousSendTime.inMilliseconds).toStringAsFixed(2)} kbps');
      
      // Wait for continuous data to be received
      await Future.delayed(Duration(seconds: 10));
      
      // Close devices
      masterDevice.close();
      slaveDevice.close();
      
      print('\\nLarge data stress test completed!');
    }, timeout: Timeout(Duration(minutes: 3))); // 3-minute timeout for large data transfers
  });
}