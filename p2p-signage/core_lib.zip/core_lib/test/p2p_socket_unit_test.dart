import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:core_lib/p2p_socket.dart';

void main() {
  group('P2PSocket Unit Tests', () {
    test('creates P2PSocket instance with correct parameters', () {
      final socket = P2PSocket(
        peerId: 'test_peer',
        stunServerHostname: 'stun.example.com',
        stunPort: 12345,
      );
      
      // Note: These are private fields, so we can't directly test them
      // Instead, we can verify that creation doesn't throw an error
      expect(socket, isNotNull);
      
      socket.close();
    });

    test('adds remote candidate correctly', () {
      final socket = P2PSocket(peerId: 'test_peer');
      final candidate = IceCandidate('host', '192.168.1.100', 8080, 126, foundation: '1');
      
      socket.addRemoteCandidate(candidate);
      // We can't directly check the internal list, so we'll just verify no errors occur
      
      socket.close();
    });
    
    test('send method does not throw when no connection established', () {
      final socket = P2PSocket(peerId: 'test_peer');
      final message = Uint8List.fromList('Hello'.codeUnits);
      
      // Should not throw an error even if no connection is established
      expect(() => socket.send(message), returnsNormally);
      
      socket.close();
    });
    
    test('streams are properly initialized', () {
      final socket = P2PSocket(peerId: 'test_peer');
      
      expect(socket.onCandidate, isNotNull);
      expect(socket.onMessage, isNotNull);
      
      socket.close();
    });
    
    test('onCandidate stream receives candidates during candidate gathering', () async {
      final socket = P2PSocket(peerId: 'test_peer');
      
      // We use a Completer to wait for the candidate
      final candidateCompleter = Completer<IceCandidate>();
      
      socket.onCandidate.listen((candidate) {
        if (!candidateCompleter.isCompleted) {
          candidateCompleter.complete(candidate);
        }
      });
      
      // Start gathering candidates (this would normally try to reach a STUN server)
      try {
        await socket.gatherCandidates();
      } catch (e) {
        // We expect this to potentially fail if STUN server is not reachable,
        // but we can still check if any local candidate was generated
      }
      
      // Wait briefly for any candidate that might be generated, but don't fail the test if none arrives
      // because the STUN server might not be reachable in the test environment
      await Future.delayed(Duration(seconds: 1));
      
      socket.close();
    });
    
    test('onMessage stream receives messages', () async {
      final socket = P2PSocket(peerId: 'test_peer');
      
      final messageCompleter = Completer<Uint8List>();
      socket.onMessage.listen((message) {
        if (!messageCompleter.isCompleted) {
          messageCompleter.complete(message);
        }
      });
      
      // Send a test message to ourselves - this is just to test the stream
      // (Note: This won't actually send it anywhere since we don't have a remote candidate)
      final testMessage = Uint8List.fromList('Test message'.codeUnits);
      socket.send(testMessage);
      
      // Wait briefly for any potential message (though there shouldn't be any sent back)
      await Future.delayed(Duration(milliseconds: 500));
      
      socket.close();
    });
  });
}