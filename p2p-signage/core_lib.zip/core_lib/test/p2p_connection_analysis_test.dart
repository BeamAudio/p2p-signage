import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:core_lib/p2p_socket.dart';

void main() {
  group('P2PSocket Connection Analysis', () {
    test('Analyze connection establishment process', () async {
      print('=== Analyzing Connection Establishment ===');
      
      // Create two P2PSocket instances
      final deviceA = P2PSocket(
        peerId: 'device_a',
      );
      
      final deviceB = P2PSocket(
        peerId: 'device_b',
      );
      
      // Wait for IP discovery
      await Future.wait([
        deviceA.gatherCandidates(),
        deviceB.gatherCandidates()
      ]).timeout(Duration(seconds: 10), onTimeout: () => [Future.value(), Future.value()]);
      
      await Future.delayed(Duration(seconds: 3));
      
      print('Device A IP: ${deviceA.discoveredPrivateIp}, Port: ${deviceA.localPort}');
      print('Device B IP: ${deviceB.discoveredPrivateIp}, Port: ${deviceB.localPort}');
      
      // Set up connection establishment tracking
      var deviceAConnected = false;
      var deviceBConnected = false;
      
      deviceA.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        if (message == 'Connection established!') {
          deviceAConnected = true;
          print('Device A: Connection established!');
        }
      });
      
      deviceB.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        if (message == 'Connection established!') {
          deviceBConnected = true;
          print('Device B: Connection established!');
        }
      });
      
      // Set up candidate exchange
      // Use Device A's actual IP and port for Device B to connect to
      final deviceAInfo = IceCandidate(
        'direct',
        deviceA.discoveredPrivateIp!,  // Use the actual IP of device A
        deviceA.localPort!,            // Use the actual port of device A
        140,
        foundation: 'direct_test'
      );
      deviceB.addRemoteCandidate(deviceAInfo);
      print('Added Device A (${deviceA.discoveredPrivateIp}:${deviceA.localPort}) to Device B');
      
      // Use Device B's actual IP and port for Device A to connect to
      final deviceBInfo = IceCandidate(
        'direct',
        deviceB.discoveredPrivateIp!,  // Use the actual IP of device B
        deviceB.localPort!,            // Use the actual port of device B
        140,
        foundation: 'direct_test'
      );
      deviceA.addRemoteCandidate(deviceBInfo);
      print('Added Device B (${deviceB.discoveredPrivateIp}:${deviceB.localPort}) to Device A');
      
      await Future.delayed(Duration(seconds: 5));
      
      print('\\nConnection status after candidate exchange:');
      print('Device A connected: $deviceAConnected');
      print('Device B connected: $deviceBConnected');
      
      // Check internal state
      print('\\nInternal state:');
      print('Device A _isConnected: ${_getIsConnected(deviceA)}');
      print('Device B _isConnected: ${_getIsConnected(deviceB)}');
      print('Device A _selectedRemoteCandidate: ${_getSelectedRemoteCandidate(deviceA)}');
      print('Device B _selectedRemoteCandidate: ${_getSelectedRemoteCandidate(deviceB)}');
      
      // Close sockets
      deviceA.close();
      deviceB.close();
    }, timeout: Timeout(Duration(seconds: 30)));
  });
}

// Helper to access private properties for testing
bool _getIsConnected(P2PSocket socket) {
  // This would require access to private fields, let's just log a note
  print('Note: Cannot access private _isConnected field for analysis in this test');
  return false;
}

// Helper to access private properties for testing
dynamic _getSelectedRemoteCandidate(P2PSocket socket) {
  // This would require access to private fields, let's just log a note
  print('Note: Cannot access private _selectedRemoteCandidate field for analysis in this test');
  return null;
}