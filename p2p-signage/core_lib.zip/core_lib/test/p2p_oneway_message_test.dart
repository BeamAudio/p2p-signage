import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:core_lib/p2p_socket.dart';

void main() {
  group('P2PSocket One-Way Message Test', () {
    test('Test one-way messaging with timing', () async {
      print('=== One-Way Messaging Test ===');
      
      // Create two P2PSocket instances
      final sender = P2PSocket(
        peerId: 'sender',
      );
      
      final receiver = P2PSocket(
        peerId: 'receiver',
      );
      
      // Wait for IP discovery
      await Future.wait([
        sender.gatherCandidates(),
        receiver.gatherCandidates()
      ]).timeout(Duration(seconds: 10), onTimeout: () => [Future.value(), Future.value()]);
      
      await Future.delayed(Duration(seconds: 3));
      
      print('Sender IP: ${sender.discoveredPrivateIp}, Port: ${sender.localPort}');
      print('Receiver IP: ${receiver.discoveredPrivateIp}, Port: ${receiver.localPort}');
      
      // Add receiver's address as a remote candidate to the sender
      final receiverInfo = IceCandidate(
        'direct',
        receiver.discoveredPrivateIp!,  // Use receiver's IP
        receiver.localPort!,            // Use receiver's port
        140,
        foundation: 'direct_test'
      );
      sender.addRemoteCandidate(receiverInfo);
      print('Added receiver (${receiver.discoveredPrivateIp}:${receiver.localPort}) to sender');
      
      // Add sender's address as a remote candidate to the receiver
      final senderInfo = IceCandidate(
        'direct',
        sender.discoveredPrivateIp!,    // Use sender's IP
        sender.localPort!,              // Use sender's port
        140,
        foundation: 'direct_test'
      );
      receiver.addRemoteCandidate(senderInfo);
      print('Added sender (${sender.discoveredPrivateIp}:${sender.localPort}) to receiver');
      
      // Wait for candidate processing to complete
      await Future.delayed(Duration(seconds: 2));
      
      // Set up message tracking - we'll use Completers to wait for messages
      final receivedMessages = <String>[];
      final messageCompleter = Completer<void>();
      
      receiver.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        if (message.startsWith('MSG:')) {
          receivedMessages.add(message);
          print('Receiver received: $message');
          if (!messageCompleter.isCompleted) {
            messageCompleter.complete();
          }
        }
      });
      
      print('\\nSending message from sender to receiver...');
      sender.send(Uint8List.fromList('MSG: Hello from sender'.codeUnits));
      
      print('Message sent, waiting for receipt or timeout...');
      
      // Wait for the message to be received with timeout
      try {
        await messageCompleter.future.timeout(Duration(seconds: 5));
        print('SUCCESS: Message was received!');
      } catch (e) {
        print('TIMEOUT: Message was not received within 5 seconds');
        print('Messages received: $receivedMessages');
      }
      
      print('\\nFinal results:');
      print('Messages received by receiver: $receivedMessages');
      
      // Close sockets
      sender.close();
      receiver.close();
    }, timeout: Timeout(Duration(seconds: 30)));
  });
}