import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:core_lib/p2p_socket.dart';

void main() {
  group('P2PSocket Technician Network Buildout Test', () {
    test('Simulate technician connecting 10 devices sequentially', () async {
      print('=== Technician Network Buildout Test ===');
      
      // Create 10 P2PSocket instances (devices)
      final devices = <P2PSocket>[];
      final deviceIds = <String>[];
      
      for (int i = 0; i < 10; i++) {
        final deviceId = 'device_${i.toString().padLeft(2, '0')}';
        deviceIds.add(deviceId);
        final device = P2PSocket(
          peerId: deviceId,
        );
        devices.add(device);
      }
      
      print('Created ${devices.length} devices');
      
      // Start gathering candidates for all devices to discover IPs
      print('Starting IP discovery for all devices...');
      final futures = <Future>[];
      for (final device in devices) {
        futures.add(device.gatherCandidates());
      }
      
      try {
        await Future.wait(futures, eagerError: true).timeout(Duration(seconds: 15));
      } catch (e) {
        print('Some devices had timeout during candidate gathering: $e');
        // Continue with what we have
      }
      
      // Wait for IP discovery to complete
      await Future.delayed(Duration(seconds: 3));
      
      // Print discovered information for each device
      print('\\nDiscovered information for all devices:');
      for (int i = 0; i < devices.length; i++) {
        print('  Device ${i.toString().padLeft(2)}: IP=${devices[i].discoveredPrivateIp}, Port=${devices[i].localPort}, PublicIP=${devices[i].publicIp}');
      }
      
      // SIMULATE TECHNICIAN PROCESS: Connect devices one by one
      
      // Step 1: Technician connects Device 0 and Device 1
      print('\\n--- Technician connects Device 00 and Device 01 ---');
      if (devices[1].discoveredPrivateIp != null && devices[1].localPort != null) {
        final device1Info = IceCandidate(
          'technician',
          devices[1].discoveredPrivateIp!,
          devices[1].localPort!,
          140,
          foundation: 'tech_connect'
        );
        devices[0].addRemoteCandidate(device1Info);
        print('  Technician added Device 01 (${devices[1].discoveredPrivateIp}:${devices[1].localPort}) to Device 00');
      }
      
      if (devices[0].discoveredPrivateIp != null && devices[0].localPort != null) {
        final device0Info = IceCandidate(
          'technician',
          devices[0].discoveredPrivateIp!,
          devices[0].localPort!,
          140,
          foundation: 'tech_connect'
        );
        devices[1].addRemoteCandidate(device0Info);
        print('  Technician added Device 00 (${devices[0].discoveredPrivateIp}:${devices[0].localPort}) to Device 01');
      }
      
      // Wait for initial connection
      await Future.delayed(Duration(seconds: 2));
      
      // Step 2: Technician takes Device 2 and connects to Device 1 (who already knows Device 0)
      print('\\n--- Technician adds Device 02 to network via Device 01 ---');
      // Device 2 gets connection info for Device 1
      if (devices[1].discoveredPrivateIp != null && devices[1].localPort != null) {
        final device1Info = IceCandidate(
          'technician',
          devices[1].discoveredPrivateIp!,
          devices[1].localPort!,
          140,
          foundation: 'tech_connect'
        );
        devices[2].addRemoteCandidate(device1Info);
        print('  Technician added Device 01 (${devices[1].discoveredPrivateIp}:${devices[1].localPort}) to Device 02');
      }
      
      // Device 1 gets connection info for Device 2
      if (devices[2].discoveredPrivateIp != null && devices[2].localPort != null) {
        final device2Info = IceCandidate(
          'technician',
          devices[2].discoveredPrivateIp!,
          devices[2].localPort!,
          140,
          foundation: 'tech_connect'
        );
        devices[1].addRemoteCandidate(device2Info);
        print('  Technician added Device 02 (${devices[2].discoveredPrivateIp}:${devices[2].localPort}) to Device 01');
      }
      
      // Now Device 2 should learn about Device 0 through Device 1
      // Simulate Device 1 sharing Device 0's info with Device 2
      if (devices[0].discoveredPrivateIp != null && devices[0].localPort != null) {
        final device0Info = IceCandidate(
          'gossip',
          devices[0].discoveredPrivateIp!,
          devices[0].localPort!,
          130, // Lower priority for gossiped info
          foundation: 'gossip'
        );
        devices[2].addRemoteCandidate(device0Info);
        print('  Device 01 gossiped Device 00 (${devices[0].discoveredPrivateIp}:${devices[0].localPort}) to Device 02');
      }
      
      await Future.delayed(Duration(seconds: 2));
      
      // Step 3: Technician connects Device 3 to Device 2 (who knows about 0, 1)
      print('\\n--- Technician adds Device 03 to network via Device 02 ---');
      // Connect Device 3 and Device 2 directly
      if (devices[2].discoveredPrivateIp != null && devices[2].localPort != null) {
        final device2Info = IceCandidate(
          'technician',
          devices[2].discoveredPrivateIp!,
          devices[2].localPort!,
          140,
          foundation: 'tech_connect'
        );
        devices[3].addRemoteCandidate(device2Info);
        print('  Technician added Device 02 (${devices[2].discoveredPrivateIp}:${devices[2].localPort}) to Device 03');
      }
      
      if (devices[3].discoveredPrivateIp != null && devices[3].localPort != null) {
        final device3Info = IceCandidate(
          'technician',
          devices[3].discoveredPrivateIp!,
          devices[3].localPort!,
          140,
          foundation: 'tech_connect'
        );
        devices[2].addRemoteCandidate(device3Info);
        print('  Technician added Device 03 (${devices[3].discoveredPrivateIp}:${devices[3].localPort}) to Device 02');
      }
      
      // Device 2 shares info about Devices 0 and 1 with Device 3
      if (devices[0].discoveredPrivateIp != null && devices[0].localPort != null) {
        final device0Info = IceCandidate(
          'gossip',
          devices[0].discoveredPrivateIp!,
          devices[0].localPort!,
          130,
          foundation: 'gossip'
        );
        devices[3].addRemoteCandidate(device0Info);
        print('  Device 02 gossiped Device 00 (${devices[0].discoveredPrivateIp}:${devices[0].localPort}) to Device 03');
      }
      
      if (devices[1].discoveredPrivateIp != null && devices[1].localPort != null) {
        final device1Info = IceCandidate(
          'gossip',
          devices[1].discoveredPrivateIp!,
          devices[1].localPort!,
          130,
          foundation: 'gossip'
        );
        devices[3].addRemoteCandidate(device1Info);
        print('  Device 02 gossiped Device 01 (${devices[1].discoveredPrivateIp}:${devices[1].localPort}) to Device 03');
      }
      
      await Future.delayed(Duration(seconds: 2));
      
      // Continue the pattern for remaining devices
      for (int i = 4; i < devices.length; i++) {
        print('\\n--- Technician adds Device ${(i).toString().padLeft(2, '0')} to network via Device ${(i-1).toString().padLeft(2, '0')} ---');
        
        // Connect new device to the previous one
        final prevDevice = devices[i-1];
        final newDevice = devices[i];
        
        // Direct technician connection
        if (prevDevice.discoveredPrivateIp != null && prevDevice.localPort != null) {
          final prevInfo = IceCandidate(
            'technician',
            prevDevice.discoveredPrivateIp!,
            prevDevice.localPort!,
            140,
            foundation: 'tech_connect'
          );
          newDevice.addRemoteCandidate(prevInfo);
          print('  Technician added Device ${(i-1).toString().padLeft(2, '0')} (${prevDevice.discoveredPrivateIp}:${prevDevice.localPort}) to Device ${i.toString().padLeft(2, '0')}');
        }
        
        if (newDevice.discoveredPrivateIp != null && newDevice.localPort != null) {
          final newInfo = IceCandidate(
            'technician',
            newDevice.discoveredPrivateIp!,
            newDevice.localPort!,
            140,
            foundation: 'tech_connect'
          );
          prevDevice.addRemoteCandidate(newInfo);
          print('  Technician added Device ${i.toString().padLeft(2, '0')} (${newDevice.discoveredPrivateIp}:${newDevice.localPort}) to Device ${(i-1).toString().padLeft(2, '0')}');
        }
        
        // Previous device gossips all known devices to the new device
        for (int j = 0; j < i-1; j++) {  // Share all devices before the previous one
          final gossipDevice = devices[j];
          if (gossipDevice.discoveredPrivateIp != null && gossipDevice.localPort != null) {
            final gossipInfo = IceCandidate(
              'gossip',
              gossipDevice.discoveredPrivateIp!,
              gossipDevice.localPort!,
              130,
              foundation: 'gossip'
            );
            newDevice.addRemoteCandidate(gossipInfo);
            print('  Device ${(i-1).toString().padLeft(2, '0')} gossiped Device ${j.toString().padLeft(2, '0')} (${gossipDevice.discoveredPrivateIp}:${gossipDevice.localPort}) to new Device ${i.toString().padLeft(2, '0')}');
          }
        }
        
        await Future.delayed(Duration(seconds: 1));
      }
      
      print('\\n=== Network Formation Complete ===');
      
      // Now send a test message from Device 0 to see how many other devices receive it
      print('\\nTesting network connectivity by sending message from Device 00...');
      
      final receivedBy = <int>[];
      final Completer<void> allRepliesCompleter = Completer<void>();
      
      // All devices listen for test message and reply
      for (int i = 1; i < devices.length; i++) { // i starts at 1, since sender is 0
        final targetIndex = i;
        devices[i].onMessage.listen((data) {
          final message = String.fromCharCodes(data);
          if (message.startsWith('TEST_MSG_FROM_00:')) {
            if (!receivedBy.contains(targetIndex)) {
              receivedBy.add(targetIndex);
              print('  Device ${targetIndex.toString().padLeft(2, '0')} received test message');
              
              // Reply back to acknowledge
              final reply = 'ACK_FROM_${targetIndex.toString().padLeft(2, '0')}';
              devices[0].send(Uint8List.fromList(reply.codeUnits));
            }
          }
        });
      }
      
      // Device 0 listens for acknowledgments
      var ackCount = 0;
      devices[0].onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        if (message.startsWith('ACK_FROM_')) {
          ackCount++;
          print('  Device 00 received acknowledgment: $message');
        }
      });
      
      // Send the test message from Device 0
      final testMessage = 'TEST_MSG_FROM_00: Hello from the first device in the network!';
      devices[0].send(Uint8List.fromList(testMessage.codeUnits));
      
      // Wait for acknowledgments or timeout
      await Future.delayed(Duration(seconds: 8));
      
      print('\\n=== Final Network Results ===');
      print('  Total devices in network: ${devices.length}');
      print('  Message from Device 00 reached: ${receivedBy.length} of ${devices.length - 1} other devices');
      print('  Acknowledgments received by Device 00: $ackCount');
      
      // Calculate network reach
      final reachPercentage = devices.length > 1 ? (receivedBy.length / (devices.length - 1) * 100) : 0;
      print('  Network reach: ${reachPercentage.toStringAsFixed(2)}%');
      
      if (receivedBy.length > 0) {
        print('  Devices that received the message: ${receivedBy.map((i) => 'Device ${i.toString().padLeft(2, '0')}').join(', ')}');
      } else {
        print('  No other devices received the message from Device 00');
      }
      
      // Close all devices
      for (final device in devices) {
        device.close();
      }
      
      print('\\nTechnician network buildout test completed!');
    }, timeout: Timeout(Duration(seconds: 60)));
  });
}