import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:core_lib/p2p_socket.dart';

void main() {
  group('P2PSocket Network Setup Test', () {
    test('Simulate technician manual setup with routing table', () async {
      // Simulate a master instance that a technician would use
      final masterSocket = P2PSocket(peerId: 'master_device');
      var masterPublicIp = '';
      var masterPort = 0;
      
      // Simulate a client instance
      final clientSocket = P2PSocket(peerId: 'client_device');
      var clientPublicIp = '';
      var clientPort = 0;
      
      // Track discovered public IPs from STUN
      masterSocket.onCandidate.listen((candidate) {
        if (candidate.type == 'srflx') { // server-reflexive = public IP
          masterPublicIp = candidate.address;
          masterPort = candidate.port;
          print('Master public IP discovered: ${masterPublicIp}:${masterPort}');
        } else if (candidate.type == 'host') {
          // Fallback to local IP if STUN fails
          masterPublicIp = candidate.address;
          masterPort = candidate.port;
          print('Master local IP used: ${masterPublicIp}:${masterPort}');
        }
      });
      
      clientSocket.onCandidate.listen((candidate) {
        if (candidate.type == 'srflx') { // server-reflexive = public IP
          clientPublicIp = candidate.address;
          clientPort = candidate.port;
          print('Client public IP discovered: ${clientPublicIp}:${clientPort}');
        } else if (candidate.type == 'host') {
          // Fallback to local IP if STUN fails
          clientPublicIp = candidate.address;
          clientPort = candidate.port;
          print('Client local IP used: ${clientPublicIp}:${clientPort}');
        }
      });
      
      // Gather candidates to discover IPs
      await Future.wait([
        masterSocket.gatherCandidates(),
        clientSocket.gatherCandidates()
      ]).timeout(Duration(seconds: 10), onTimeout: () => [Future.value(), Future.value()]);
      
      await Future.delayed(Duration(seconds: 2));
      
      print('Manual setup - Master IP: ${masterPublicIp}:${masterPort}');
      print('Manual setup - Client IP: ${clientPublicIp}:${clientPort}');
      
      // Simulate manual setup by technician: add client IP to master
      final clientAsCandidate = IceCandidate('manual', clientPublicIp, clientPort, 75);
      masterSocket.addRemoteCandidate(clientAsCandidate);
      
      // Simulate manual setup by technician: add master IP to client  
      final masterAsCandidate = IceCandidate('manual', masterPublicIp, masterPort, 75);
      clientSocket.addRemoteCandidate(masterAsCandidate);
      
      // Now both nodes should try to connect to each other
      await Future.delayed(Duration(seconds: 5));
      
      // Test message exchange
      var masterReceivedMessage = false;
      var clientReceivedMessage = false;
      
      masterSocket.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        if (message == 'Hello from client') {
          masterReceivedMessage = true;
          print('Master received message from client');
        }
      });
      
      clientSocket.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        if (message == 'Hello from master') {
          clientReceivedMessage = true;
          print('Client received message from master');
        }
      });
      
      // Send messages in both directions
      masterSocket.send(Uint8List.fromList('Hello from master'.codeUnits));
      clientSocket.send(Uint8List.fromList('Hello from client'.codeUnits));
      
      await Future.delayed(Duration(seconds: 3));
      
      print('Master received client message: $masterReceivedMessage');
      print('Client received master message: $clientReceivedMessage');
      
      masterSocket.close();
      clientSocket.close();
    }, timeout: Timeout(Duration(seconds: 40)));
    
    test('Test distributed routing table simulation', () async {
      // Create multiple nodes to simulate the distributed routing table
      final nodes = <P2PSocket>[];
      final nodeData = <Map<String, dynamic>>[];
      
      const numNodes = 4;
      
      // Create nodes and collect their IP data
      for (int i = 0; i < numNodes; i++) {
        final node = P2PSocket(peerId: 'node_$i');
        nodes.add(node);
        
        // Track this node's information
        final data = {
          'id': 'node_$i',
          'publicIp': '',
          'port': 0,
          'candidate': null as IceCandidate?
        };
        nodeData.add(data);
        
        // Listen for candidates (IP discovery)
        node.onCandidate.listen((candidate) {
          if (candidate.type == 'srflx' || candidate.type == 'host') {
            data['publicIp'] = candidate.address;
            data['port'] = candidate.port;
            data['candidate'] = candidate;
            print('Node ${data['id']} IP: ${candidate.address}:${candidate.port}');
          }
        });
      }
      
      // Gather candidates for all nodes
      final futures = <Future>[];
      for (final node in nodes) {
        futures.add(node.gatherCandidates().timeout(Duration(seconds: 5), 
          onTimeout: () => Future.value()));
      }
      await Future.wait(futures, eagerError: false);
      
      await Future.delayed(Duration(seconds: 2));
      
      // Simulate distributed routing table sharing
      // Each node adds all other nodes as remote candidates
      for (int i = 0; i < numNodes; i++) {
        for (int j = 0; j < numNodes; j++) {
          if (i != j && nodeData[j]['candidate'] != null) {
            nodes[i].addRemoteCandidate(nodeData[j]['candidate']!);
          }
        }
      }
      
      await Future.delayed(Duration(seconds: 3));
      
      // Test message exchange between all nodes
      var totalMessagesReceived = 0;
      
      for (int i = 0; i < numNodes; i++) {
        nodes[i].onMessage.listen((data) {
          final message = String.fromCharCodes(data);
          if (message.startsWith('Test message from')) {
            totalMessagesReceived++;
            print('Node $i received: $message');
          }
        });
      }
      
      // Send test messages from each node to all others
      for (int i = 0; i < numNodes; i++) {
        for (int j = 0; j < numNodes; j++) {
          if (i != j) {
            final message = 'Test message from node_$i to node_$j';
            nodes[i].send(Uint8List.fromList(message.codeUnits));
          }
        }
      }
      
      await Future.delayed(Duration(seconds: 5));
      
      print('Total messages received across all nodes: $totalMessagesReceived');
      
      // Close all nodes
      for (final node in nodes) {
        node.close();
      }
    }, timeout: Timeout(Duration(seconds: 40)));
  });
}