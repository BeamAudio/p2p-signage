import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:core_lib/p2p_socket.dart';

void main() {
  group('P2PSocket Manual IP Configuration Test', () {
    test('Simulate manual configuration of remote device IPs and ports', () async {
      print('=== Manual IP Configuration Test ===');
      
      // Create two P2PSocket instances
      final deviceA = P2PSocket(
        peerId: 'device_a',
      );
      
      final deviceB = P2PSocket(
        peerId: 'device_b',
      );
      
      // Wait for IP discovery
      await Future.wait([
        deviceA.gatherCandidates(),
        deviceB.gatherCandidates()
      ]).timeout(Duration(seconds: 10), onTimeout: () => [Future.value(), Future.value()]);
      
      await Future.delayed(Duration(seconds: 3));
      
      // Display discovered information for each device
      print('Device A:');
      print('  Local IPs: ${deviceA.localIps.map((ip) => ip.address).join(", ")}');
      print('  Discovered Private IP: ${deviceA.discoveredPrivateIp}');
      print('  Local Port: ${deviceA.localPort}');
      print('  Discovered Private Address: ${deviceA.discoveredPrivateAddress}');
      print('  Discovered Public IP: ${deviceA.publicIp}');
      
      print('Device B:');
      print('  Local IPs: ${deviceB.localIps.map((ip) => ip.address).join(", ")}');
      print('  Discovered Private IP: ${deviceB.discoveredPrivateIp}');
      print('  Local Port: ${deviceB.localPort}');
      print('  Discovered Private Address: ${deviceB.discoveredPrivateAddress}');
      print('  Discovered Public IP: ${deviceB.publicIp}');
      
      // This is the key part - in a real scenario, after each device discovers
      // its own IP and port, they would need to be manually configured with
      // the other device's IP and port information
      final deviceAAddress = deviceA.discoveredPrivateAddress;  // In real scenarios, this would be public IP
      final deviceBAddress = deviceB.discoveredPrivateAddress;  // In real scenarios, this would be public IP
      
      print('Simulating manual configuration where:');
      print('  - Device A is told about Device B address: $deviceBAddress');
      print('  - Device B is told about Device A address: $deviceAAddress');
      
      // Create IceCandidates for the manually configured remote addresses
      // In a real system, this would happen via a distributed routing table or manual input
      if (deviceB.discoveredPrivateIp != null && deviceB.localPort != null) {
        final deviceBInfo = IceCandidate(
          'manual', 
          deviceB.discoveredPrivateIp!,  // This would be the public IP in real scenarios
          deviceB.localPort!,            // This is the port Device B is listening on
          150,                           // High priority for manually configured IPs
          foundation: 'manual_config'
        );
        deviceA.addRemoteCandidate(deviceBInfo);
        print('Added Device B ($deviceBAddress) to Device A manually');
      }
      
      if (deviceA.discoveredPrivateIp != null && deviceA.localPort != null) {
        final deviceAInfo = IceCandidate(
          'manual', 
          deviceA.discoveredPrivateIp!,  // This would be the public IP in real scenarios
          deviceA.localPort!,            // This is the port Device A is listening on
          150,                           // High priority for manually configured IPs
          foundation: 'manual_config'
        );
        deviceB.addRemoteCandidate(deviceAInfo);
        print('Added Device A ($deviceAAddress) to Device B manually');
      }
      
      await Future.delayed(Duration(seconds: 2));
      
      // Track connections and messages
      var deviceAConnected = false;
      var deviceBConnected = false;
      var deviceAMessages = <String>[];
      var deviceBMessages = <String>[];
      
      deviceA.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        if (message == 'Connection established!') {
          deviceAConnected = true;
          print('Device A: Connection established with remote device');
        } else {
          deviceAMessages.add(message);
          print('Device A received: $message');
        }
      });
      
      deviceB.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        if (message == 'Connection established!') {
          deviceBConnected = true;
          print('Device B: Connection established with remote device');
        } else {
          deviceBMessages.add(message);
          print('Device B received: $message');
        }
      });
      
      // Send initial messages to trigger connection
      deviceA.send(Uint8List.fromList('Hello from Device A'.codeUnits));
      deviceB.send(Uint8List.fromList('Hello from Device B'.codeUnits));
      
      await Future.delayed(Duration(seconds: 3));
      
      // Send more messages
      deviceA.send(Uint8List.fromList('Second message from A'.codeUnits));
      deviceB.send(Uint8List.fromList('Second message from B'.codeUnits));
      
      await Future.delayed(Duration(seconds: 2));
      
      print('\\nResults:');
      print('  Device A connected: $deviceAConnected');
      print('  Device B connected: $deviceBConnected');
      print('  Device A received messages: ${deviceAMessages.length}');
      print('  Device B received messages: ${deviceBMessages.length}');
      
      // Verify that both devices were able to discover their IPs
      expect(deviceA.discoveredPrivateIp, isNotNull);
      expect(deviceA.localPort, greaterThan(0));
      expect(deviceB.discoveredPrivateIp, isNotNull);
      expect(deviceB.localPort, greaterThan(0));
      
      deviceA.close();
      deviceB.close();
    }, timeout: Timeout(Duration(seconds: 30)));
    
    test('Demonstrate technician configuration workflow', () async {
      print('\\n=== Technician Configuration Workflow ===');
      
      // Step 1: Each device discovers its own IP and port
      final masterDevice = P2PSocket(
        peerId: 'master_display',
      );
      
      final slaveDevice = P2PSocket(
        peerId: 'slave_display',
      );
      
      // Start gathering candidates so each device discovers its own info
      await Future.wait([
        masterDevice.gatherCandidates(),
        slaveDevice.gatherCandidates()
      ]).timeout(Duration(seconds: 10), onTimeout: () => [Future.value(), Future.value()]);
      
      await Future.delayed(Duration(seconds: 3));
      
      // Step 2: Technician notes each device's IP and port
      final masterInfo = {
        'ip': masterDevice.discoveredPrivateIp,  // Would be public IP in real scenario
        'port': masterDevice.localPort,
        'address': masterDevice.discoveredPrivateAddress
      };
      
      final slaveInfo = {
        'ip': slaveDevice.discoveredPrivateIp,  // Would be public IP in real scenario
        'port': slaveDevice.localPort,
        'address': slaveDevice.discoveredPrivateAddress
      };
      
      print('Technician notes:');
      print('  Master device IP: ${masterInfo['ip']}, Port: ${masterInfo['port']}');
      print('  Slave device IP: ${slaveInfo['ip']}, Port: ${slaveInfo['port']}');
      
      // Step 3: Technician configures each device with the other's information
      // (simulating adding to distributed routing table)
      if (slaveInfo['ip'] != null && slaveInfo['port'] != null) {
        final slaveForMaster = IceCandidate(
          'configured',
          slaveInfo['ip'] as String,
          slaveInfo['port'] as int,
          140,  // Priority for configured candidates
          foundation: 'tech_config'
        );
        masterDevice.addRemoteCandidate(slaveForMaster);
        print('Technician configured Master with Slave info: ${slaveInfo['address']}');
      }
      
      if (masterInfo['ip'] != null && masterInfo['port'] != null) {
        final masterForSlave = IceCandidate(
          'configured',
          masterInfo['ip'] as String,
          masterInfo['port'] as int,
          140,  // Priority for configured candidates
          foundation: 'tech_config'
        );
        slaveDevice.addRemoteCandidate(masterForSlave);
        print('Technician configured Slave with Master info: ${masterInfo['address']}');
      }
      
      await Future.delayed(Duration(seconds: 2));
      
      // Step 4: Devices can now communicate
      var masterReceivedCount = 0;
      var slaveReceivedCount = 0;
      
      masterDevice.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        if (message != 'Connection established!') {
          masterReceivedCount++;
          print('Master received: $message');
        }
      });
      
      slaveDevice.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        if (message != 'Connection established!') {
          slaveReceivedCount++;
          print('Slave received: $message');
        }
      });
      
      // Step 5: Send test communications
      masterDevice.send(Uint8List.fromList('Playlist update from master'.codeUnits));
      slaveDevice.send(Uint8List.fromList('Status report from slave'.codeUnits));
      
      await Future.delayed(Duration(seconds: 3));
      
      print('\\nCommunication results:');
      print('  Master received: $masterReceivedCount messages');
      print('  Slave received: $slaveReceivedCount messages');
      
      // Cleanup
      masterDevice.close();
      slaveDevice.close();
      
      print('\\nTechnician configuration workflow completed successfully!');
    }, timeout: Timeout(Duration(seconds: 30)));
  });
}