import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:core_lib/p2p_socket.dart';

void main() {
  group('P2PSocket Automatic IP Discovery Test', () {
    test('Auto-discover IPs and use in communication', () async {
      final socketA = P2PSocket(peerId: 'device_a');
      final socketB = P2PSocket(peerId: 'device_b');
      
      print('Socket A - Initial state:');
      print('  Discovered Public IP: ${socketA.discoveredPublicIp}');
      print('  Discovered Private IP: ${socketA.discoveredPrivateIp}');
      print('  Local Port: ${socketA.localPort}');
      
      print('Socket B - Initial state:');
      print('  Discovered Public IP: ${socketB.discoveredPublicIp}');
      print('  Discovered Private IP: ${socketB.discoveredPrivateIp}');
      print('  Local Port: ${socketB.localPort}');
      
      // Wait for IP discovery
      await Future.wait([
        socketA.gatherCandidates(),
        socketB.gatherCandidates()
      ]).timeout(Duration(seconds: 15), onTimeout: () => [Future.value(), Future.value()]);
      
      // Add a small delay to ensure IP discovery is complete
      await Future.delayed(Duration(seconds: 3));
      
      print('After IP discovery:');
      print('Socket A - Discovered Public IP: ${socketA.discoveredPublicIp}');
      print('Socket A - Discovered Private IP: ${socketA.discoveredPrivateIp}');
      print('Socket A - Local Port: ${socketA.localPort}');
      
      print('Socket B - Discovered Public IP: ${socketB.discoveredPublicIp}');
      print('Socket B - Discovered Private IP: ${socketB.discoveredPrivateIp}');
      print('Socket B - Local Port: ${socketB.localPort}');
      
      // Now use the discovered IPs to set up communication
      // Get socketA's public IP and port to add to socketB as a remote candidate
      if (socketA.discoveredPublicIp != null && socketA.localPort != null) {
        final socketACandidate = IceCandidate('discovered', socketA.discoveredPublicIp!, socketA.localPort!, 120);
        socketB.addRemoteCandidate(socketACandidate);
        print('Added Socket A (${socketA.discoveredPublicIp}:${socketA.localPort}) to Socket B');
      }
      
      // Get socketB's public IP and port to add to socketA as a remote candidate
      if (socketB.discoveredPublicIp != null && socketB.localPort != null) {
        final socketBCandidate = IceCandidate('discovered', socketB.discoveredPublicIp!, socketB.localPort!, 120);
        socketA.addRemoteCandidate(socketBCandidate);
        print('Added Socket B (${socketB.discoveredPublicIp}:${socketB.localPort}) to Socket A');
      }
      
      // Wait for connection establishment
      await Future.delayed(Duration(seconds: 3));
      
      // Set up message tracking 
      var messageReceivedByA = false;
      var messageReceivedByB = false;
      var connectionEstablishedA = false;
      var connectionEstablishedB = false;
      
      socketA.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        if (message == 'Connection established!') {
          connectionEstablishedA = true;
          print('Socket A: Connection established');
        } else {
          print('Socket A received: $message');
          messageReceivedByA = true;
        }
      });
      
      socketB.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        if (message == 'Connection established!') {
          connectionEstablishedB = true;
          print('Socket B: Connection established');
        } else {
          print('Socket B received: $message');
          messageReceivedByB = true;
        }
      });
      
      // Send test messages
      socketA.send(Uint8List.fromList('Hello from A using auto-discovered IPs'.codeUnits));
      socketB.send(Uint8List.fromList('Hello from B using auto-discovered IPs'.codeUnits));
      
      await Future.delayed(Duration(seconds: 5));
      
      print('Results:');
      print('  A connection established: $connectionEstablishedA');
      print('  B connection established: $connectionEstablishedB');
      print('  A received message: $messageReceivedByA');
      print('  B received message: $messageReceivedByB');
      
      socketA.close();
      socketB.close();
    }, timeout: Timeout(Duration(seconds: 40)));
    
    test('Test with multiple instances auto-discovering IPs', () async {
      const numInstances = 3;
      final sockets = <P2PSocket>[];
      final ipDiscoveryCompleters = <Completer<void>>[];
      
      // Create multiple instances with auto IP discovery
      for (int i = 0; i < numInstances; i++) {
        final socket = P2PSocket(peerId: 'multi_instance_$i');
        sockets.add(socket);
        ipDiscoveryCompleters.add(Completer<void>());
      }
      
      // Track discovered IPs
      final discoveredIps = List<String?>.filled(numInstances, null);
      final discoveredPorts = List<int?>.filled(numInstances, null);
      
      // Listen for IP discovery
      for (int i = 0; i < numInstances; i++) {
        sockets[i].onCandidate.listen((candidate) {
          if (candidate.type == 'srflx' || (candidate.type == 'host' && discoveredIps[i] == null)) {
            discoveredIps[i] = candidate.address;
            discoveredPorts[i] = (candidate.type == 'srflx') ? candidate.port : sockets[i].localPort;
            if (!ipDiscoveryCompleters[i].isCompleted) {
              ipDiscoveryCompleters[i].complete();
            }
            print('Instance $i discovered IP: ${candidate.address}:${candidate.port} (type: ${candidate.type})');
          }
        });
      }
      
      // Start IP discovery for all instances
      final futures = <Future>[];
      for (final socket in sockets) {
        futures.add(socket.gatherCandidates().timeout(Duration(seconds: 8), 
          onTimeout: () => Future.value()));
      }
      
      await Future.wait(futures, eagerError: false);
      await Future.delayed(Duration(seconds: 2));
      
      // Add all discovered IPs to each other (like a distributed routing table)
      for (int i = 0; i < numInstances; i++) {
        for (int j = 0; j < numInstances; j++) {
          if (i != j && discoveredIps[j] != null && discoveredPorts[j] != null) {
            final remoteCandidate = IceCandidate('discovered', discoveredIps[j]!, discoveredPorts[j]!, 110);
            sockets[i].addRemoteCandidate(remoteCandidate);
            print('Added instance $j (${discoveredIps[j]}:${discoveredPorts[j]}) to instance $i');
          }
        }
      }
      
      await Future.delayed(Duration(seconds: 3));
      
      // Test communication
      var totalMessagesReceived = 0;
      
      for (int i = 0; i < numInstances; i++) {
        sockets[i].onMessage.listen((data) {
          final message = String.fromCharCodes(data);
          if (message != 'Connection established!') {
            totalMessagesReceived++;
            print('Instance $i received: $message');
          }
        });
      }
      
      // Send messages from each instance to others
      for (int i = 0; i < numInstances; i++) {
        final message = 'Message from instance $i';
        sockets[i].send(Uint8List.fromList(message.codeUnits));
      }
      
      await Future.delayed(Duration(seconds: 5));
      
      print('Multi-instance results:');
      print('  Total messages received: $totalMessagesReceived');
      
      // Close all sockets
      for (final socket in sockets) {
        socket.close();
      }
    }, timeout: Timeout(Duration(seconds: 60)));
  });
}