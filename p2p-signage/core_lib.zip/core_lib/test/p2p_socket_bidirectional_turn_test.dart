import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:core_lib/p2p_socket.dart';

void main() {
  group('P2PSocket Bidirectional TURN Test', () {
    test('Test P2PSocket acting as TURN server', () async {
      // Create a P2PSocket that acts as a TURN server
      final turnServerSocket = P2PSocket(
        peerId: 'turn_server',
        enableTurnServer: true,  // Enable TURN server functionality
      );
      
      var serverCandidateReceived = false;
      
      // Listen for candidates
      turnServerSocket.onCandidate.listen((candidate) {
        print('TURN Server candidate: ${candidate.type} - ${candidate.address}:${candidate.port}');
        serverCandidateReceived = true;
      });
      
      // Gather candidates for the server socket
      await turnServerSocket.gatherCandidates().timeout(Duration(seconds: 5), onTimeout: () => Future.value());
      
      await Future.delayed(Duration(seconds: 2));
      
      print('Server candidate received: $serverCandidateReceived');
      
      // Close the socket
      turnServerSocket.close();
    }, timeout: Timeout(Duration(seconds: 30)));
    
    test('Test multiple P2PSockets with mixed TURN roles', () async {
      // Create several sockets with different roles
      final sockets = <P2PSocket>[];
      
      // Create one that acts as a TURN server
      final turnServer = P2PSocket(
        peerId: 'main_turn_server',
        enableTurnServer: true,
      );
      sockets.add(turnServer);
      
      // Create clients that might connect to TURN servers
      for (int i = 0; i < 3; i++) {
        final clientSocket = P2PSocket(
          peerId: 'client_$i',
        );
        sockets.add(clientSocket);
      }
      
      // Track candidates
      final candidateCounts = List.filled(sockets.length, 0);
      
      for (int i = 0; i < sockets.length; i++) {
        sockets[i].onCandidate.listen((candidate) {
          candidateCounts[i]++;
          print('Socket ${sockets[i].peerId} received candidate: ${candidate.type}');
        });
      }
      
      // Start gathering candidates
      final futures = <Future>[];
      for (final socket in sockets) {
        futures.add(socket.gatherCandidates().timeout(Duration(seconds: 5), 
          onTimeout: () => Future.value()));
      }
      
      await Future.wait(futures, eagerError: false);
      await Future.delayed(Duration(seconds: 2));
      
      // Check how many candidates each socket received
      for (int i = 0; i < sockets.length; i++) {
        print('Socket ${sockets[i].peerId} received ${candidateCounts[i]} candidates');
      }
      
      // Validate that the TURN server socket was properly configured
      expect(turnServer.isTurnServer, true);
      
      // Close all sockets
      for (final socket in sockets) {
        socket.close();
      }
    }, timeout: Timeout(Duration(seconds: 30)));
    
    test('Test TURN server functionality verification', () async {
      final turnServerSocket = P2PSocket(
        peerId: 'verification_server',
        enableTurnServer: true,
      );
      
      // Verify that the server is configured to act as a TURN server
      expect(turnServerSocket.isTurnServer, true);
      
      // Verify the socket is bound by attempting to gather candidates
      await turnServerSocket.gatherCandidates().timeout(Duration(seconds: 5), 
        onTimeout: () => Future.value());
      
      print('TURN server initialized and ready');
      
      // Close the socket
      turnServerSocket.close();
    }, timeout: Timeout(Duration(seconds: 30)));
  });
}