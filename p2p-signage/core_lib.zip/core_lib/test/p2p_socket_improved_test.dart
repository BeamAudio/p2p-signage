import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:core_lib/p2p_socket.dart';

void main() {
  group('P2PSocket Improved Connection Test', () {
    test('Test reliable connection establishment and message delivery', () async {
      final socketA = P2PSocket(peerId: 'reliable_test_a');
      final socketB = P2PSocket(peerId: 'reliable_test_b');
      
      // Track messages received by each socket
      final messagesA = <String>[];
      final messagesB = <String>[];
      
      // Track connection establishment
      var connectionEstablishedA = false;
      var connectionEstablishedB = false;
      
      // Set up message listeners
      socketA.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        if (message == 'Connection established!') {
          connectionEstablishedA = true;
          print('Socket A: Connection established');
        } else {
          messagesA.add(message);
          print('Socket A received: $message');
        }
      });
      
      socketB.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        if (message == 'Connection established!') {
          connectionEstablishedB = true;
          print('Socket B: Connection established');
        } else {
          messagesB.add(message);
          print('Socket B received: $message');
        }
      });
      
      // Set up candidate exchange
      socketA.onCandidate.listen((candidate) {
        socketB.addRemoteCandidate(candidate);
        print('Socket A sharing candidate: ${candidate.address}:${candidate.port}');
      });
      
      socketB.onCandidate.listen((candidate) {
        socketA.addRemoteCandidate(candidate);
        print('Socket B sharing candidate: ${candidate.address}:${candidate.port}');
      });
      
      // Start gathering candidates
      await Future.wait([
        socketA.gatherCandidates(),
        socketB.gatherCandidates()
      ]).timeout(Duration(seconds: 10), onTimeout: () => [Future.value(), Future.value()]);
      
      await Future.delayed(Duration(seconds: 3));
      
      // Send a test message from A to B
      const testMessage = 'Hello from A to B';
      socketA.send(Uint8List.fromList(testMessage.codeUnits));
      print('Socket A sent: $testMessage');
      
      // Wait a bit for the message to be received
      await Future.delayed(Duration(seconds: 2));
      
      // Send a response from B to A
      const responseMessage = 'Hello from B to A';
      socketB.send(Uint8List.fromList(responseMessage.codeUnits));
      print('Socket B sent: $responseMessage');
      
      // Wait to receive the response
      await Future.delayed(Duration(seconds: 2));
      
      // Check results
      print('Results:');
      print('  Connection A established: $connectionEstablishedA');
      print('  Connection B established: $connectionEstablishedB');
      print('  Messages A received: ${messagesA.length} (${messagesA.join(", ")})');
      print('  Messages B received: ${messagesB.length} (${messagesB.join(", ")})');
      
      // Close sockets
      socketA.close();
      socketB.close();
    }, timeout: Timeout(Duration(seconds: 40)));
    
    test('Test message delivery with fallback mechanisms', () async {
      final socketA = P2PSocket(peerId: 'fallback_test_a');
      final socketB = P2PSocket(peerId: 'fallback_test_b');
      
      final receivedMessages = <String>[];
      final messageReceivedCompleter = Completer<void>();
      
      // Set up listeners
      socketB.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        if (message != 'Connection established!') {
          receivedMessages.add(message);
          print('Socket B received: $message');
          if (!messageReceivedCompleter.isCompleted) {
            messageReceivedCompleter.complete();
          }
        }
      });
      
      socketA.onCandidate.listen((candidate) {
        socketB.addRemoteCandidate(candidate);
      });
      
      socketB.onCandidate.listen((candidate) {
        socketA.addRemoteCandidate(candidate);
      });
      
      // Start gathering candidates
      await Future.wait([
        socketA.gatherCandidates(),
        socketB.gatherCandidates()
      ]).timeout(Duration(seconds: 10), onTimeout: () => [Future.value(), Future.value()]);
      
      await Future.delayed(Duration(seconds: 3));
      
      // Send message
      const message = 'Test message with fallback';
      socketA.send(Uint8List.fromList(message.codeUnits));
      print('Socket A sent: $message');
      
      try {
        // Wait for message to be received with timeout
        await messageReceivedCompleter.future.timeout(Duration(seconds: 10));
        print('Message successfully delivered with fallback mechanisms');
      } catch (e) {
        print('Message delivery timed out: $e');
        // This is expected in some network configurations
      }
      
      socketA.close();
      socketB.close();
    }, timeout: Timeout(Duration(seconds: 40)));
    
    test('Test periodic connectivity checks', () async {
      final socketA = P2PSocket(peerId: 'periodic_test_a');
      final socketB = P2PSocket(peerId: 'periodic_test_b');
      
      var messageCount = 0;
      final messageCompleter = Completer<int>();
      
      // Track messages from A to B
      socketB.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        if (message.startsWith('Periodic message')) {
          messageCount++;
          print('Received periodic message: $message');
          if (messageCount >= 2 && !messageCompleter.isCompleted) {
            messageCompleter.complete(messageCount);
          }
        }
      });
      
      // Set up candidate exchange
      socketA.onCandidate.listen((candidate) {
        socketB.addRemoteCandidate(candidate);
      });
      
      socketB.onCandidate.listen((candidate) {
        socketA.addRemoteCandidate(candidate);
      });
      
      // Start gathering candidates
      await Future.wait([
        socketA.gatherCandidates(),
        socketB.gatherCandidates()
      ]).timeout(Duration(seconds: 10), onTimeout: () => [Future.value(), Future.value()]);
      
      await Future.delayed(Duration(seconds: 2));
      
      // Send multiple messages over time to test connectivity maintenance
      for (int i = 0; i < 3; i++) {
        final message = 'Periodic message $i';
        socketA.send(Uint8List.fromList(message.codeUnits));
        print('Sent: $message');
        await Future.delayed(Duration(seconds: 1));
      }
      
      try {
        final count = await messageCompleter.future.timeout(Duration(seconds: 10));
        print('Successfully received $count periodic messages');
      } catch (e) {
        print('Periodic message test completed with $messageCount messages received');
      }
      
      socketA.close();
      socketB.close();
    }, timeout: Timeout(Duration(seconds: 40)));
  });
}