import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:core_lib/p2p_socket.dart';

void main() {
  group('P2PSocket Same Device Functionality Test', () {
    test('Test functionality with both sockets on same device', () async {
      print('=== Testing P2PSocket functionality on same device ===');
      
      // Both sockets will use the same network interface but different ports
      // In a real scenario, each device would have its own unique IP
      // But for testing on same device, we'll simulate that they each have their own identity
      
      final socketA = P2PSocket(
        peerId: 'device_a',
        // For same-device testing, we'll use localhost equivalents
      );
      
      final socketB = P2PSocket(
        peerId: 'device_b',
        // For same-device testing, we'll use localhost equivalents
      );
      
      // Start socket initialization
      await Future.wait([
        socketA.gatherCandidates(),
        socketB.gatherCandidates()
      ]).timeout(Duration(seconds: 10), onTimeout: () => [Future.value(), Future.value()]);
      
      await Future.delayed(Duration(seconds: 1));
      
      print('Socket A - Private IP: ${socketA.discoveredPrivateIp}, Port: ${socketA.localPort}');
      print('Socket B - Private IP: ${socketB.discoveredPrivateIp}, Port: ${socketB.localPort}');
      
      // In a real system, the distributed routing table would exchange public IPs
      // For same-device testing, we'll exchange the private IPs as if they were public
      // This simulates the case where both devices are on the same network
      
      if (socketA.discoveredPrivateIp != null && socketA.localPort != null) {
        final aInfo = IceCandidate(
          'network', 
          socketA.discoveredPrivateIp!, 
          socketA.localPort!, 
          120,
          foundation: 'local_network'
        );
        socketB.addRemoteCandidate(aInfo);
        print('Added Device A (${aInfo.address}:${aInfo.port}) to Device B');
      }
      
      if (socketB.discoveredPrivateIp != null && socketB.localPort != null) {
        final bInfo = IceCandidate(
          'network', 
          socketB.discoveredPrivateIp!, 
          socketB.localPort!, 
          120,
          foundation: 'local_network'
        );
        socketA.addRemoteCandidate(bInfo);
        print('Added Device B (${bInfo.address}:${bInfo.port}) to Device A');
      }
      
      await Future.delayed(Duration(seconds: 2));
      
      // Track messages
      final receivedByA = <String>[];
      final receivedByB = <String>[];
      var connectionEstablishedA = false;
      var connectionEstablishedB = false;
      
      socketA.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        if (message == 'Connection established!') {
          connectionEstablishedA = true;
          print('Device A: Connection established');
        } else {
          receivedByA.add(message);
          print('Device A received: $message');
        }
      });
      
      socketB.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        if (message == 'Connection established!') {
          connectionEstablishedB = true;
          print('Device B: Connection established');
        } else {
          receivedByB.add(message);
          print('Device B received: $message');
        }
      });
      
      // Send test messages between devices
      socketA.send(Uint8List.fromList('Hello from Device A'.codeUnits));
      socketB.send(Uint8List.fromList('Hello from Device B'.codeUnits));
      
      await Future.delayed(Duration(seconds: 3));
      
      // Send more messages
      socketA.send(Uint8List.fromList('Second message from A'.codeUnits));
      socketB.send(Uint8List.fromList('Second message from B'.codeUnits));
      
      await Future.delayed(Duration(seconds: 2));
      
      print('\nResults:');
      print('  A connection established: $connectionEstablishedA');
      print('  B connection established: $connectionEstablishedB');
      print('  Messages received by A: ${receivedByA.length} (${receivedByA.join(", ")})');
      print('  Messages received by B: ${receivedByB.length} (${receivedByB.join(", ")})');
      
      // Verify functionality
      expect(socketA.discoveredPrivateIp, isNotNull);
      expect(socketB.discoveredPrivateIp, isNotNull);
      expect(socketA.localPort, greaterThan(0));
      expect(socketB.localPort, greaterThan(0));
      expect(socketA.localPort, isNot(equals(socketB.localPort))); // Different ports
      
      socketA.close();
      socketB.close();
    }, timeout: Timeout(Duration(seconds: 40)));
    
    test('Test same device with simulated real IPs', () async {
      print('\n=== Testing with simulated real device IPs on same device ===');
      
      // Test using dynamically discovered IPs
      final socketA = P2PSocket(
        peerId: 'simulated_device_1',
      );
      
      final socketB = P2PSocket(
        peerId: 'simulated_device_2',
      );
      
      // Wait for IP discovery
      await Future.delayed(Duration(seconds: 3));
      
      // Use the discovered IPs or fallback to local IPs
      final socketAIP = socketA.publicIp ?? (socketA.localIps.isNotEmpty ? socketA.localIps[0].address : '127.0.0.1');
      final socketBIP = socketB.publicIp ?? (socketB.localIps.isNotEmpty ? socketB.localIps[0].address : '127.0.0.1');
      final commonPortA = 8080;  // Use common port for communication
      final commonPortB = 8081;  // Use common port for communication
      
      print('Socket A - Discovered IP: $socketAIP');
      print('Socket A - Local IPs: ${socketA.localIps.map((ip) => ip.address).join(", ")}');
      print('Socket B - Discovered IP: $socketBIP');
      print('Socket B - Local IPs: ${socketB.localIps.map((ip) => ip.address).join(", ")}');
      
      // Initialize sockets
      await Future.wait([
        socketA.gatherCandidates(),
        socketB.gatherCandidates()
      ]).timeout(Duration(seconds: 10), onTimeout: () => [Future.value(), Future.value()]);
      
      await Future.delayed(Duration(seconds: 1));
      
      print('Socket A - Actual private IP: ${socketA.discoveredPrivateIp}, Port: ${socketA.localPort}');
      print('Socket B - Actual private IP: ${socketB.discoveredPrivateIp}, Port: ${socketB.localPort}');
      
      // Exchange candidates using the discovered IPs
      final aAsSeenByNetwork = IceCandidate(
        'discovered', 
        socketAIP, 
        commonPortA, 
        150,  // High priority
        foundation: 'discovered'
      );
      
      final bAsSeenByNetwork = IceCandidate(
        'discovered', 
        socketBIP, 
        commonPortB, 
        150,  // High priority
        foundation: 'discovered'
      );
      
      socketB.addRemoteCandidate(aAsSeenByNetwork);
      socketA.addRemoteCandidate(bAsSeenByNetwork);
      
      print('Exchanged discovered IPs between devices');
      
      await Future.delayed(Duration(seconds: 2));
      
      // Message tracking
      var messagesA = 0;
      var messagesB = 0;
      
      socketA.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        if (message != 'Connection established!') {
          messagesA++;
          print('Socket A received: $message');
        }
      });
      
      socketB.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        if (message != 'Connection established!') {
          messagesB++;
          print('Socket B received: $message');
        }
      });
      
      // Send messages
      socketA.send(Uint8List.fromList('Test from A using configured IP'.codeUnits));
      socketB.send(Uint8List.fromList('Test from B using configured IP'.codeUnits));
      
      await Future.delayed(Duration(seconds: 3));
      
      print('Same device test results:');
      print('  Messages received by A: $messagesA');
      print('  Messages received by B: $messagesB');
      
      socketA.close();
      socketB.close();
    }, timeout: Timeout(Duration(seconds: 40)));
  });
}