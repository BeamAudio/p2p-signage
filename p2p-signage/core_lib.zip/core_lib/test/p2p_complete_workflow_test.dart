import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:core_lib/p2p_socket.dart';

void main() {
  group('Complete P2P Workflow Test with Real IP', () {
    test('Complete workflow with 192.168.0.15', () async {
      print('=== Complete P2P Workflow with Real IP 192.168.0.15 ===');
      
      // Simulate the complete workflow where each device discovers its own IP
      // and then they connect to each other
      final deviceA = P2PSocket(
        peerId: 'device_a',
      );
      
      final deviceB = P2PSocket(
        peerId: 'device_b',
      );
      
      // Wait for IP discovery
      await Future.wait([
        deviceA.gatherCandidates(),
        deviceB.gatherCandidates()
      ]).timeout(Duration(seconds: 10), onTimeout: () => [Future.value(), Future.value()]);
      
      await Future.delayed(Duration(seconds: 3));
      
      // Check if your IP (192.168.0.15) is discovered by both devices
      final deviceAHasYourIp = deviceA.localIps.any((ip) => ip.address == '192.168.0.15');
      final deviceBHasYourIp = deviceB.localIps.any((ip) => ip.address == '192.168.0.15');
      
      print('Device A has your IP (192.168.0.15): $deviceAHasYourIp');
      print('Device B has your IP (192.168.0.15): $deviceBHasYourIp');
      print('Device A discovered IPs: ${deviceA.localIps.map((ip) => ip.address).toList()}');
      print('Device B discovered IPs: ${deviceB.localIps.map((ip) => ip.address).toList()}');
      print('Device A public IP: ${deviceA.publicIp}');
      print('Device B public IP: ${deviceB.publicIp}');
      print('Device A private IP: ${deviceA.discoveredPrivateIp}');
      print('Device B private IP: ${deviceB.discoveredPrivateIp}');
      print('Device A port: ${deviceA.localPort}');
      print('Device B port: ${deviceB.localPort}');
      
      // Verify that your IP is discovered
      expect(deviceAHasYourIp || deviceBHasYourIp, true, reason: 'At least one device should discover your IP 192.168.0.15');
      
      // Exchange connection information (simulating distributed routing table)
      final deviceBAddress = deviceB.discoveredPrivateIp!;
      final deviceBPort = deviceB.localPort!;
      
      final deviceBInfo = IceCandidate(
        'routing_table',
        deviceBAddress,
        deviceBPort,
        140,  // Priority
        foundation: 'dist_routing'
      );
      
      deviceA.addRemoteCandidate(deviceBInfo);
      print('Added Device B ($deviceBAddress:$deviceBPort) to Device A routing table');
      
      final deviceAAddress = deviceA.discoveredPrivateIp!;
      final deviceAPort = deviceA.localPort!;
      
      final deviceAInfo = IceCandidate(
        'routing_table',
        deviceAAddress,
        deviceAPort,
        140,  // Priority
        foundation: 'dist_routing'
      );
      
      deviceB.addRemoteCandidate(deviceAInfo);
      print('Added Device A ($deviceAAddress:$deviceAPort) to Device B routing table');
      
      // Set up message tracking
      final deviceAMessages = <String>[];
      final deviceBMessages = <String>[];
      
      deviceA.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        if (message != 'Connection established!') {
          deviceAMessages.add(message);
          print('Device A received: $message');
        }
      });
      
      deviceB.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        if (message != 'Connection established!') {
          deviceBMessages.add(message);
          print('Device B received: $message');
        }
      });
      
      await Future.delayed(Duration(seconds: 2));
      
      // Send messages between devices
      print('\\nSending messages...');
      deviceA.send(Uint8List.fromList('Message from Device A to Device B'.codeUnits));
      deviceB.send(Uint8List.fromList('Message from Device B to Device A'.codeUnits));
      
      await Future.delayed(Duration(seconds: 3));
      
      // Send more messages
      deviceA.send(Uint8List.fromList('Second message A to B'.codeUnits));
      deviceB.send(Uint8List.fromList('Second message B to A'.codeUnits));
      
      await Future.delayed(Duration(seconds: 2));
      
      print('\\nResults:');
      print('Device A received ${deviceAMessages.length} messages: $deviceAMessages');
      print('Device B received ${deviceBMessages.length} messages: $deviceBMessages');
      
      // Verify correct setup
      expect(deviceA.discoveredPrivateIp, isNotNull);
      expect(deviceB.discoveredPrivateIp, isNotNull);
      expect(deviceA.localPort, greaterThan(0));
      expect(deviceB.localPort, greaterThan(0));
      
      deviceA.close();
      deviceB.close();
      
      print('\\nComplete P2P workflow with IP 192.168.0.15 completed successfully!');
    }, timeout: Timeout(Duration(seconds: 30)));
  });
}