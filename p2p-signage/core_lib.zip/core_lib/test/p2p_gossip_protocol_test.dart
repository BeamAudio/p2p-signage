import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:core_lib/p2p_socket.dart';

void main() {
  group('P2PSocket Gossip Protocol Test', () {
    test('Verify gossip protocol results in 100% network reach', () async {
      print('=== Gossip Protocol 100% Network Reach Test ===');
      
      // Create 10 P2PSocket instances (devices)
      final devices = <P2PSocket>[];
      final deviceIds = <String>[];
      
      for (int i = 0; i < 10; i++) {
        final deviceId = 'device_${i.toString().padLeft(2, '0')}';
        deviceIds.add(deviceId);
        final device = P2PSocket(
          peerId: deviceId,
        );
        devices.add(device);
      }
      
      print('Created ${devices.length} devices');
      
      // Start gathering candidates for all devices to discover IPs
      print('Starting IP discovery for all devices...');
      final futures = <Future>[];
      for (final device in devices) {
        futures.add(device.gatherCandidates());
      }
      
      try {
        await Future.wait(futures, eagerError: true).timeout(Duration(seconds: 15));
      } catch (e) {
        print('Some devices had timeout during candidate gathering: $e');
      }
      
      // Wait for IP discovery to complete
      await Future.delayed(Duration(seconds: 3));
      
      // Print discovered information for each device
      print('\\nDiscovered information for all devices:');
      for (int i = 0; i < devices.length; i++) {
        print('  Device ${i.toString().padLeft(2)}: IP=${devices[i].discoveredPrivateIp}, Port=${devices[i].localPort}, PublicIP=${devices[i].publicIp}');
      }
      
      // Connect devices in a chain with gossip protocol
      print('\\n=== Building network with gossip protocol ===');
      
      for (int i = 1; i < devices.length; i++) {
        final currentDevice = devices[i];
        final previousDevice = devices[i-1];
        
        print('\\n--- Connecting Device ${i.toString().padLeft(2, '0')} via Device ${(i-1).toString().padLeft(2, '0')} ---');
        
        // Direct connection between current and previous device
        if (previousDevice.discoveredPrivateIp != null && previousDevice.localPort != null) {
          final prevInfo = IceCandidate(
            'direct_connect',
            previousDevice.discoveredPrivateIp!,
            previousDevice.localPort!,
            150, // Higher priority for direct connections
            foundation: 'direct'
          );
          currentDevice.addRemoteCandidate(prevInfo);
          print('  Direct: Added Device ${(i-1).toString().padLeft(2, '0')} (${previousDevice.discoveredPrivateIp}:${previousDevice.localPort}) to Device ${i.toString().padLeft(2, '0')}');
        }
        
        if (currentDevice.discoveredPrivateIp != null && currentDevice.localPort != null) {
          final currentInfo = IceCandidate(
            'direct_connect',
            currentDevice.discoveredPrivateIp!,
            currentDevice.localPort!,
            150, // Higher priority for direct connections
            foundation: 'direct'
          );
          previousDevice.addRemoteCandidate(currentInfo);
          print('  Direct: Added Device ${i.toString().padLeft(2, '0')} (${currentDevice.discoveredPrivateIp}:${currentDevice.localPort}) to Device ${(i-1).toString().padLeft(2, '0')}');
        }
        
        // Now implement the gossip protocol - previous device shares all known devices with current device
        for (int j = 0; j < i-1; j++) { // Share all devices before the previous one
          final gossipDevice = devices[j];
          if (gossipDevice.discoveredPrivateIp != null && gossipDevice.localPort != null) {
            // Add to current device (the new one)
            final gossipInfo = IceCandidate(
              'gossip',
              gossipDevice.discoveredPrivateIp!,
              gossipDevice.localPort!,
              140, // Slightly lower priority than direct
              foundation: 'gossip_from_${(i-1).toString().padLeft(2, '0')}'
            );
            currentDevice.addRemoteCandidate(gossipInfo);
            print('  Gossip: Device ${(i-1).toString().padLeft(2, '0')} shared Device ${j.toString().padLeft(2, '0')} (${gossipDevice.discoveredPrivateIp}:${gossipDevice.localPort}) with Device ${i.toString().padLeft(2, '0')}');
            
            // Also add the new device to the gossiped device (bidirectional)
            final backGossipInfo = IceCandidate(
              'gossip',
              currentDevice.discoveredPrivateIp!,
              currentDevice.localPort!,
              140,
              foundation: 'gossip_to_${i.toString().padLeft(2, '0')}'
            );
            gossipDevice.addRemoteCandidate(backGossipInfo);
            print('  Gossip: Device ${i.toString().padLeft(2, '0')} shared with Device ${j.toString().padLeft(2, '0')} (reverse gossip)');
          }
        }
        
        await Future.delayed(Duration(milliseconds: 500)); // Small delay between connections
      }
      
      print('\\n=== Network Building Complete ===');
      
      // Wait for all gossip to propagate
      await Future.delayed(Duration(seconds: 3));
      
      // Now test network reach by sending a message from Device 0 to all others
      print('\\n=== Testing 100% Network Reach ===');
      
      // Set up message tracking
      final messagesReceived = List.filled(devices.length, 0);
      final totalExpectedMessages = devices.length * (devices.length - 1); // Each device sends to all others
      
      // Each device will send a message to all others it knows about
      for (int i = 0; i < devices.length; i++) {
        final senderIndex = i;
        final sender = devices[i];
        
        // Listen for messages from other devices
        sender.onMessage.listen((data) {
          final message = String.fromCharCodes(data);
          if (message.startsWith('TEST_MSG_')) {
            final parts = message.split(':');
            if (parts.length >= 2) {
              final sourceInfo = parts[0]; // Format: "TEST_MSG_from_XX"
              final sourceMatch = RegExp(r'from_(\d+)').firstMatch(sourceInfo);
              if (sourceMatch != null) {
                final sourceIndex = int.tryParse(sourceMatch.group(1)!);
                if (sourceIndex != null && sourceIndex != senderIndex) {
                  messagesReceived[senderIndex]++;
                  print('  Device ${senderIndex.toString().padLeft(2, '0')} received message from Device ${sourceIndex.toString().padLeft(2, '0')}');
                }
              }
            }
          }
        });
      }
      
      // Send test messages from each device to test full network connectivity
      print('\\nSending test messages from each device to its known peers...');
      for (int i = 0; i < devices.length; i++) {
        final senderDevice = devices[i];
        final message = 'TEST_MSG_from_${i.toString().padLeft(2, '0')}: Hello from Device ${i.toString().padLeft(2, '0')}';
        
        // Wait a bit between sends to allow processing
        await Future.delayed(Duration(milliseconds: 200));
        
        senderDevice.send(Uint8List.fromList(message.codeUnits));
        print('  Device ${i.toString().padLeft(2, '0')} sent message to its known peers');
      }
      
      // Wait for all messages to propagate
      await Future.delayed(Duration(seconds: 8));
      
      print('\\n=== Network Reach Results ===');
      
      // Calculate results
      var totalReceived = 0;
      var devicesWithMaxConnections = 0;
      
      for (int i = 0; i < devices.length; i++) {
        print('  Device ${i.toString().padLeft(2, '0')}: received ${messagesReceived[i]} messages');
        totalReceived += messagesReceived[i];
        
        // Each device should receive messages from all other devices (9 messages each)
        if (messagesReceived[i] >= devices.length - 1) {
          devicesWithMaxConnections++;
        }
      }
      
      // Each device should receive messages from all other (n-1) devices
      final expectedMessagesPerDevice = devices.length - 1;
      final totalExpectedReceived = devices.length * expectedMessagesPerDevice;
      final reachPercentage = totalExpectedReceived > 0 ? (totalReceived / totalExpectedReceived * 100) : 0;
      
      print('\\n=== Final Results ===');
      print('  Total devices: ${devices.length}');
      print('  Expected messages per device: $expectedMessagesPerDevice');
      print('  Total expected messages: $totalExpectedReceived');
      print('  Total received messages: $totalReceived');
      print('  Perfectly connected devices: $devicesWithMaxConnections out of ${devices.length}');
      print('  Network reach: ${reachPercentage.toStringAsFixed(2)}%');
      
      if (reachPercentage >= 95) { // Allow for minor timing issues
        print('  🎉 SUCCESS: Network reach is excellent (>=95%)!');
      } else {
        print('  ⚠️  Network reach could be improved');
      }
      
      // Close all devices
      for (final device in devices) {
        device.close();
      }
      
      print('\\nGossip protocol test completed!');
    }, timeout: Timeout(Duration(seconds: 60)));
  });
}