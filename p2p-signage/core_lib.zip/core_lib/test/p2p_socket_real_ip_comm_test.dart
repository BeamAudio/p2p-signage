import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:core_lib/p2p_socket.dart';

void main() {
  group('P2PSocket Real IP Communication Test', () {
    test('Test getting public and private IPs from both instances', () async {
      final socketA = P2PSocket(peerId: 'instance_a');
      final socketB = P2PSocket(peerId: 'instance_b');
      
      // Track discovered IPs
      String? publicIpA, privateIpA;
      String? publicIpB, privateIpB;
      
      // Listen for IP discovery
      socketA.onCandidate.listen((candidate) {
        if (candidate.type == 'srflx') { // Public IP via STUN
          publicIpA = candidate.address;
          print('Instance A public IP: $publicIpA');
        } else if (candidate.type == 'host') { // Private IP
          privateIpA = candidate.address;
          print('Instance A private IP: $privateIpA');
        }
      });
      
      socketB.onCandidate.listen((candidate) {
        if (candidate.type == 'srflx') { // Public IP via STUN
          publicIpB = candidate.address;
          print('Instance B public IP: $publicIpB');
        } else if (candidate.type == 'host') { // Private IP
          privateIpB = candidate.address;
          print('Instance B private IP: $privateIpB');
        }
      });
      
      // Start gathering candidates (includes STUN discovery)
      await Future.wait([
        socketA.gatherCandidates(),
        socketB.gatherCandidates()
      ]).timeout(Duration(seconds: 10), onTimeout: () => [Future.value(), Future.value()]);
      
      await Future.delayed(Duration(seconds: 2));
      
      // Verify the IP properties are accessible
      print('Socket A - Public IP: ${socketA.publicIp}');
      print('Socket A - Private IP: ${socketA.privateIp}');
      print('Socket A - Local Port: ${socketA.localPort}');
      print('Socket A - Public Address: ${socketA.publicAddress}');
      print('Socket A - Private Address: ${socketA.privateAddress}');
      
      print('Socket B - Public IP: ${socketB.publicIp}');
      print('Socket B - Private IP: ${socketB.privateIp}');
      print('Socket B - Local Port: ${socketB.localPort}');
      print('Socket B - Public Address: ${socketB.publicAddress}');
      print('Socket B - Private Address: ${socketB.privateAddress}');
      
      // Exchange the public IPs between instances (simulating the distributed routing table)
      if (socketA.publicIp != null && socketA.localPort != null) {
        final publicCandidateA = IceCandidate('srflx', socketA.publicIp!, socketA.localPort!, 100);
        socketB.addRemoteCandidate(publicCandidateA);
      }
      
      if (socketB.publicIp != null && socketB.localPort != null) {
        final publicCandidateB = IceCandidate('srflx', socketB.publicIp!, socketB.localPort!, 100);
        socketA.addRemoteCandidate(publicCandidateB);
      }
      
      await Future.delayed(Duration(seconds: 2));
      
      // Test message exchange
      var messageReceivedByA = false;
      var messageReceivedByB = false;
      
      socketA.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        if (message != 'Connection established!') {
          print('Instance A received: $message');
          messageReceivedByA = true;
        }
      });
      
      socketB.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        if (message != 'Connection established!') {
          print('Instance B received: $message');
          messageReceivedByB = true;
        }
      });
      
      // Send messages
      socketA.send(Uint8List.fromList('Hello from A'.codeUnits));
      socketB.send(Uint8List.fromList('Hello from B'.codeUnits));
      
      await Future.delayed(Duration(seconds: 3));
      
      print('Results:');
      print('  A received message: $messageReceivedByA');
      print('  B received message: $messageReceivedByB');
      
      socketA.close();
      socketB.close();
    }, timeout: Timeout(Duration(seconds: 40)));
  });
}