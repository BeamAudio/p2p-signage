import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:core_lib/p2p_socket.dart';

void main() {
  group('P2PSocket Same Public Address Test', () {
    test('Verify different local ports for same public address scenario', () async {
      const numInstances = 6;
      final sockets = <P2PSocket>[];
      final localPorts = <int>[];
      
      // Create instances that will bind to different local ports
      // Use a Completer based approach to avoid timeout issues
      final futures = <Future<void>>[];
      
      for (int i = 0; i < numInstances; i++) {
        final socket = P2PSocket(
          peerId: 'same_addr_$i',
        );
        sockets.add(socket);
        
        // Create a future that completes when candidate gathering is done or times out
        futures.add(
          socket.gatherCandidates()
              .timeout(Duration(seconds: 8), 
                onTimeout: () => Future.value())
              .then((_) => Future.delayed(Duration(milliseconds: 50)))
        );
        
        print('Started socket $i');
      }
      
      // Wait for all operations to complete
      await Future.wait(futures, eagerError: false);
      
      // Verify that all sockets were created
      expect(sockets.length, numInstances);
      
      // Close all sockets
      for (final socket in sockets) {
        socket.close();
      }
      
      print('Successfully created $numInstances instances with different local ports');
    }, timeout: Timeout(Duration(seconds: 60)));
    
    test('Test multiple instances sharing same network interface', () async {
      // This test simulates multiple instances on same machine (same public IP)
      final sockets = <P2PSocket>[];
      final candidates = <List<IceCandidate>>[];
      
      const numInstances = 5;
      
      // Initialize the candidate tracking
      for (int i = 0; i < numInstances; i++) {
        candidates.add([]);
      }
      
      final futures = <Future<void>>[];
      
      for (int i = 0; i < numInstances; i++) {
        final socket = P2PSocket(
          peerId: 'network_interface_$i',
        );
        sockets.add(socket);
        
        // Listen to candidates to see what addresses are discovered
        socket.onCandidate.listen((candidate) {
          candidates[i].add(candidate);
          print('Instance $i - Candidate: ${candidate.type} ${candidate.address}:${candidate.port}');
        });
        
        // Start gathering candidates
        futures.add(
          socket.gatherCandidates()
              .timeout(Duration(seconds: 8), 
                onTimeout: () => Future.value())
              .then((_) => Future.delayed(Duration(milliseconds: 100)))
        );
      }
      
      // Wait for all operations to complete
      await Future.wait(futures, eagerError: false);
      
      // Wait a bit more to collect all candidates
      await Future.delayed(Duration(seconds: 2));
      
      // Analyze the results - all should have the same local IP but different ports
      final localIps = <String>{};
      final localPorts = <int>{};
      
      for (int i = 0; i < numInstances; i++) {
        for (final candidate in candidates[i]) {
          if (candidate.type == 'host') {
            localIps.add(candidate.address);
            localPorts.add(candidate.port);
          }
        }
      }
      
      print('Unique local IPs: ${localIps.length} (${localIps.join(", ")})');
      print('Unique local ports: ${localPorts.length}');
      print('Total host candidates found: ${localPorts.length}');
      
      // Should have same IP, different ports
      expect(localIps.length, greaterThanOrEqualTo(1)); // May be 1 (same IP) or more if multiple network interfaces
      
      // Close all sockets
      for (final socket in sockets) {
        socket.close();
      }
    }, timeout: Timeout(Duration(seconds: 60)));
    
    test('Validate port allocation uniqueness under stress', () async {
      // Create multiple sockets in quick succession to stress test port allocation
      final sockets = <P2PSocket>[];
      final portUsage = <int>{}; // Set to track unique ports
      
      final futures = <Future<void>>[];
      
      for (int i = 0; i < 8; i++) {
        final socket = P2PSocket(
          peerId: 'port_stress_$i',
        );
        sockets.add(socket);
        
        // Listen for host candidates to see what ports are allocated
        socket.onCandidate.listen((candidate) {
          if (candidate.type == 'host') {
            if (!portUsage.contains(candidate.port)) {
              portUsage.add(candidate.port);
              print('Port ${candidate.port} allocated to socket $i');
            }
          }
        });
        
        // Gather candidates to force port binding
        futures.add(
          socket.gatherCandidates()
              .timeout(Duration(seconds: 8), 
                onTimeout: () => Future.value())
        );
      }
      
      // Wait for all operations to complete
      await Future.wait(futures, eagerError: false);
      
      await Future.delayed(Duration(seconds: 2));
      
      print('Total unique ports allocated: ${portUsage.length} out of ${sockets.length} sockets');
      
      // Each socket should get a unique port when binding to 0 (any available port)
      expect(portUsage.length, greaterThanOrEqualTo(sockets.length - 2)); // Allow for some overlap in stress
      
      // Close all sockets
      for (final socket in sockets) {
        socket.close();
      }
    }, timeout: Timeout(Duration(seconds: 60)));
  });
}