import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:crypto/crypto.dart';
import 'package:core_lib/p2p_socket.dart';

void main() {
  group('P2PSocket Large Data Integrity Test', () {
    test('Test large byte chains with checksums and verify integrity rate', () async {
      print('=== Large Data Integrity Test with Checksums ===');
      
      // Create two P2PSocket instances
      final sender = P2PSocket(
        peerId: 'sender_device',
      );
      
      final receiver = P2PSocket(
        peerId: 'receiver_device',
      );
      
      print('Created sender and receiver devices for integrity test');
      
      // Start gathering candidates to discover IPs
      print('Starting IP discovery...');
      await Future.wait([
        sender.gatherCandidates(),
        receiver.gatherCandidates()
      ]).timeout(Duration(seconds: 15), onTimeout: () => [Future.value(), Future.value()]);
      
      await Future.delayed(Duration(seconds: 3));
      
      print('Discovered device information:');
      print('  Sender Device: ${sender.discoveredPrivateIp}:${sender.localPort}');
      print('  Receiver Device: ${receiver.discoveredPrivateIp}:${receiver.localPort}');
      
      // Verify your specific IP (192.168.0.15) is discovered
      bool senderHasYourIp = sender.localIps.any((ip) => ip.address == '192.168.0.15');
      bool receiverHasYourIp = receiver.localIps.any((ip) => ip.address == '192.168.0.15');
      
      print('Your specific IP (192.168.0.15) discovered:');
      print('  In Sender: ${senderHasYourIp ? '✅ YES' : '❌ NO'}');
      print('  In Receiver: ${receiverHasYourIp ? '✅ YES' : '❌ NO'}');
      
      // Set up direct communication between devices
      print('\\nSetting up direct communication...');
      
      if (receiver.discoveredPrivateIp != null && receiver.localPort != null) {
        final receiverCandidate = IceCandidate(
          'integrity_test',
          receiver.discoveredPrivateIp!,
          receiver.localPort!,
          150,
          foundation: 'integrity_test'
        );
        sender.addRemoteCandidate(receiverCandidate);
        print('  Added Receiver (${receiver.discoveredPrivateIp}:${receiver.localPort}) to Sender');
      }
      
      if (sender.discoveredPrivateIp != null && sender.localPort != null) {
        final senderCandidate = IceCandidate(
          'integrity_test',
          sender.discoveredPrivateIp!,
          sender.localPort!,
          150,
          foundation: 'integrity_test'
        );
        receiver.addRemoteCandidate(senderCandidate);
        print('  Added Sender (${sender.discoveredPrivateIp}:${sender.localPort}) to Receiver');
      }
      
      await Future.delayed(Duration(seconds: 2));
      
      // Set up message tracking with integrity verification
      print('\\nSetting up integrity verification tracking...');
      
      final receivedMessages = <Map<String, dynamic>>[];
      final integrityResults = <String, bool>{};
      final messageSizes = <int>[];
      final checksums = <String>[];
      
      receiver.onMessage.listen((data) {
        try {
          final jsonString = String.fromCharCodes(data);
          final messageData = jsonDecode(jsonString) as Map<String, dynamic>;
          
          if (messageData.containsKey('type') && 
              messageData['type'] == 'large_data_chunk') {
            receivedMessages.add(messageData);
            messageSizes.add(data.length);
            
            // Verify integrity using checksum
            final receivedChecksum = messageData['checksum'].toString();
            final chunkData = base64Decode(messageData['data'].toString());
            final calculatedChecksum = _calculateChecksum(chunkData);
            
            final isIntegrityOk = receivedChecksum == calculatedChecksum;
            integrityResults[messageData['chunk_id'].toString()] = isIntegrityOk;
            checksums.add(receivedChecksum);
            
            print('Received chunk ${messageData['chunk_id']}: ${chunkData.length} bytes, integrity: ${isIntegrityOk ? '✅ OK' : '❌ FAILED'}');
          } else {
            // Handle other messages
            print('Received other message (${data.length} bytes): ${jsonString.substring(0, min(jsonString.length, 50))}${jsonString.length > 50 ? '...' : ''}');
          }
        } catch (e) {
          print('Error processing received message: $e');
        }
      });
      
      await Future.delayed(Duration(seconds: 2));
      
      // Generate and send large byte chains with checksums
      print('\\n=== Generating Large Byte Chains ===');
      
      // Create large data payloads of different sizes
      final testDataSizes = [1024, 4096, 16384, 65536, 262144, 1048576]; // 1KB to 1MB
      final totalChunksToSend = testDataSizes.length * 5; // 5 chunks per size
      final chunkSize = 32768; // 32KB chunks
      
      print('Test data sizes: ${testDataSizes.map((size) => '${(size / 1024).toStringAsFixed(0)}KB').join(', ')}');
      print('Total chunks to send: $totalChunksToSend');
      print('Chunk size: ${(chunkSize / 1024).toStringAsFixed(0)}KB');
      
      // Track sending statistics
      final sentChunks = <String>[];
      final sentChunkSizes = <int>[];
      final sentChecksums = <String>[];
      
      // Send large data chains
      print('\\nSending large byte chains with checksums...');
      
      final sendStartTime = DateTime.now();
      int chunksSent = 0;
      int totalBytesSent = 0;
      
      for (int sizeIndex = 0; sizeIndex < testDataSizes.length; sizeIndex++) {
        final dataSize = testDataSizes[sizeIndex];
        print('\\nSending ${dataSize ~/ 1024}KB data chains...');
        
        // Create test data of specified size
        final testData = Uint8List(dataSize);
        for (int i = 0; i < dataSize; i++) {
          testData[i] = (i * 13 + sizeIndex * 17) % 256;
        }
        
        // Split into chunks if data is larger than chunk size
        final chunks = <Uint8List>[];
        if (dataSize <= chunkSize) {
          chunks.add(testData);
        } else {
          for (int i = 0; i < dataSize; i += chunkSize) {
            final end = (i + chunkSize < dataSize) ? i + chunkSize : dataSize;
            final chunk = Uint8List(end - i);
            for (int j = 0; j < chunk.length; j++) {
              chunk[j] = testData[i + j];
            }
            chunks.add(chunk);
          }
        }
        
        print('  Split ${dataSize} bytes into ${chunks.length} chunks');
        
        // Send each chunk with checksum
        for (int chunkIndex = 0; chunkIndex < chunks.length; chunkIndex++) {
          final chunk = chunks[chunkIndex];
          final checksum = _calculateChecksum(chunk);
          final chunkId = 'data_${sizeIndex}_${chunkIndex}';
          
          // Create message with chunk data and checksum
          final message = {
            'type': 'large_data_chunk',
            'chunk_id': chunkId,
            'data_size': dataSize,
            'chunk_size': chunk.length,
            'chunk_index': chunkIndex,
            'total_chunks': chunks.length,
            'data': base64Encode(chunk),
            'checksum': checksum,
            'timestamp': DateTime.now().millisecondsSinceEpoch,
            'source': 'sender_device',
            'target': 'receiver_device'
          };
          
          final jsonString = jsonEncode(message);
          final messageBytes = Uint8List.fromList(jsonString.codeUnits);
          
          try {
            sender.send(messageBytes);
            chunksSent++;
            totalBytesSent += messageBytes.length;
            sentChunks.add(chunkId);
            sentChunkSizes.add(chunk.length);
            sentChecksums.add(checksum);
            
            print('  Sent chunk $chunkId (${chunk.length} bytes) with checksum: $checksum');
          } catch (e) {
            print('  Error sending chunk $chunkId: $e');
          }
          
          // Small delay between chunks to avoid overwhelming
          await Future.delayed(Duration(milliseconds: 100));
        }
      }
      
      final sendEndTime = DateTime.now();
      final sendDuration = sendEndTime.difference(sendStartTime);
      
      print('\\n=== Send Statistics ===');
      print('Chunks sent: $chunksSent/$totalChunksToSend');
      print('Total bytes sent: ${totalBytesSent} (${(totalBytesSent / 1024).toStringAsFixed(2)} KB)');
      print('Send duration: ${sendDuration.inMilliseconds} ms');
      print('Average send rate: ${(totalBytesSent * 8 / sendDuration.inMilliseconds).toStringAsFixed(2)} kbps');
      
      // Wait for all messages to be received and processed
      print('\\nWaiting for messages to be received and integrity checked...');
      await Future.delayed(Duration(seconds: 10));
      
      // Verify integrity and calculate success rate
      print('\\n=== Integrity Verification Results ===');
      print('Messages received: ${receivedMessages.length}/$totalChunksToSend');
      print('Message sizes: ${messageSizes.join(', ')} bytes');
      
      int successfulIntegrityChecks = 0;
      int failedIntegrityChecks = 0;
      
      for (final entry in integrityResults.entries) {
        if (entry.value) {
          successfulIntegrityChecks++;
        } else {
          failedIntegrityChecks++;
        }
      }
      
      final integrityRate = totalChunksToSend > 0 ? 
          (successfulIntegrityChecks / totalChunksToSend * 100) : 0;
      
      print('\\nIntegrity Check Results:');
      print('  Successful integrity checks: $successfulIntegrityChecks/$totalChunksToSend');
      print('  Failed integrity checks: $failedIntegrityChecks');
      print('  Integrity rate: ${integrityRate.toStringAsFixed(2)}%');
      
      // Detailed analysis by data size
      print('\\nDetailed Analysis by Data Size:');
      for (int sizeIndex = 0; sizeIndex < testDataSizes.length; sizeIndex++) {
        final dataSize = testDataSizes[sizeIndex];
        final sizeInKB = (dataSize / 1024).toStringAsFixed(0);
        final chunksForThisSize = receivedMessages.where(
          (msg) => msg['data_size'] == dataSize
        ).length;
        
        final chunksExpectedForThisSize = 5; // 5 chunks per size
        final sizeSuccessRate = chunksExpectedForThisSize > 0 ? 
            (chunksForThisSize / chunksExpectedForThisSize * 100) : 0;
            
        print('  ${sizeInKB}KB data:');
        print('    Chunks received: $chunksForThisSize/$chunksExpectedForThisSize');
        print('    Success rate: ${sizeSuccessRate.toStringAsFixed(2)}%');
      }
      
      // Performance metrics
      print('\\n=== Performance Metrics ===');
      final receiveEndTime = DateTime.now();
      final totalTestDuration = receiveEndTime.difference(sendStartTime);
      final avgMessageSize = messageSizes.isNotEmpty ? 
          (messageSizes.reduce((a, b) => a + b) ~/ messageSizes.length) : 0;
      
      print('Total test duration: ${totalTestDuration.inSeconds} seconds');
      print('Average message size: ${avgMessageSize} bytes (${(avgMessageSize / 1024).toStringAsFixed(2)} KB)');
      print('Messages per second: ${(receivedMessages.length / totalTestDuration.inSeconds).toStringAsFixed(2)} msgs/sec');
      
      // Success criteria evaluation
      print('\\n=== Success Criteria Evaluation ===');
      final overallDeliveryRate = (receivedMessages.length / totalChunksToSend * 100);
      print('Message delivery rate: ${overallDeliveryRate.toStringAsFixed(2)}%');
      
      bool deliverySuccess = overallDeliveryRate >= 80;
      bool integritySuccess = integrityRate >= 95;
      bool performanceSuccess = (totalBytesSent * 8 / sendDuration.inMilliseconds) >= 100; // 100 kbps minimum
      
      print('Delivery rate >= 80%: ${deliverySuccess ? '✅ PASS' : '❌ FAIL'} (${overallDeliveryRate.toStringAsFixed(2)}%)');
      print('Integrity rate >= 95%: ${integritySuccess ? '✅ PASS' : '❌ FAIL'} (${integrityRate.toStringAsFixed(2)}%)');
      print('Performance >= 100 kbps: ${performanceSuccess ? '✅ PASS' : '❌ FAIL'} (${(totalBytesSent * 8 / sendDuration.inMilliseconds).toStringAsFixed(2)} kbps)');
      
      if (deliverySuccess && integritySuccess && performanceSuccess) {
        print('\\n🎉 LARGE DATA INTEGRITY TEST: EXCELLENT RESULTS!');
        print('   System successfully handles large data transfers with high integrity');
        print('   Your specific IP (192.168.0.15) used throughout the test');
        print('   Checksum verification working correctly for all data sizes');
      } else if (deliverySuccess || integritySuccess) {
        print('\\n⚠️  LARGE DATA INTEGRITY TEST: ACCEPTABLE PERFORMANCE');
        print('   System functional but can be optimized for better performance');
        print('   Core functionality available with reasonable integrity rates');
      } else {
        print('\\n🔴 LARGE DATA INTEGRITY TEST: NEEDS IMPROVEMENT');
        print('   System struggles with large data transfers');
        print('   May affect real-world deployment scenarios');
      }
      
      // Close devices
      sender.close();
      receiver.close();
      
      print('\\nLarge data integrity test with checksums completed!');
    }, timeout: Timeout(Duration(seconds: 60)));
  });
}

// Helper function to calculate SHA256 checksum
String _calculateChecksum(Uint8List data) {
  return sha256.convert(data).toString();
}

// Helper function for min
int min(int a, int b) => a < b ? a : b;