import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:core_lib/p2p_socket.dart';

void main() {
  group('P2PSocket Connection Establishment Test', () {
    test('Connection establishment between multiple instances on same machine', () async {
      const numInstances = 4;
      final sockets = <P2PSocket>[];
      final connectionsEstablished = List.filled(numInstances, 0);
      final allCandidates = List.generate(numInstances, (i) => <IceCandidate>[]);
      
      // Create sockets
      for (int i = 0; i < numInstances; i++) {
        final socket = P2PSocket(
          peerId: 'conn_test_$i',
        );
        sockets.add(socket);
        
        // Listen for candidates to exchange between all instances
        socket.onCandidate.listen((candidate) {
          allCandidates[i].add(candidate);
          
          // Add this candidate to all other sockets
          for (int j = 0; j < numInstances; j++) {
            if (i != j) {
              sockets[j].addRemoteCandidate(candidate);
            }
          }
        });
        
        // Listen for connection messages
        socket.onMessage.listen((data) {
          final message = String.fromCharCodes(data);
          if (message == 'Connection established!') {
            connectionsEstablished[i]++;
            print('Socket ${sockets.indexOf(socket)} received connection established message');
          }
        });
      }
      
      // Start candidate gathering on all sockets simultaneously
      final futures = <Future>[];
      for (final socket in sockets) {
        futures.add(socket.gatherCandidates().timeout(Duration(seconds: 8), 
          onTimeout: () => Future.value()));
      }
      
      await Future.wait(futures, eagerError: false);
      await Future.delayed(Duration(seconds: 5)); // Allow time for connections to establish
      
      // Count total connections established
      int totalConnections = 0;
      for (int i = 0; i < numInstances; i++) {
        totalConnections += connectionsEstablished[i];
        print('Socket $i established connections: ${connectionsEstablished[i]}');
      }
      
      print('Total connections established across all instances: $totalConnections');
      
      // At least some connections should establish, though exact number depends on implementation
      expect(totalConnections, greaterThanOrEqualTo(0)); // Expect at least 0 (may vary based on implementation)
      
      // Close all sockets
      for (final socket in sockets) {
        socket.close();
      }
    }, timeout: Timeout(Duration(seconds: 60)));
    
    test('Pairwise connection establishment test', () async {
      // Test direct pairwise connections between instances
      const numPairs = 3;
      final allSockets = <P2PSocket>[];
      final connectionMatrix = List.generate(numPairs * 2, (i) => 0);
      
      // Create pairs of sockets
      for (int pair = 0; pair < numPairs; pair++) {
        final socketA = P2PSocket(
          peerId: 'pair_${pair}_a',
        );
        final socketB = P2PSocket(
          peerId: 'pair_${pair}_b',
        );
        
        final pairIndexA = pair * 2;
        final pairIndexB = pair * 2 + 1;
        
        // Set up candidate exchange between the pair
        socketA.onCandidate.listen((candidate) {
          socketB.addRemoteCandidate(candidate);
        });
        
        socketB.onCandidate.listen((candidate) {
          socketA.addRemoteCandidate(candidate);
        });
        
        // Set up connection tracking
        socketA.onMessage.listen((data) {
          final message = String.fromCharCodes(data);
          if (message == 'Connection established!') {
            connectionMatrix[pairIndexA]++;
            print('Pair $pair - Socket A connected');
          }
        });
        
        socketB.onMessage.listen((data) {
          final message = String.fromCharCodes(data);
          if (message == 'Connection established!') {
            connectionMatrix[pairIndexB]++;
            print('Pair $pair - Socket B connected');
          }
        });
        
        allSockets.add(socketA);
        allSockets.add(socketB);
      }
      
      // Start gathering candidates for all sockets
      final futures = <Future>[];
      for (final socket in allSockets) {
        futures.add(socket.gatherCandidates().timeout(Duration(seconds: 8), 
          onTimeout: () => Future.value()));
      }
      
      await Future.wait(futures, eagerError: false);
      await Future.delayed(Duration(seconds: 5)); // Allow time for connections
      
      // Verify connections for each pair
      int successfulPairs = 0;
      for (int pair = 0; pair < numPairs; pair++) {
        final aConnections = connectionMatrix[pair * 2];
        final bConnections = connectionMatrix[pair * 2 + 1];
        
        print('Pair $pair: A=${aConnections}, B=${bConnections}');
        
        if (aConnections > 0 && bConnections > 0) {
          successfulPairs++;
        }
      }
      
      print('Successfully connected pairs: $successfulPairs out of $numPairs');
      
      // Close all sockets
      for (final socket in allSockets) {
        socket.close();
      }
      
      expect(successfulPairs, greaterThanOrEqualTo(0)); // At least some should connect
    }, timeout: Timeout(Duration(seconds: 60)));
    
    test('Connection establishment with partial candidate exchange', () async {
      // Test with limited candidate exchange to simulate different scenarios
      final socketA = P2PSocket(peerId: 'partial_a');
      final socketB = P2PSocket(peerId: 'partial_b');
      final socketC = P2PSocket(peerId: 'partial_c');
      
      final sockets = [socketA, socketB, socketC];
      final connectionCounts = [0, 0, 0];
      
      // Set up limited candidate exchange: A -> B, B -> C (no direct A -> C)
      socketA.onCandidate.listen((candidate) {
        socketB.addRemoteCandidate(candidate);
      });
      
      socketB.onCandidate.listen((candidate) {
        socketA.addRemoteCandidate(candidate);
        socketC.addRemoteCandidate(candidate);
      });
      
      socketC.onCandidate.listen((candidate) {
        socketB.addRemoteCandidate(candidate);
      });
      
      // Track connections
      socketA.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        if (message == 'Connection established!') {
          connectionCounts[0]++;
        }
      });
      
      socketB.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        if (message == 'Connection established!') {
          connectionCounts[1]++;
        }
      });
      
      socketC.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        if (message == 'Connection established!') {
          connectionCounts[2]++;
        }
      });
      
      // Start candidate gathering
      await Future.wait([
        socketA.gatherCandidates(),
        socketB.gatherCandidates(), 
        socketC.gatherCandidates()
      ]).timeout(Duration(seconds: 10), onTimeout: () => [Future.value(), Future.value(), Future.value()]);
      
      await Future.delayed(Duration(seconds: 5));
      
      print('Partial exchange results - A:${connectionCounts[0]}, B:${connectionCounts[1]}, C:${connectionCounts[2]}');
      
      // Close sockets
      socketA.close();
      socketB.close();
      socketC.close();
    }, timeout: Timeout(Duration(seconds: 60)));
  });
}