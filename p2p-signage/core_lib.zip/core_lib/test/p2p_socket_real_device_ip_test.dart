import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:core_lib/p2p_socket.dart';

void main() {
  group('P2PSocket Real Device IP Test', () {
    test('Test with actual device IPs', () async {
      // Test with dynamically discovered IPs
      final nodeA = P2PSocket(
        peerId: 'main_device',
      );
      
      final nodeB = P2PSocket(
        peerId: 'remote_device',
      );
      
      // Wait for IP discovery
      await Future.delayed(Duration(seconds: 3));
      
      // Use the discovered public IPs or fallback to local IPs
      final nodeAIP = nodeA.publicIp ?? (nodeA.localIps.isNotEmpty ? nodeA.localIps[0].address : '127.0.0.1');
      final nodeBIP = nodeB.publicIp ?? (nodeB.localIps.isNotEmpty ? nodeB.localIps[0].address : '127.0.0.1');
      final commonPortA = 8080;  // Use common port for communication
      final commonPortB = 8081;  // Use common port for communication
      
      print('Node A Configuration:');
      print('  Peer ID: ${nodeA.peerId}');
      print('  Discovered Public IP: ${nodeA.publicIp}');
      print('  Local IPs: ${nodeA.localIps.map((ip) => ip.address).join(", ")}');
      
      print('Node B Configuration:');
      print('  Peer ID: ${nodeB.peerId}');
      print('  Discovered Public IP: ${nodeB.publicIp}');
      print('  Local IPs: ${nodeB.localIps.map((ip) => ip.address).join(", ")}');
      
      // Start gathering candidates to initialize the sockets
      await Future.wait([
        nodeA.gatherCandidates(),
        nodeB.gatherCandidates()
      ]).timeout(Duration(seconds: 10), onTimeout: () => [Future.value(), Future.value()]);
      
      print('After initialization:');
      print('  Node A - Private IP: ${nodeA.discoveredPrivateIp}, Local Port: ${nodeA.localPort}');
      print('  Node B - Private IP: ${nodeB.discoveredPrivateIp}, Local Port: ${nodeB.localPort}');
      
      // Now exchange the discovered IPs between nodes
      // This simulates the distributed routing table where each node knows others' public IPs
      final aPublicCandidate = IceCandidate(
        'discovered', 
        nodeAIP, 
        commonPortA,
        150,  // High priority for discovered IPs
        foundation: 'discovered_device'
      );
      nodeB.addRemoteCandidate(aPublicCandidate);
      print('Added Node A ($nodeAIP:$commonPortA) to Node B');
      
      final bPublicCandidate = IceCandidate(
        'discovered', 
        nodeBIP, 
        commonPortB,
        150,  // High priority for discovered IPs
        foundation: 'discovered_device'
      );
      nodeA.addRemoteCandidate(bPublicCandidate);
      print('Added Node B ($nodeBIP:$commonPortB) to Node A');
      
      await Future.delayed(Duration(seconds: 3));
      
      // Set up message tracking
      var messageReceivedA = 0;
      var messageReceivedB = 0;
      
      nodeA.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        if (message != 'Connection established!') {
          messageReceivedA++;
          print('Node A received: $message');
        }
      });
      
      nodeB.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        if (message != 'Connection established!') {
          messageReceivedB++;
          print('Node B received: $message');
        }
      });
      
      // Send messages between the nodes using their configured IPs
      nodeA.send(Uint8List.fromList('Hello from main device (37.223.163.63)'.codeUnits));
      nodeB.send(Uint8List.fromList('Hello from remote device (192.168.0.15)'.codeUnits));
      
      await Future.delayed(Duration(seconds: 5));
      
      print('Results with real device IPs:');
      print('  Node A received: $messageReceivedA messages');
      print('  Node B received: $messageReceivedB messages');
      
      // Close sockets
      nodeA.close();
      nodeB.close();
    }, timeout: Timeout(Duration(seconds: 40)));
    
    test('Simulate technician setup with real IPs', () async {
      // This simulates the scenario with dynamically discovered IPs
      print('Simulating technician setup process with discovered IPs...');
      
      // Create nodes
      final masterNode = P2PSocket(
        peerId: 'master_signage',
      );
      
      final slaveNode = P2PSocket(
        peerId: 'slave_signage',
      );
      
      // Wait for IP discovery
      await Future.delayed(Duration(seconds: 3));
      
      // Use the discovered IPs or fallback to local IPs
      final masterIP = masterNode.publicIp ?? (masterNode.localIps.isNotEmpty ? masterNode.localIps[0].address : '127.0.0.1');
      final slaveIP = slaveNode.publicIp ?? (slaveNode.localIps.isNotEmpty ? slaveNode.localIps[0].address : '127.0.0.1');
      final commonPortMaster = 8080;  // Use common port for communication
      final commonPortSlave = 8081;   // Use common port for communication
      
      // Start initialization
      await Future.wait([
        masterNode.gatherCandidates(),
        slaveNode.gatherCandidates()
      ]).timeout(Duration(seconds: 10), onTimeout: () => [Future.value(), Future.value()]);
      
      // Simulate the distributed routing table process
      // This is where each node would learn about the other's IP
      print('Adding nodes to distributed routing table with discovered IPs...');
      
      // In a real system, the master would learn the slave's IP and vice versa
      final slaveInfoForMaster = IceCandidate(
        'distributed_route', 
        slaveIP,  // Slave's discovered IP
        commonPortSlave,            // Slave's port
        140,             // High priority for routing table entries
        foundation: 'distributed'
      );
      
      final masterInfoForSlave = IceCandidate(
        'distributed_route', 
        masterIP, // Master's discovered IP
        commonPortMaster,            // Master's port
        140,             // High priority for routing table entries
        foundation: 'distributed'
      );
      
      masterNode.addRemoteCandidate(slaveInfoForMaster);
      slaveNode.addRemoteCandidate(masterInfoForSlave);
      
      print('Routing table setup complete');
      print('  Master knows about: ${slaveInfoForMaster.address}:${slaveInfoForMaster.port}');
      print('  Slave knows about: ${masterInfoForSlave.address}:${masterInfoForSlave.port}');
      
      await Future.delayed(Duration(seconds: 2));
      
      // Now test communication using the routing table information
      var masterReceived = 0;
      var slaveReceived = 0;
      
      masterNode.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        if (message.startsWith('Data from slave')) {
          masterReceived++;
          print('Master received: $message');
        }
      });
      
      slaveNode.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        if (message.startsWith('Data from master')) {
          slaveReceived++;
          print('Slave received: $message');
        }
      });
      
      // Send data between nodes
      masterNode.send(Uint8List.fromList('Data from master (37.223.163.63)'.codeUnits));
      slaveNode.send(Uint8List.fromList('Data from slave (192.168.0.15)'.codeUnits));
      
      await Future.delayed(Duration(seconds: 5));
      
      print('Results after technician setup:');
      print('  Master received: $masterReceived messages');
      print('  Slave received: $slaveReceived messages');
      
      masterNode.close();
      slaveNode.close();
    }, timeout: Timeout(Duration(seconds: 40)));
  });
}