import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:core_lib/p2p_socket.dart';

void main() {
  group('P2PSocket Data Transmission Test', () {
    test('Data transmission between multiple instances on same machine', () async {
      const numInstances = 3;
      final sockets = <P2PSocket>[];
      final receivedMessages = List.generate(numInstances, (i) => <String>[]);
      
      // Create sockets
      for (int i = 0; i < numInstances; i++) {
        final socket = P2PSocket(
          peerId: 'data_test_$i',
        );
        sockets.add(socket);
        
        // Set up candidate exchange between all instances
        socket.onCandidate.listen((candidate) {
          for (int j = 0; j < numInstances; j++) {
            if (i != j) {
              sockets[j].addRemoteCandidate(candidate);
            }
          }
        });
        
        // Listen for messages
        socket.onMessage.listen((data) {
          final message = String.fromCharCodes(data);
          if (message != 'Connection established!') { // Filter out connection messages
            receivedMessages[i].add(message);
            print('Socket $i received: $message');
          }
        });
      }
      
      // Start candidate gathering
      final futures = <Future>[];
      for (final socket in sockets) {
        futures.add(socket.gatherCandidates().timeout(Duration(seconds: 8), 
          onTimeout: () => Future.value()));
      }
      
      await Future.wait(futures, eagerError: false);
      await Future.delayed(Duration(seconds: 3)); // Allow time for connections
      
      // Send messages between instances
      const testMessage = 'Hello from instance';
      for (int i = 0; i < numInstances; i++) {
        final message = '$testMessage $i';
        final messageBytes = Uint8List.fromList(message.codeUnits);
        sockets[i].send(messageBytes);
        print('Socket $i sent: $message');
        await Future.delayed(Duration(milliseconds: 200)); // Small delay between sends
      }
      
      // Wait for messages to propagate
      await Future.delayed(Duration(seconds: 3));
      
      // Check received messages
      for (int i = 0; i < numInstances; i++) {
        print('Socket $i received ${receivedMessages[i].length} messages: ${receivedMessages[i]}');
      }
      
      // Close all sockets
      for (final socket in sockets) {
        socket.close();
      }
    }, timeout: Timeout(Duration(seconds: 60)));
    
    test('Bidirectional data transmission between paired instances', () async {
      // Create pairs of sockets for bidirectional testing
      const numPairs = 2;
      final allSockets = <P2PSocket>[];
      final receivedData = <int, List<String>>{}; // Map socket index to received messages
      
      for (int pair = 0; pair < numPairs; pair++) {
        final socketA = P2PSocket(
          peerId: 'bidir_${pair}_a',
        );
        final socketB = P2PSocket(
          peerId: 'bidir_${pair}_b',
        );
        
        final aIndex = pair * 2;
        final bIndex = pair * 2 + 1;
        receivedData[aIndex] = [];
        receivedData[bIndex] = [];
        
        // Set up candidate exchange between the pair
        socketA.onCandidate.listen((candidate) {
          socketB.addRemoteCandidate(candidate);
        });
        
        socketB.onCandidate.listen((candidate) {
          socketA.addRemoteCandidate(candidate);
        });
        
        // Set up message listening
        socketA.onMessage.listen((data) {
          final message = String.fromCharCodes(data);
          if (message != 'Connection established!') {
            receivedData[aIndex]!.add(message);
            print('Pair $pair - Socket A received: $message');
          }
        });
        
        socketB.onMessage.listen((data) {
          final message = String.fromCharCodes(data);
          if (message != 'Connection established!') {
            receivedData[bIndex]!.add(message);
            print('Pair $pair - Socket B received: $message');
          }
        });
        
        allSockets.add(socketA);
        allSockets.add(socketB);
      }
      
      // Start candidate gathering
      final futures = <Future>[];
      for (final socket in allSockets) {
        futures.add(socket.gatherCandidates().timeout(Duration(seconds: 8), 
          onTimeout: () => Future.value()));
      }
      
      await Future.wait(futures, eagerError: false);
      await Future.delayed(Duration(seconds: 3)); // Allow connections to establish
      
      // Send messages in both directions for each pair
      for (int pair = 0; pair < numPairs; pair++) {
        final aSocket = allSockets[pair * 2];
        final bSocket = allSockets[pair * 2 + 1];
        final aIndex = pair * 2;
        final bIndex = pair * 2 + 1;
        
        // A sends to B
        final messageAToB = 'Message from A$pair to B$pair';
        aSocket.send(Uint8List.fromList(messageAToB.codeUnits));
        print('A$pair -> B$pair: $messageAToB');
        
        // B sends to A
        final messageBToA = 'Message from B$pair to A$pair';
        bSocket.send(Uint8List.fromList(messageBToA.codeUnits));
        print('B$pair -> A$pair: $messageBToA');
      }
      
      // Wait for messages to be received
      await Future.delayed(Duration(seconds: 3));
      
      // Check results for each pair
      int successfulPairs = 0;
      for (int pair = 0; pair < numPairs; pair++) {
        final aIndex = pair * 2;
        final bIndex = pair * 2 + 1;
        
        print('Pair $pair - A received: ${receivedData[aIndex]}');
        print('Pair $pair - B received: ${receivedData[bIndex]}');
        
        // Check if both sent messages were received
        final aReceivedBMessage = receivedData[aIndex]!.any((msg) => msg.contains('Message from B$pair to A$pair'));
        final bReceivedAMessage = receivedData[bIndex]!.any((msg) => msg.contains('Message from A$pair to B$pair'));
        
        if (aReceivedBMessage && bReceivedAMessage) {
          successfulPairs++;
        }
      }
      
      print('Bidirectional transmission successful in $successfulPairs out of $numPairs pairs');
      
      // Close all sockets
      for (final socket in allSockets) {
        socket.close();
      }
    }, timeout: Timeout(Duration(seconds: 60)));
    
    test('Large data transmission stress test', () async {
      // Test transmission of larger amounts of data
      final sender = P2PSocket(peerId: 'large_data_sender');
      final receiver = P2PSocket(peerId: 'large_data_receiver');
      
      String? receivedData;
      final receivedCompleter = Completer<String>();
      
      // Set up candidate exchange
      sender.onCandidate.listen((candidate) {
        receiver.addRemoteCandidate(candidate);
      });
      
      receiver.onCandidate.listen((candidate) {
        sender.addRemoteCandidate(candidate);
      });
      
      // Set up message receiving
      receiver.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        if (message != 'Connection established!') {
          receivedData = message;
          if (!receivedCompleter.isCompleted) {
            receivedCompleter.complete(message);
          }
        }
      });
      
      // Start candidate gathering
      await Future.wait([
        sender.gatherCandidates(),
        receiver.gatherCandidates()
      ]).timeout(Duration(seconds: 10), onTimeout: () => [Future.value(), Future.value()]);
      
      await Future.delayed(Duration(seconds: 3)); // Allow connections to establish
      
      // Create a larger data payload (512 bytes)
      final largeMessage = 'A' * 512;
      print('Sending large message (${largeMessage.length} bytes)...');
      
      sender.send(Uint8List.fromList(largeMessage.codeUnits));
      
      try {
        final result = await receivedCompleter.future.timeout(Duration(seconds: 10));
        expect(result, largeMessage);
        print('Large data transmission successful');
      } catch (e) {
        print('Large data transmission failed: $e');
        // This is expected to potentially fail in some network configurations
      }
      
      sender.close();
      receiver.close();
    }, timeout: Timeout(Duration(seconds: 70)));
  });
}