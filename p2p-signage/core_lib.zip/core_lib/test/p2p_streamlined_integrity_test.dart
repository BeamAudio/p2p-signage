import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:crypto/crypto.dart';
import 'package:core_lib/p2p_socket.dart';

void main() {
  group('P2PSocket Large Data Integrity Test', () {
    test('Test large byte chains with checksums and verify integrity', () async {
      print('=== Large Data Integrity Test ===');
      
      // Create two P2PSocket instances
      final sender = P2PSocket(
        peerId: 'sender_integrity',
      );
      
      final receiver = P2PSocket(
        peerId: 'receiver_integrity',
      );
      
      print('Created sender and receiver for integrity test');
      
      // Start gathering candidates for IP discovery
      await Future.wait([
        sender.gatherCandidates(),
        receiver.gatherCandidates()
      ]).timeout(Duration(seconds: 15), onTimeout: () => [Future.value(), Future.value()]);
      
      await Future.delayed(Duration(seconds: 3));
      
      print('Discovered IPs:');
      print('  Sender: ${sender.discoveredPrivateIp}:${sender.localPort}');
      print('  Receiver: ${receiver.discoveredPrivateIp}:${receiver.localPort}');
      print('  Public IPs: ${sender.publicIp}, ${receiver.publicIp}');
      
      // Verify your specific IP (192.168.0.15) is discovered
      bool senderHasYourIp = sender.localIps.any((ip) => ip.address == '192.168.0.15');
      bool receiverHasYourIp = receiver.localIps.any((ip) => ip.address == '192.168.0.15');
      
      print('Your specific IP (192.168.0.15) discovered:');
      print('  In Sender: ${senderHasYourIp ? '✅ YES' : '❌ NO'}');
      print('  In Receiver: ${receiverHasYourIp ? '✅ YES' : '❌ NO'}');
      
      // Set up message tracking
      final receivedMessages = <Map<String, dynamic>>[];
      final messageSizes = <int>[];
      final integrityChecks = <String, bool>{};
      
      receiver.onMessage.listen((data) {
        try {
          final message = String.fromCharCodes(data);
          if (message.startsWith('{')) {
            final jsonData = jsonDecode(message) as Map<String, dynamic>;
            receivedMessages.add(jsonData);
            messageSizes.add(data.length);
            
            // Verify integrity if it's a data message with checksum
            if (jsonData.containsKey('checksum') && jsonData.containsKey('data')) {
              final receivedChecksum = jsonData['checksum'] as String;
              final receivedData = base64Decode(jsonData['data'] as String);
              final calculatedChecksum = _calculateChecksum(receivedData);
              final integrityOk = receivedChecksum == calculatedChecksum;
              integrityChecks[jsonData['id'] as String] = integrityOk;
              print('Received data chunk ${jsonData['id']}: ${receivedData.length} bytes, integrity: ${integrityOk ? '✅ OK' : '❌ FAILED'}');
            }
          }
        } catch (e) {
          print('Error processing received message: $e');
        }
      });
      
      await Future.delayed(Duration(seconds: 2));
      
      // Set up direct communication by exchanging candidate information
      if (receiver.discoveredPrivateIp != null && receiver.localPort != null) {
        final receiverCandidate = IceCandidate(
          'direct',
          receiver.discoveredPrivateIp!,
          receiver.localPort!,
          150,
          foundation: 'direct_integrity'
        );
        sender.addRemoteCandidate(receiverCandidate);
        print('Added receiver (${receiver.discoveredPrivateIp}:${receiver.localPort}) to sender');
      }
      
      if (sender.discoveredPrivateIp != null && sender.localPort != null) {
        final senderCandidate = IceCandidate(
          'direct',
          sender.discoveredPrivateIp!,
          sender.localPort!,
          150,
          foundation: 'direct_integrity'
        );
        receiver.addRemoteCandidate(senderCandidate);
        print('Added sender (${sender.discoveredPrivateIp}:${sender.localPort}) to receiver');
      }
      
      await Future.delayed(Duration(seconds: 2));
      
      // Generate and send large data with checksums
      print('\\nSending large data with integrity verification...');
      
      final chunksToSend = 10;
      int chunksSent = 0;
      int totalBytesToSend = 0;
      
      for (int i = 0; i < chunksToSend; i++) {
        // Create variable sized data chunks (1KB to 100KB)
        final chunkSize = 1024 + (i * 10 * 1024); // 1KB + increments of 10KB
        final dataChunk = Uint8List(chunkSize);
        
        // Fill with pseudo-random but deterministic data
        for (int j = 0; j < chunkSize; j++) {
          dataChunk[j] = (j * 7 + i * 13) % 256;
        }
        
        // Calculate checksum
        final checksum = _calculateChecksum(dataChunk);
        totalBytesToSend += chunkSize;
        
        // Create message with data and checksum
        final message = {
          'type': 'data_chunk',
          'id': 'chunk_$i',
          'size': chunkSize,
          'data': base64Encode(dataChunk),
          'checksum': checksum,
          'timestamp': DateTime.now().millisecondsSinceEpoch,
          'source': 'sender_integrity',
          'sequence': i
        };
        
        final jsonString = jsonEncode(message);
        final messageBytes = Uint8List.fromList(jsonString.codeUnits);
        
        try {
          sender.send(messageBytes);
          chunksSent++;
          print('Sent chunk $i (${chunkSize} bytes) with checksum: ${checksum.substring(0, 16)}...');
        } catch (e) {
          print('Error sending chunk $i: $e');
        }
        
        await Future.delayed(Duration(milliseconds: 200));
      }
      
      print('\\nData transmission completed:');
      print('  Chunks sent: $chunksSent/$chunksToSend');
      print('  Total bytes: ${totalBytesToSend} (${(totalBytesToSend / 1024).toStringAsFixed(2)} KB)');
      
      // Wait for messages to be received
      print('\\nWaiting for data reception and integrity verification...');
      await Future.delayed(Duration(seconds: 8));
      
      // Analyze results
      print('\\n=== Integrity Test Results ===');
      print('Messages received: ${receivedMessages.length}/$chunksToSend');
      print('Message sizes: ${messageSizes.length} messages received');
      
      int passedIntegrityChecks = 0;
      int failedIntegrityChecks = 0;
      
      for (final entry in integrityChecks.entries) {
        if (entry.value) {
          passedIntegrityChecks++;
        } else {
          failedIntegrityChecks++;
        }
      }
      
      final integrityRate = chunksSent > 0 ? (passedIntegrityChecks / chunksSent * 100) : 0;
      
      print('\\nIntegrity verification:');
      print('  Passed checks: $passedIntegrityChecks/$chunksSent');
      print('  Failed checks: $failedIntegrityChecks');
      print('  Integrity rate: ${integrityRate.toStringAsFixed(2)}%');
      
      // Show detailed chunk information
      print('\\nChunk details:');
      for (int i = 0; i < min(receivedMessages.length, 5); i++) {
        final msg = receivedMessages[i];
        print('  Chunk ${msg['id']}: ${msg['size']} bytes, seq: ${msg['sequence']}');
      }
      
      if (receivedMessages.length > 5) {
        print('  ... and ${receivedMessages.length - 5} more chunks');
      }
      
      // Performance metrics
      print('\\nPerformance metrics:');
      final avgMessageSize = messageSizes.isNotEmpty ? 
          (messageSizes.reduce((a, b) => a + b) ~/ messageSizes.length) : 0;
      print('  Average received message size: ${avgMessageSize} bytes (${(avgMessageSize / 1024).toStringAsFixed(2)} KB)');
      
      // Success criteria
      bool integritySuccess = integrityRate >= 90; // 90% integrity rate
      bool deliverySuccess = receivedMessages.length >= chunksSent * 0.8; // 80% delivery rate
      
      print('\\nSuccess criteria evaluation:');
      print('  Integrity rate >= 90%: ${integritySuccess ? '✅ PASS (${integrityRate.toStringAsFixed(2)}%)' : '❌ FAIL (${integrityRate.toStringAsFixed(2)}%)'}');
      print('  Delivery rate >= 80%: ${deliverySuccess ? '✅ PASS (${((receivedMessages.length / chunksSent) * 100).toStringAsFixed(2)}%)' : '❌ FAIL (${((receivedMessages.length / chunksSent) * 100).toStringAsFixed(2)}%)'}');
      
      if (integritySuccess && deliverySuccess) {
        print('\\n🎉 LARGE DATA INTEGRITY TEST: SUCCESSFUL!');
        print('   System handles large data transfers with high integrity');
        print('   Your specific IP (192.168.0.15) used for communication');
        print('   Checksum verification working correctly (${integrityRate.toStringAsFixed(2)}% pass rate)');
      } else if (integritySuccess || deliverySuccess) {
        print('\\n⚠️  LARGE DATA INTEGRITY TEST: ACCEPTABLE');
        print('   System functional but can be optimized');
        print('   Core integrity mechanisms working');
      } else {
        print('\\n🔴 LARGE DATA INTEGRITY TEST: NEEDS IMPROVEMENT');
        print('   Issues with data transmission or integrity verification');
      }
      
      // Close devices
      sender.close();
      receiver.close();
      
      print('\\nLarge data integrity test completed!');
    }, timeout: Timeout(Duration(seconds: 45)));
  });
}

// Helper function to calculate SHA256 checksum
String _calculateChecksum(Uint8List data) {
  return sha256.convert(data).toString();
}

// Helper function for min
int min(int a, int b) => a < b ? a : b;