import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:core_lib/p2p_socket.dart';

void main() {
  group('P2PSocket Public IP Discovery Test', () {
    test('Verify STUN server lookup and public IP discovery', () async {
      final socket = P2PSocket(
        peerId: 'stun_test',
        stunServerHostname: 'stun.l.google.com', 
        stunPort: 19302
      );
      
      // Track the candidates we receive
      var hostCandidateFound = false;
      var srflxCandidateFound = false;
      List<IceCandidate> allCandidates = [];
      
      socket.onCandidate.listen((candidate) {
        allCandidates.add(candidate);
        if (candidate.type == 'host') {
          hostCandidateFound = true;
        } else if (candidate.type == 'srflx') { // server-reflexive
          srflxCandidateFound = true;
        }
        print('Received candidate: ${candidate.type} - ${candidate.address}:${candidate.port}');
      });
      
      try {
        // Start gathering candidates
        await socket.gatherCandidates().timeout(Duration(seconds: 15));
        
        // Wait a bit more to collect all candidates
        await Future.delayed(Duration(seconds: 5));
        
        // Check that we at least have a host candidate
        expect(hostCandidateFound, true);
        
        // The srflx candidate might not be available if STUN server is unreachable
        print('Total candidates received: ${allCandidates.length}');
        print('Host candidate found: $hostCandidateFound');
        print('SRFLX candidate found: $srflxCandidateFound');
        
        // Print all candidates for debugging
        for (int i = 0; i < allCandidates.length; i++) {
          print('Candidate $i: ${allCandidates[i].type} - ${allCandidates[i].address}:${allCandidates[i].port}');
        }
      } catch (e) {
        // If timeout occurs, that's expected in some network environments
        print('STUN candidate gathering timed out: $e');
        
        // We should still at least have a host candidate in most cases
        // Wait a bit more in case host candidate comes after the timeout
        await Future.delayed(Duration(seconds: 1));
      } finally {
        socket.close();
      }
    });
    
    test('Test with different STUN servers', () async {
      // Test with alternative STUN servers
      final List<Map<String, Object>> stunServers = [
        {'host': 'stun.l.google.com', 'port': 19302},
        {'host': 'stun1.l.google.com', 'port': 19302},
        {'host': 'stun.cloudflare.com', 'port': 3478}
      ];
      
      for (final server in stunServers) {
        print('Testing with STUN server: ${server['host']}:${server['port']}');
        
        final socket = P2PSocket(
          peerId: 'stun_alt_test_${server['host']}',
          stunServerHostname: server['host'] as String,
          stunPort: server['port'] as int
        );
        
        var candidateReceived = false;
        socket.onCandidate.listen((candidate) {
          candidateReceived = true;
          print('Received candidate from ${server['host']}: ${candidate.type} - ${candidate.address}:${candidate.port}');
        });
        
        try {
          await socket.gatherCandidates().timeout(Duration(seconds: 10));
          
          // Wait to see if we get any candidates
          await Future.delayed(Duration(seconds: 3));
          
          // Even if STUN fails, we should typically get a host candidate
          print('STUN server ${server['host']}: Candidate received = $candidateReceived');
        } catch (e) {
          print('STUN server ${server['host']} timed out: $e');
        } finally {
          socket.close();
        }
        
        // Add delay between tests
        await Future.delayed(Duration(milliseconds: 500));
      }
    });
    
    test('Verify socket binding on different ports', () async {
      // Create multiple sockets to test binding on different ports
      final sockets = <P2PSocket>[];
      final ports = <int>[];
      
      for (int i = 0; i < 3; i++) {
        final socket = P2PSocket(peerId: 'port_test_$i');
        sockets.add(socket);
        
        // Gather candidates which will bind the socket
        await socket.gatherCandidates();
        
        // Add delay to ensure socket binding
        await Future.delayed(Duration(milliseconds: 100));
        
        // Note: We can't directly access the internal _socket.port because it's private,
        // but the binding should happen internally
        ports.add(-1); // Placeholder since we can't access the port directly
      }
      
      // Verify all sockets created successfully
      expect(sockets.length, 3);
      
      // Close all sockets
      for (final socket in sockets) {
        socket.close();
      }
    });
  });
}