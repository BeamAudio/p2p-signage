import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:core_lib/p2p_socket.dart';

void main() {
  group('P2PSocket Functionality Test with Real Local IPs', () {
    test('Test functionality with real local IPs on same device', () async {
      // Get the actual local IP of the device instead of using fake ones
      // Both sockets will bind to the same network interface but different ports
      
      final socketA = P2PSocket(peerId: 'socket_a');
      final socketB = P2PSocket(peerId: 'socket_b');
      
      // Track discovered IPs - they should both get the same real local IP
      String? ipA, ipB;
      int? portA, portB;
      
      socketA.onCandidate.listen((candidate) {
        if (candidate.type == 'host') {
          ipA = candidate.address;
          portA = candidate.port;
          print('Socket A discovered local IP: ${ipA!}:${portA!}');
        }
      });
      
      socketB.onCandidate.listen((candidate) {
        if (candidate.type == 'host') {
          ipB = candidate.address;
          portB = candidate.port;
          print('Socket B discovered local IP: ${ipB!}:${portB!}');
        }
      });
      
      // Initialize both sockets - they'll bind to the same network interface
      await Future.wait([
        socketA.gatherCandidates(),
        socketB.gatherCandidates()
      ]).timeout(Duration(seconds: 10), onTimeout: () => [Future.value(), Future.value()]);
      
      print('After initialization:');
      print('  Socket A IP: ${socketA.discoveredPrivateIp}, Port: ${socketA.localPort}');
      print('  Socket B IP: ${socketB.discoveredPrivateIp}, Port: ${socketB.localPort}');
      
      // Verify they got the same actual local IP (which exists on this device)
      expect(socketA.discoveredPrivateIp, equals(socketB.discoveredPrivateIp));
      expect(socketA.discoveredPrivateIp, isNotNull);
      expect(socketA.localPort, isNot(equals(socketB.localPort))); // Different ports
      
      // Add each socket's info to the other (like in a distributed network)
      final candidateA = IceCandidate('local', socketA.discoveredPrivateIp!, socketA.localPort!, 125, foundation: 'local_test');
      final candidateB = IceCandidate('local', socketB.discoveredPrivateIp!, socketB.localPort!, 125, foundation: 'local_test');
      
      socketB.addRemoteCandidate(candidateA);
      socketA.addRemoteCandidate(candidateB);
      
      print('Added remote candidates - A knows about B: ${candidateB.address}:${candidateB.port}');
      print('Added remote candidates - B knows about A: ${candidateA.address}:${candidateA.port}');
      
      // Wait for potential connection establishment
      await Future.delayed(Duration(seconds: 2));
      
      // Set up message tracking
      var messageReceivedByA = false;
      var messageReceivedByB = false;
      var connectionEstablishedA = false;
      var connectionEstablishedB = false;
      
      socketA.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        if (message == 'Connection established!') {
          connectionEstablishedA = true;
          print('Socket A: Connection established');
        } else {
          print('Socket A received: $message');
          messageReceivedByA = true;
        }
      });
      
      socketB.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        if (message == 'Connection established!') {
          connectionEstablishedB = true;
          print('Socket B: Connection established');
        } else {
          print('Socket B received: $message');
          messageReceivedByB = true;
        }
      });
      
      // Send messages using real local IPs
      socketA.send(Uint8List.fromList('Hello from A on real local IP'.codeUnits));
      socketB.send(Uint8List.fromList('Hello from B on real local IP'.codeUnits));
      
      await Future.delayed(Duration(seconds: 3));
      
      print('Results with real local IPs:');
      print('  A connection established: $connectionEstablishedA');
      print('  B connection established: $connectionEstablishedB');
      print('  A received message: $messageReceivedByA');
      print('  B received message: $messageReceivedByB');
      
      socketA.close();
      socketB.close();
    }, timeout: Timeout(Duration(seconds: 40)));
    
    test('Test with multiple instances on real local network', () async {
      const numInstances = 4;
      final sockets = <P2PSocket>[];
      final localIps = <String>{};
      
      // Create multiple instances that will use the real local network
      for (int i = 0; i < numInstances; i++) {
        final socket = P2PSocket(peerId: 'instance_$i');
        sockets.add(socket);
      }
      
      // Listen for IP discovery
      for (int i = 0; i < numInstances; i++) {
        sockets[i].onCandidate.listen((candidate) {
          if (candidate.type == 'host') {
            localIps.add(candidate.address);
            print('Instance $i discovered local IP: ${candidate.address}:${candidate.port}');
          }
        });
      }
      
      // Initialize all instances
      final futures = <Future>[];
      for (final socket in sockets) {
        futures.add(socket.gatherCandidates().timeout(Duration(seconds: 5), 
          onTimeout: () => Future.value()));
      }
      
      await Future.wait(futures, eagerError: false);
      
      print('All instances initialized with real local IPs');
      print('Unique local IPs discovered: ${localIps.length} - ${localIps.join(", ")}');
      
      // Exchange candidates between all instances
      for (int i = 0; i < numInstances; i++) {
        for (int j = 0; j < numInstances; j++) {
          if (i != j) {
            final remoteCandidate = IceCandidate(
              'local_network', 
              sockets[j].discoveredPrivateIp!, 
              sockets[j].localPort!, 
              120,
              foundation: 'mesh'
            );
            sockets[i].addRemoteCandidate(remoteCandidate);
          }
        }
      }
      
      await Future.delayed(Duration(seconds: 2));
      
      // Test communication
      var totalMessagesReceived = 0;
      
      for (int i = 0; i < numInstances; i++) {
        sockets[i].onMessage.listen((data) {
          final message = String.fromCharCodes(data);
          if (message != 'Connection established!') {
            totalMessagesReceived++;
            print('Instance $i received: $message');
          }
        });
      }
      
      // Send messages from each instance
      for (int i = 0; i < numInstances; i++) {
        final message = 'Message from instance $i on real network';
        sockets[i].send(Uint8List.fromList(message.codeUnits));
      }
      
      await Future.delayed(Duration(seconds: 3));
      
      print('Results with real local network:');
      print('  Total messages received: $totalMessagesReceived');
      
      // Close all sockets
      for (final socket in sockets) {
        socket.close();
      }
    }, timeout: Timeout(Duration(seconds: 40)));
  });
}