import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:core_lib/p2p_socket.dart';

void main() {
  group('P2PSocket TURN Functionality Tests', () {
    test('Initialize P2PSocket with TURN configuration', () {
      final turnConfig = TurnServerConfig(
        hostname: 'turn.example.com',
        port: 3478,
        username: 'testuser',
        password: 'testpass',
      );
      
      final socket = P2PSocket(
        peerId: 'turn_test_1',
        turnServerConfig: turnConfig,
      );
      
      expect(socket.turnServerConfig, isNotNull);
      expect(socket.turnServerConfig!.hostname, 'turn.example.com');
      expect(socket.turnServerConfig!.port, 3478);
      expect(socket.turnServerConfig!.username, 'testuser');
      expect(socket.turnServerConfig!.password, 'testpass');
      
      socket.close();
    });
    
    test('Initialize P2PSocket without TURN configuration', () {
      final socket = P2PSocket(
        peerId: 'no_turn_test',
        // No turnServerConfig provided
      );
      
      expect(socket.turnServerConfig, isNull);
      
      socket.close();
    });
    
    test('Test candidate generation with TURN fallback (simulated)', () async {
      // Create a TURN config with realistic values
      final turnConfig = TurnServerConfig(
        hostname: 'turn.cloudflare.com',
        port: 3478,
        username: 'test',
        password: 'test',
      );
      
      final socket = P2PSocket(
        peerId: 'turn_fallback_test',
        turnServerConfig: turnConfig,
      );
      
      var candidateCount = 0;
      var relayCandidateFound = false;
      var hostCandidateFound = false;
      
      socket.onCandidate.listen((candidate) {
        candidateCount++;
        print('Received candidate: ${candidate.type} - ${candidate.address}:${candidate.port}');
        
        if (candidate.type == 'relay') {
          relayCandidateFound = true;
        } else if (candidate.type == 'host') {
          hostCandidateFound = true;
        }
      });
      
      try {
        // Attempt to gather candidates (this may timeout on STUN but should try TURN)
        await socket.gatherCandidates().timeout(Duration(seconds: 15));
        await Future.delayed(Duration(seconds: 3)); // Allow time for any candidates
        
        // Even if TURN doesn't successfully allocate (due to invalid credentials in test),
        // the infrastructure should be in place
        print('Total candidates: $candidateCount');
        print('Host candidate found: $hostCandidateFound');
        print('Relay candidate found: $relayCandidateFound');
        
        // We should at least get a host candidate
        expect(hostCandidateFound, true);
        
      } catch (e) {
        print('Error during candidate gathering: $e');
      } finally {
        socket.close();
      }
    });
    
    test('Test TURN as fallback when STUN fails', () async {
      // Use a non-existent STUN server to force failure, with TURN as fallback
      final turnConfig = TurnServerConfig(
        hostname: 'turn.cloudflare.com', 
        port: 3478,
        username: 'test',
        password: 'test',
      );
      
      final socket = P2PSocket(
        peerId: 'stun_fail_fallback_test',
        stunServerHostname: 'nonexistent-stun-server.example.com', // This should fail
        stunPort: 19302,
        turnServerConfig: turnConfig,
      );
      
      var candidateCount = 0;
      var hostCandidateFound = false;
      
      socket.onCandidate.listen((candidate) {
        candidateCount++;
        print('Received candidate (STUN fail test): ${candidate.type} - ${candidate.address}:${candidate.port}');
        
        if (candidate.type == 'host') {
          hostCandidateFound = true;
        }
      });
      
      try {
        // STUN will likely fail, but host candidate should still be generated
        // TURN fallback would attempt but likely fail too due to fake credentials
        await socket.gatherCandidates().timeout(Duration(seconds: 15));
        await Future.delayed(Duration(seconds: 3));
        
        print('Candidates when STUN fails: $candidateCount');
        expect(candidateCount, greaterThanOrEqualTo(1)); // At least host candidate
        expect(hostCandidateFound, true);
        
      } catch (e) {
        print('Error during STUN fail test: $e');
      } finally {
        socket.close();
      }
    });
    
    test('Verify TURN candidate priority is lower than other types', () async {
      final turnConfig = TurnServerConfig(
        hostname: 'turn.example.com',
        port: 3478,
        username: 'test',
        password: 'test',
      );
      
      final socket = P2PSocket(
        peerId: 'priority_test',
        turnServerConfig: turnConfig,
      );
      
      final candidates = <IceCandidate>[];
      
      socket.onCandidate.listen((candidate) {
        candidates.add(candidate);
        print('Candidate: ${candidate.type}, Priority: ${candidate.priority}');
      });
      
      try {
        await socket.gatherCandidates().timeout(Duration(seconds: 10));
        await Future.delayed(Duration(seconds: 2));
        
        // Check that if any relay candidates were added, they have lower priority
        final relayCandidates = candidates.where((c) => c.type == 'relay');
        for (final candidate in relayCandidates) {
          // Relay candidates should have lower priority (higher number = lower priority)
          expect(candidate.priority, greaterThan(10)); // This is based on our implementation
        }
        
        // Check that host candidates have higher priority (lower number = higher priority)
        final hostCandidates = candidates.where((c) => c.type == 'host');
        for (final candidate in hostCandidates) {
          expect(candidate.priority, lessThanOrEqualTo(126)); // Based on our implementation
        }
        
      } catch (e) {
        print('Error during priority test: $e');
      } finally {
        socket.close();
      }
    });
  });
}