import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:core_lib/p2p_socket.dart';

void main() {
  group('P2PSocket Real IP Test - Correct Approach', () {
    test('Test using actual public IP for each node', () async {
      // Each socket uses dynamically discovered public IP
      final socketA = P2PSocket(
        peerId: 'node_a',
      );
      
      final socketB = P2PSocket(
        peerId: 'node_b', 
      );
      
      // Wait for IP discovery
      await Future.delayed(Duration(seconds: 3));
      
      // Use the discovered public IPs or fallback to local IPs
      final socketAIP = socketA.publicIp ?? (socketA.localIps.isNotEmpty ? socketA.localIps[0].address : '127.0.0.1');
      final socketBIP = socketB.publicIp ?? (socketB.localIps.isNotEmpty ? socketB.localIps[0].address : '127.0.0.1');
      final commonPortA = 8080;  // Use common port for communication
      final commonPortB = 8081;  // Use common port for communication
      
      // Track what each socket receives
      final receivedByA = <String>[];
      final receivedByB = <String>[];
      
      socketA.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        if (message != 'Connection established!') {
          receivedByA.add(message);
          print('Node A received: $message');
        }
      });
      
      socketB.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        if (message != 'Connection established!') {
          receivedByB.add(message);
          print('Node B received: $message');
        }
      });
      
      // Exchange candidates - each socket gets the other's public info
      socketA.onCandidate.listen((candidate) {
        print('Node A candidate: ${candidate.type} ${candidate.address}:${candidate.port}');
        // If it's a discovered/public IP candidate, share with the other socket
        if (candidate.type == 'discovered' || candidate.type == 'srflx' || candidate.type == 'host') {
          socketB.addRemoteCandidate(candidate);
        }
      });
      
      socketB.onCandidate.listen((candidate) {
        print('Node B candidate: ${candidate.type} ${candidate.address}:${candidate.port}');
        // If it's a discovered/public IP candidate, share with the other socket
        if (candidate.type == 'discovered' || candidate.type == 'srflx' || candidate.type == 'host') {
          socketA.addRemoteCandidate(candidate);
        }
      });
      
      // Start gathering candidates
      await Future.wait([
        socketA.gatherCandidates(),
        socketB.gatherCandidates()
      ]).timeout(Duration(seconds: 10), onTimeout: () => [Future.value(), Future.value()]);
      
      // Exchange the discovered IPs as manual candidates
      final aPublicCandidate = IceCandidate(
        'discovered', 
        socketAIP, 
        commonPortA,
        150,  // High priority for discovered IPs
        foundation: 'discovered_device'
      );
      socketB.addRemoteCandidate(aPublicCandidate);
      print('Added Node A ($socketAIP:$commonPortA) to Node B');
      
      final bPublicCandidate = IceCandidate(
        'discovered', 
        socketBIP, 
        commonPortB,
        150,  // High priority for discovered IPs
        foundation: 'discovered_device'
      );
      socketA.addRemoteCandidate(bPublicCandidate);
      print('Added Node B ($socketBIP:$commonPortB) to Node A');
      
      await Future.delayed(Duration(seconds: 3));
      
      // Send messages between nodes
      socketA.send(Uint8List.fromList('Hello from Node A'.codeUnits));
      socketB.send(Uint8List.fromList('Hello from Node B'.codeUnits));
      
      await Future.delayed(Duration(seconds: 3));
      
      print('Results:');
      print('  Node A received ${receivedByA.length} messages: $receivedByA');
      print('  Node B received ${receivedByB.length} messages: $receivedByB');
      
      socketA.close();
      socketB.close();
    }, timeout: Timeout(Duration(seconds: 40)));
    
    test('Simulate technician configuration process', () async {
      // Simulate the technician using dynamically discovered IPs
      print('Simulating technician configuring nodes with discovered IPs...');
      
      // Node 1
      final masterNode = P2PSocket(
        peerId: 'master',
      );
      
      // Node 2
      final clientNode = P2PSocket(
        peerId: 'client',
      );
      
      // Wait for IP discovery
      await Future.delayed(Duration(seconds: 3));
      
      // Use the discovered public IPs or fallback to local IPs
      final masterIP = masterNode.publicIp ?? (masterNode.localIps.isNotEmpty ? masterNode.localIps[0].address : '127.0.0.1');
      final clientIP = clientNode.publicIp ?? (clientNode.localIps.isNotEmpty ? clientNode.localIps[0].address : '127.0.0.1');
      final commonPortMaster = 8080;  // Use common port for communication
      final commonPortClient = 8081;  // Use common port for communication
      
      // Simulate distributed routing table sharing
      // Each node knows about the other's discovered public IP
      final masterInfo = IceCandidate(
        'discovered', 
        masterIP,  // Master's discovered IP
        commonPortMaster, 
        150, 
        foundation: 'dist_table'
      );
      
      final clientInfo = IceCandidate(
        'discovered', 
        clientIP,   // Client's discovered IP
        commonPortClient, 
        150, 
        foundation: 'dist_table'
      );
      
      // Add each node's info to the other (as would happen in routing table)
      masterNode.addRemoteCandidate(clientInfo);
      clientNode.addRemoteCandidate(masterInfo);
      
      // Track messages
      var masterReceived = 0;
      var clientReceived = 0;
      
      masterNode.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        if (message != 'Connection established!') {
          masterReceived++;
          print('Master received: $message');
        }
      });
      
      clientNode.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        if (message != 'Connection established!') {
          clientReceived++;
          print('Client received: $message');
        }
      });
      
      await Future.delayed(Duration(seconds: 2));
      
      // Send messages
      masterNode.send(Uint8List.fromList('Tech config: Master to Client'.codeUnits));
      clientNode.send(Uint8List.fromList('Tech config: Client to Master'.codeUnits));
      
      await Future.delayed(Duration(seconds: 3));
      
      print('Results after technician configuration:');
      print('  Master received: $masterReceived messages');
      print('  Client received: $clientReceived messages');
      
      masterNode.close();
      clientNode.close();
    }, timeout: Timeout(Duration(seconds: 40)));
  });
}