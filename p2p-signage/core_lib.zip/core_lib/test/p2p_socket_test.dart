import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:core_lib/core_lib.dart';

void main() {
  group('P2PSocket', () {
    test('gathers at least a host candidate', () async {
      final socket = P2PSocket(peerId: 'test_peer_1');
      final completer = Completer<IceCandidate>();

      socket.onCandidate.listen((candidate) {
        if (candidate.type == 'host') {
          completer.complete(candidate);
        }
      });

      await socket.gatherCandidates();
      final hostCandidate = await completer.future.timeout(const Duration(seconds: 5));

      expect(hostCandidate, isNotNull);
      expect(hostCandidate.type, 'host');

      socket.close();
    });

    test('establishes a connection between two peers', () async {
      final socketA = P2PSocket(peerId: 'peerA');
      final socketB = P2PSocket(peerId: 'peerB');

      final connectionCompleterA = Completer();
      final connectionCompleterB = Completer();

      socketA.onMessage.listen((data) {
        if (String.fromCharCodes(data) == 'Connection established!') {
          connectionCompleterA.complete();
        }
      });

      socketB.onMessage.listen((data) {
        if (String.fromCharCodes(data) == 'Connection established!') {
          connectionCompleterB.complete();
        }
      });

      socketA.onCandidate.listen((candidate) {
        socketB.addRemoteCandidate(candidate);
      });

      socketB.onCandidate.listen((candidate) {
        socketA.addRemoteCandidate(candidate);
      });

      await socketA.gatherCandidates();
      await socketB.gatherCandidates();

      await Future.wait([connectionCompleterA.future, connectionCompleterB.future])
          .timeout(const Duration(seconds: 10));

      socketA.close();
      socketB.close();
    });

    test('sends and receives data between two peers', () async {
      final socketA = P2PSocket(peerId: 'peerA_data');
      final socketB = P2PSocket(peerId: 'peerB_data');

      final connectionCompleterA = Completer();
      final connectionCompleterB = Completer();

      socketA.onMessage.listen((data) {
        if (String.fromCharCodes(data) == 'Connection established!') {
          connectionCompleterA.complete();
        }
      });

      socketB.onMessage.listen((data) {
        if (String.fromCharCodes(data) == 'Connection established!') {
          connectionCompleterB.complete();
        }
      });

      socketA.onCandidate.listen((candidate) {
        socketB.addRemoteCandidate(candidate);
      });

      socketB.onCandidate.listen((candidate) {
        socketA.addRemoteCandidate(candidate);
      });

      await socketA.gatherCandidates();
      await socketB.gatherCandidates();

      await Future.wait([connectionCompleterA.future, connectionCompleterB.future])
          .timeout(const Duration(seconds: 10));

      final messageCompleter = Completer<String>();
      socketB.onMessage.listen((data) {
        messageCompleter.complete(String.fromCharCodes(data));
      });

      final testMessage = 'Hello, P2P!';
      socketA.send(Uint8List.fromList(testMessage.codeUnits));

      final receivedMessage = await messageCompleter.future.timeout(const Duration(seconds: 5));

      expect(receivedMessage, testMessage);

      socketA.close();
      socketB.close();
    });
  });
}