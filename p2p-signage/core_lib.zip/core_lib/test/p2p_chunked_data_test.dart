import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:core_lib/p2p_socket.dart';

void main() {
  group('P2PSocket Chunked Large Data Test', () {
    test('Test chunked large data transfer through abstraction layer', () async {
      print('=== P2PSocket Chunked Large Data Transfer Test ===');
      
      // Create two P2PSocket instances to simulate master/slave devices
      final masterDevice = P2PSocket(
        peerId: 'master_device',
      );
      
      final slaveDevice = P2PSocket(
        peerId: 'slave_device',
      );
      
      print('Created master and slave devices');
      
      // Start gathering candidates for IP discovery
      print('Starting IP discovery...');
      await Future.wait([
        masterDevice.gatherCandidates(),
        slaveDevice.gatherCandidates()
      ]).timeout(Duration(seconds: 15), onTimeout: () => [Future.value(), Future.value()]);
      
      // Wait for IP discovery to complete
      await Future.delayed(Duration(seconds: 3));
      
      print('Discovered device information:');
      print('  Master Device:');
      print('    Private IP: ${masterDevice.discoveredPrivateIp}');
      print('    Port: ${masterDevice.localPort}');
      print('    Public IP: ${masterDevice.publicIp}');
      print('  Slave Device:');
      print('    Private IP: ${slaveDevice.discoveredPrivateIp}');
      print('    Port: ${slaveDevice.localPort}');
      print('    Public IP: ${slaveDevice.publicIp}');
      
      // Connect devices using public IPs to test relay functionality
      print('\\nSetting up connection using public IPs...');
      
      if (masterDevice.publicIp != null && masterDevice.localPort != null) {
        final masterPublicInfo = IceCandidate(
          'public_ip',
          masterDevice.publicIp!,  // Use public IP for relay testing
          masterDevice.localPort!, 
          150, 
          foundation: 'public_ip_test'
        );
        slaveDevice.addRemoteCandidate(masterPublicInfo);
        print('  Added Master public IP (${masterDevice.publicIp}:${masterDevice.localPort}) to Slave');
      }
      
      if (slaveDevice.publicIp != null && slaveDevice.localPort != null) {
        final slavePublicInfo = IceCandidate(
          'public_ip',
          slaveDevice.publicIp!,  // Use public IP for relay testing
          slaveDevice.localPort!, 
          150, 
          foundation: 'public_ip_test'
        );
        masterDevice.addRemoteCandidate(slavePublicInfo);
        print('  Added Slave public IP (${slaveDevice.publicIp}:${slaveDevice.localPort}) to Master');
      }
      
      await Future.delayed(Duration(seconds: 2));
      
      // Set up message tracking
      final masterReceivedMessages = <String>[];
      final slaveReceivedMessages = <String>[];
      final masterReceivedDataSizes = <int>[];
      final slaveReceivedDataSizes = <int>[];
      
      masterDevice.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        masterReceivedMessages.add(message);
        masterReceivedDataSizes.add(data.length);
        print('Master received message (${data.length} bytes)');
      });
      
      slaveDevice.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        slaveReceivedMessages.add(message);
        slaveReceivedDataSizes.add(data.length);
        print('Slave received message (${data.length} bytes)');
      });
      
      // Test with chunked large data transfer (simulate real-world usage)
      print('\\nTesting chunked large data transfer...');
      
      // Create a large playlist item (5MB of data)
      final largePlaylistSize = 5 * 1024 * 1024; // 5MB
      final largePlaylistData = Uint8List(largePlaylistSize);
      
      // Fill with pseudo-random data
      for (int i = 0; i < largePlaylistSize; i++) {
        largePlaylistData[i] = (i * 7 + 13) % 256;
      }
      
      print('Created large playlist item (${(largePlaylistSize / (1024 * 1024)).toStringAsFixed(2)} MB)');
      
      // Split into chunks (64KB each to avoid UDP limitations)
      final chunkSize = 64 * 1024; // 64KB chunks
      final chunks = <Uint8List>[];
      
      for (int i = 0; i < largePlaylistData.length; i += chunkSize) {
        final end = (i + chunkSize < largePlaylistData.length) ? i + chunkSize : largePlaylistData.length;
        final chunk = Uint8List(end - i);
        // Copy data to chunk
        for (int j = 0; j < chunk.length; j++) {
          chunk[j] = largePlaylistData[i + j];
        }
        chunks.add(chunk);
      }
      
      print('Split into ${chunks.length} chunks of max ${(chunkSize / 1024).toStringAsFixed(1)} KB each');
      
      // Send chunks with metadata
      final startTime = DateTime.now();
      int chunksSent = 0;
      int totalBytesSent = 0;
      
      final transferId = 'transfer_${DateTime.now().millisecondsSinceEpoch}';
      
      print('\\nSending chunks with metadata...');
      
      for (int i = 0; i < chunks.length; i++) {
        final chunkMetadata = {
          'type': 'chunked_data',
          'transferId': transferId,
          'chunkIndex': i,
          'totalChunks': chunks.length,
          'chunkSize': chunks[i].length,
          'timestamp': DateTime.now().millisecondsSinceEpoch,
          'data': base64Encode(chunks[i]), // Base64 encode the binary data
        };
        
        final jsonString = jsonEncode(chunkMetadata);
        final messageBytes = Uint8List.fromList(jsonString.codeUnits);
        
        try {
          masterDevice.send(messageBytes);
          chunksSent++;
          totalBytesSent += messageBytes.length;
          print('  Sent chunk $i/${chunks.length} (${messageBytes.length} bytes)');
        } catch (e) {
          print('  Error sending chunk $i: $e');
        }
        
        // Small delay between chunks to avoid overwhelming
        await Future.delayed(Duration(milliseconds: 50));
      }
      
      final sendTime = DateTime.now().difference(startTime);
      print('\\nChunk transmission completed:');
      print('  Chunks sent: $chunksSent/${chunks.length}');
      print('  Total bytes sent: ${totalBytesSent} (${(totalBytesSent / (1024 * 1024)).toStringAsFixed(2)} MB)');
      print('  Transmission time: ${sendTime.inMilliseconds} ms');
      print('  Average throughput: ${(totalBytesSent * 8 / sendTime.inMilliseconds).toStringAsFixed(2)} kbps');
      
      // Wait for all chunks to be received
      print('\\nWaiting for all chunks to be received...');
      await Future.delayed(Duration(seconds: 10));
      
      // Analyze received data
      print('\\n=== Chunk Reception Analysis ===');
      print('Master device received:');
      print('  Messages: ${masterReceivedMessages.length}');
      print('  Data sizes: ${masterReceivedDataSizes.join(', ')} bytes');
      
      print('Slave device received:');
      print('  Messages: ${slaveReceivedMessages.length}');
      print('  Data sizes: ${slaveReceivedDataSizes.join(', ')} bytes');
      
      // Count received chunks
      int receivedChunks = 0;
      for (final message in slaveReceivedMessages) {
        try {
          final jsonData = jsonDecode(message);
          if (jsonData['type'] == 'chunked_data' && jsonData['transferId'] == transferId) {
            receivedChunks++;
          }
        } catch (e) {
          // Ignore parsing errors
        }
      }
      
      final receiveTime = DateTime.now().difference(startTime);
      
      print('\\n=== Final Chunk Transfer Analysis ===');
      print('Transfer Summary:');
      print('  Total chunks sent: ${chunks.length}');
      print('  Successfully received chunks: $receivedChunks');
      print('  Lost chunks: ${chunks.length - receivedChunks}');
      print('  Success rate: ${((receivedChunks / chunks.length) * 100).toStringAsFixed(2)}%');
      print('  Total transfer time: ${receiveTime.inSeconds} seconds');
      
      if (receivedChunks >= chunks.length * 0.8) {
        print('  🎉 CHUNK TRANSFER TEST: PASSED!');
        print('     System successfully handled chunked large data transfer');
      } else {
        print('  ⚠️  CHUNK TRANSFER TEST: NEEDS IMPROVEMENT');
        print('     Too many chunks were lost during transmission');
      }
      
      // Test multiple small playlist items (more realistic scenario)
      print('\\n=== Multiple Small Playlist Items Test ===');
      print('Testing realistic playlist scenario with multiple small items...');
      
      final smallPlaylistItems = <Map<String, dynamic>>[];
      
      // Create 50 small playlist items (various types)
      for (int i = 0; i < 20; i++) {
        final itemType = i % 3 == 0 ? 'video' : (i % 3 == 1 ? 'image' : 'text');
        final itemSize = itemType == 'video' ? 256 * 1024 : (itemType == 'image' ? 128 * 1024 : 32 * 1024);
        
        smallPlaylistItems.add({
          'id': 'item_$i',
          'type': itemType,
          'name': 'Playlist Item $i.${itemType.substring(0, 3)}',
          'size': itemSize,
          'timestamp': DateTime.now().millisecondsSinceEpoch + i * 1000,
          'data': 'Sample content for item $i' * (itemSize ~/ 50), // Approximate size
        });
      }
      
      print('Created ${smallPlaylistItems.length} small playlist items:');
      print('  - ${smallPlaylistItems.where((item) => item['type'] == 'video').length} video items (~256KB each)');
      print('  - ${smallPlaylistItems.where((item) => item['type'] == 'image').length} image items (~128KB each)');
      print('  - ${smallPlaylistItems.where((item) => item['type'] == 'text').length} text items (~32KB each)');
      
      // Send all small playlist items
      final smallStartTime = DateTime.now();
      int smallItemsSent = 0;
      int smallTotalBytes = 0;
      
      for (int i = 0; i < smallPlaylistItems.length; i++) {
        final item = smallPlaylistItems[i];
        final jsonString = jsonEncode(item);
        final messageBytes = Uint8List.fromList(jsonString.codeUnits);
        
        try {
          masterDevice.send(messageBytes);
          smallItemsSent++;
          smallTotalBytes += messageBytes.length;
          print('  Sent ${item['type']} item ${item['id']} (${messageBytes.length} bytes)');
        } catch (e) {
          print('  Error sending item ${item['id']}: $e');
        }
        
        // Small delay between items
        await Future.delayed(Duration(milliseconds: 100));
      }
      
      final smallSendTime = DateTime.now().difference(smallStartTime);
      print('\\nSmall items transmission completed:');
      print('  Items sent: $smallItemsSent/${smallPlaylistItems.length}');
      print('  Total bytes sent: ${smallTotalBytes} (${(smallTotalBytes / 1024).toStringAsFixed(2)} KB)');
      print('  Transmission time: ${smallSendTime.inMilliseconds} ms');
      print('  Average throughput: ${(smallTotalBytes * 8 / smallSendTime.inMilliseconds).toStringAsFixed(2)} kbps');
      
      // Wait for all small items to be received
      print('\\nWaiting for all small items to be received...');
      await Future.delayed(Duration(seconds: 8));
      
      // Count received small items
      int receivedSmallItems = 0;
      for (final message in slaveReceivedMessages) {
        try {
          final jsonData = jsonDecode(message);
          if (jsonData.containsKey('id') && jsonData.containsKey('type')) {
            // This looks like a playlist item
            receivedSmallItems++;
          }
        } catch (e) {
          // Ignore parsing errors
        }
      }
      
      final smallReceiveTime = DateTime.now().difference(smallStartTime);
      
      print('\\n=== Small Items Transfer Analysis ===');
      print('Transfer Summary:');
      print('  Total small items sent: ${smallPlaylistItems.length}');
      print('  Successfully received items: $receivedSmallItems');
      print('  Lost items: ${smallPlaylistItems.length - receivedSmallItems}');
      print('  Success rate: ${((receivedSmallItems / smallPlaylistItems.length) * 100).toStringAsFixed(2)}%');
      print('  Total transfer time: ${smallReceiveTime.inSeconds} seconds');
      
      if (receivedSmallItems >= smallPlaylistItems.length * 0.9) {
        print('  🎉 SMALL ITEMS TRANSFER TEST: PASSED!');
        print('     System successfully handled multiple small playlist items');
      } else {
        print('  ⚠️  SMALL ITEMS TRANSFER TEST: NEEDS IMPROVEMENT');
        print('     Too many items were lost during transmission');
      }
      
      // Overall assessment
      final overallSuccessRate = ((receivedChunks / chunks.length) + (receivedSmallItems / smallPlaylistItems.length)) / 2;
      
      print('\\n=== OVERALL SYSTEM ASSESSMENT ===');
      print('Chunked Large Transfer Success Rate: ${((receivedChunks / chunks.length) * 100).toStringAsFixed(2)}%');
      print('Multiple Small Items Success Rate: ${((receivedSmallItems / smallPlaylistItems.length) * 100).toStringAsFixed(2)}%');
      print('Overall Success Rate: ${(overallSuccessRate * 100).toStringAsFixed(2)}%');
      
      if (overallSuccessRate >= 0.8) {
        print('  🏆 SYSTEM VERDICT: ROBUST FOR PRODUCTION USE!');
        print('     Successfully handles both large and small data transfers');
      } else if (overallSuccessRate >= 0.6) {
        print('  🟡 SYSTEM VERDICT: FUNCTIONAL WITH SOME IMPROVEMENT NEEDED');
        print('     Acceptable for most use cases but could be more reliable');
      } else {
        print('  🔴 SYSTEM VERDICT: NEEDS SIGNIFICANT IMPROVEMENT');
        print('     High packet loss rate affects usability');
      }
      
      // Close devices
      masterDevice.close();
      slaveDevice.close();
      
      print('\\nChunked large data transfer test completed!');
    }, timeout: Timeout(Duration(minutes: 2)));
  });
}