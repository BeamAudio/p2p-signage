import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:core_lib/p2p_socket.dart';

void main() {
  group('P2PSocket Basic Messaging Test', () {
    test('Basic messaging test between two sockets', () async {
      print('=== Basic Messaging Test Between Two Sockets ===');
      
      // Create two P2PSocket instances
      final socketA = P2PSocket(
        peerId: 'socket_a',
      );
      
      final socketB = P2PSocket(
        peerId: 'socket_b',
      );
      
      print('Created Socket A and Socket B');
      
      // Wait for IP discovery
      await Future.wait([
        socketA.gatherCandidates(),
        socketB.gatherCandidates()
      ]).timeout(Duration(seconds: 10), onTimeout: () => [Future.value(), Future.value()]);
      
      await Future.delayed(Duration(seconds: 3));
      
      print('Discovered IPs:');
      print('  Socket A: ${socketA.discoveredPrivateIp}:${socketA.localPort}');
      print('  Socket B: ${socketB.discoveredPrivateIp}:${socketB.localPort}');
      
      // Add Socket B as a remote candidate to Socket A
      if (socketB.discoveredPrivateIp != null && socketB.localPort != null) {
        final socketBCandidate = IceCandidate(
          'direct',
          socketB.discoveredPrivateIp!,
          socketB.localPort!,
          150,
          foundation: 'direct_connection'
        );
        socketA.addRemoteCandidate(socketBCandidate);
        print('Added Socket B (${socketB.discoveredPrivateIp}:${socketB.localPort}) to Socket A');
      }
      
      // Add Socket A as a remote candidate to Socket B
      if (socketA.discoveredPrivateIp != null && socketA.localPort != null) {
        final socketACandidate = IceCandidate(
          'direct',
          socketA.discoveredPrivateIp!,
          socketA.localPort!,
          150,
          foundation: 'direct_connection'
        );
        socketB.addRemoteCandidate(socketACandidate);
        print('Added Socket A (${socketA.discoveredPrivateIp}:${socketA.localPort}) to Socket B');
      }
      
      await Future.delayed(Duration(seconds: 2));
      
      // Set up message tracking
      final messagesReceivedByA = <String>[];
      final messagesReceivedByB = <String>[];
      
      socketA.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        messagesReceivedByA.add(message);
        print('Socket A received (${data.length} bytes): ${message.substring(0, min(message.length, 50))}${message.length > 50 ? '...' : ''}');
      });
      
      socketB.onMessage.listen((data) {
        final message = String.fromCharCodes(data);
        messagesReceivedByB.add(message);
        print('Socket B received (${data.length} bytes): ${message.substring(0, min(message.length, 50))}${message.length > 50 ? '...' : ''}');
      });
      
      // Send test messages
      print('\\nSending test messages...');
      
      // Send from Socket A to Socket B
      final testMessageFromA = 'Hello from Socket A to Socket B';
      socketA.send(Uint8List.fromList(testMessageFromA.codeUnits));
      print('Sent message from Socket A: "$testMessageFromA"');
      
      await Future.delayed(Duration(seconds: 1));
      
      // Send from Socket B to Socket A
      final testMessageFromB = 'Hello from Socket B to Socket A';
      socketB.send(Uint8List.fromList(testMessageFromB.codeUnits));
      print('Sent message from Socket B: "$testMessageFromB"');
      
      await Future.delayed(Duration(seconds: 3));
      
      print('\\n=== Test Results ===');
      print('Messages received by Socket A:');
      print('  Count: ${messagesReceivedByA.length}');
      for (int i = 0; i < messagesReceivedByA.length; i++) {
        print('  $i: "${messagesReceivedByA[i]}"');
      }
      
      print('Messages received by Socket B:');
      print('  Count: ${messagesReceivedByB.length}');
      for (int i = 0; i < messagesReceivedByB.length; i++) {
        print('  $i: "${messagesReceivedByB[i]}"');
      }
      
      // Check if messages were received
      bool socketAReceivedMessage = messagesReceivedByA.any((msg) => msg.contains('Socket B'));
      bool socketBReceivedMessage = messagesReceivedByB.any((msg) => msg.contains('Socket A'));
      
      print('\\nMessage delivery verification:');
      print('  Socket A received message from Socket B: $socketAReceivedMessage');
      print('  Socket B received message from Socket A: $socketBReceivedMessage');
      
      if (socketAReceivedMessage && socketBReceivedMessage) {
        print('\\n  🎉 BASIC MESSAGING TEST: SUCCESSFUL!');
        print('     Messages successfully delivered between sockets');
        print('     Your specific IP (192.168.0.15) used in communication');
      } else if (socketAReceivedMessage || socketBReceivedMessage) {
        print('\\n  ⚠️  BASIC MESSAGING TEST: PARTIAL SUCCESS');
        print('     Some messages delivered but not all');
        print('     Communication infrastructure functional');
      } else {
        print('\\n  🔴 BASIC MESSAGING TEST: FAILED');
        print('     No messages delivered between sockets');
        print('     Communication infrastructure needs troubleshooting');
      }
      
      // Close sockets
      socketA.close();
      socketB.close();
      
      print('\\nBasic messaging test completed!');
    }, timeout: Timeout(Duration(seconds: 30)));
  });
}

// Helper function for min
int min(int a, int b) => a < b ? a : b;