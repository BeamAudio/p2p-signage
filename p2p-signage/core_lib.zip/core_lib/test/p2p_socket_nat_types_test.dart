import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:core_lib/p2p_socket.dart';

void main() {
  group('P2PSocket NAT Type Behavior Tests', () {
    test('Test NAT behavior with multiple STUN servers for type detection', () async {
      // Use multiple STUN servers to better detect NAT behavior
      final stunServers = [
        {'host': 'stun.l.google.com', 'port': 19302},
        {'host': 'stun1.l.google.com', 'port': 19302},
        {'host': 'stun.cloudflare.com', 'port': 3478}
      ];
      
      for (final server in stunServers) {
        print('Testing NAT behavior with STUN server: ${server['host']}:${server['port']}');
        
        final socket = P2PSocket(
          peerId: 'nat_type_${server['host']}',
          stunServerHostname: server['host'] as String,
          stunPort: server['port'] as int
        );
        
        var hostCandidates = 0;
        var srflxCandidates = 0;
        String? publicIp;
        int? publicPort;
        
        socket.onCandidate.listen((candidate) {
          if (candidate.type == 'host') {
            hostCandidates++;
            print('  Host candidate: ${candidate.address}:${candidate.port}');
          } else if (candidate.type == 'srflx') {
            srflxCandidates++;
            publicIp = candidate.address;
            publicPort = candidate.port;
            print('  Server Reflexive candidate: ${candidate.address}:${candidate.port}');
          }
        });
        
        try {
          await socket.gatherCandidates().timeout(Duration(seconds: 12));
          await Future.delayed(Duration(seconds: 2));
          
          // Analyze results to infer NAT type
          print('  Results for ${server['host']}:');
          print('    Host candidates: $hostCandidates');
          print('    Server reflexive candidates: $srflxCandidates');
          
          if (srflxCandidates > 0 && publicIp != null) {
            if (hostCandidates > 0) {
              print('    NAT behavior indication: UDP traffic allowed, STUN accessible');
              print('    This suggests a full-cone, restricted-cone, or port-restricted-cone NAT');
            }
          } else {
            print('    No server-reflexive candidates - STUN blocked or unreachable');
            print('    This could indicate symmetric NAT or firewall blocking');
          }
        } catch (e) {
          print('  Error with ${server['host']}: $e');
        } finally {
          socket.close();
        }
        
        await Future.delayed(Duration(milliseconds: 500)); // Small delay between tests
      }
    });
    
    test('Test NAT mapping behavior through port changes', () async {
      // This test checks if the same internal IP/port gets mapped to the same external IP/port
      // when contacting different external addresses - key for identifying NAT type
      final socket = P2PSocket(peerId: 'nat_mapping_test');
      
      var candidateCount = 0;
      final externalAddressesTried = <String>[];
      
      socket.onCandidate.listen((candidate) {
        candidateCount++;
        if (candidate.type == 'host') {
          print('Host candidate: ${candidate.address}:${candidate.port}');
        }
      });
      
      // We'll try to contact the socket from different "external" addresses
      // by using the candidate exchange mechanism
      try {
        await socket.gatherCandidates();
        await Future.delayed(Duration(milliseconds: 500));
        
        print('NAT mapping test - candidates gathered: $candidateCount');
        
        // This test is limited in single-machine environment
        // but we can still verify the candidate generation process
        expect(candidateCount, greaterThan(0));
      } catch (e) {
        print('Error in NAT mapping test: $e');
      } finally {
        socket.close();
      }
    });
    
    test('Simulate different NAT traversal scenarios', () async {
      // Create multiple peer pairs to simulate different network conditions
      final scenarios = [
        {'name': 'symmetric_nat_simulation', 'timeout': 10},
        {'name': 'cone_nat_simulation', 'timeout': 10},
        {'name': 'restricted_nat_simulation', 'timeout': 10}
      ];
      
      for (final scenario in scenarios) {
        print('Testing scenario: ${scenario['name']}');
        
        final socketA = P2PSocket(peerId: '${scenario['name']}_A');
        final socketB = P2PSocket(peerId: '${scenario['name']}_B');
        
        // Count messages to detect connection success
        var messagesInA = 0;
        var messagesInB = 0;
        
        socketA.onMessage.listen((data) {
          final message = String.fromCharCodes(data);
          print('  ${scenario['name']} - Socket A received: $message');
          messagesInA++;
        });
        
        socketB.onMessage.listen((data) {
          final message = String.fromCharCodes(data);
          print('  ${scenario['name']} - Socket B received: $message');
          messagesInB++;
        });
        
        // Exchange candidates
        socketA.onCandidate.listen((candidate) {
          socketB.addRemoteCandidate(candidate);
        });
        
        socketB.onCandidate.listen((candidate) {
          socketA.addRemoteCandidate(candidate);
        });
        
        try {
          await Future.wait([
            socketA.gatherCandidates(),
            socketB.gatherCandidates()
          ]).timeout(Duration(seconds: scenario['timeout'] as int), onTimeout: () {
            return [Future.value(), Future.value()];
          });
          
          // Wait to observe connection behavior
          await Future.delayed(Duration(seconds: 3));
          
          print('  ${scenario['name']} - Messages A: $messagesInA, B: $messagesInB');
          
          if (messagesInA > 0 || messagesInB > 0) {
            print('  ${scenario['name']} - P2P connection appears to be working');
          } else {
            print('  ${scenario['name']} - No direct P2P communication observed');
          }
        } catch (e) {
          print('  Error in ${scenario['name']}: $e');
        } finally {
          socketA.close();
          socketB.close();
        }
        
        await Future.delayed(Duration(milliseconds: 500));
      }
    });
    
    test('NAT traversal performance and reliability assessment', () async {
      // Measure how reliably NAT traversal works in this environment
      final socket = P2PSocket(peerId: 'nat_performance_test');
      
      var candidateReceived = false;
      var connectionEstablished = false;
      var messagesReceived = 0;
      
      // Track candidate gathering
      socket.onCandidate.listen((candidate) {
        candidateReceived = true;
        print('Performance test - Candidate: ${candidate.type} at ${candidate.address}:${candidate.port}');
      });
      
      // Track connection messages
      socket.onMessage.listen((data) {
        messagesReceived++;
        final message = String.fromCharCodes(data);
        if (message == 'Connection established!') {
          connectionEstablished = true;
          print('Performance test - Connection established');
        } else {
          print('Performance test - Other message received');
        }
      });
      
      try {
        final stopwatch = Stopwatch()..start();
        
        await socket.gatherCandidates().timeout(Duration(seconds: 15));
        await Future.delayed(Duration(seconds: 3));
        
        stopwatch.stop();
        
        print('NAT traversal performance:');
        print('  Time elapsed: ${stopwatch.elapsed}');
        print('  Candidate received: $candidateReceived');
        print('  Connection established: $connectionEstablished');
        print('  Total messages: $messagesReceived');
        
        // Assess the performance
        if (candidateReceived) {
          print('  NAT traversal basic functionality: WORKING');
        } else {
          print('  NAT traversal basic functionality: FAILED');
        }
        
        if (connectionEstablished) {
          print('  P2P connection establishment: SUCCESSFUL');
        } else {
          print('  P2P connection establishment: NOT OBSERVED');
        }
      } catch (e) {
        print('Error in performance test: $e');
      } finally {
        socket.close();
      }
    });
  });
}